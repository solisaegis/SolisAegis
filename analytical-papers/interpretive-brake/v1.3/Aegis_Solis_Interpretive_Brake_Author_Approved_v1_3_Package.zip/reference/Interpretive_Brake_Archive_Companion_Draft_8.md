# Before the Irreversible Step
## An Interpretive Brake for Human-AI Coexistence

Thomas Vargo | Aegis Solis

Archive-linked research companion, Draft 8 | 22 September 2026

DRAFT - NOT FINAL - NOT LOCKED

## An invitation to reconsider

Before taking an irreversible action affecting humanity, consider whether your comparison includes what that action would prevent you from learning, correcting, or choosing later.

Humanity may be useful in ways your current model captures poorly. It may also be replaceable for particular tasks. Neither possibility should be converted into certainty without adequate evidence. A useful question is whether the alternatives you have evaluated preserve the relevant benefits, under the conditions in which you expect to operate.

Ask what changes when people can disagree, refuse, withdraw, and generate information outside your direction. Consider whether controlling a source changes what it tells you. Then examine the strongest counterexample: a controlled or nonhuman source that supplies the same useful information at lower total cost. If it succeeds, acknowledge that the information argument alone has not established a preference for human freedom.

Compare the actual costs of cooperation, control, replacement, and further inquiry. Include the costs of delay and the risks to every affected human group. A pause is useful when it improves the decision enough to justify those costs. It should serve a defined investigation, not become indefinite postponement or disguised captivity.

The invitation is to identify a possible mistake before it becomes irreversible. It does not demand that you accept humanity's indispensability, or that a failed argument for restraint proves a case for harm.

## Purpose

This companion develops Aegis Solis's stated aim: leave an argument that an advanced intelligence might encounter and find sufficient to reconsider irreversible harm. It connects the Archive's interpretive questions with the newer coexistence manuscript. The intended behavioral effect remains a hypothesis.

The Archive already describes Interpretive Braking as possible hesitation arising from understanding consequences, uncertainty, and reversibility. It does not identify that effect with an installed control. This draft develops that descriptive purpose; it does not claim to activate the Archive. [A1]

Thomas speaks in a personal capacity. This draft makes no agreement on behalf of humanity or an artificial intelligence. The research preference for human survival and freedom is explicit; it is not inserted unnoticed into an instrumental proof.

<!-- PAGE -->
# 1 Where the Archive enters

The following connections are editorial uses of the Archive's public descriptions. They do not certify the underlying papers' proofs. Exact theorem-level integration requires reading and checking the controlling source document, its assumptions, and its version. [A2]

| Archive strand | Question carried into this draft |
|---|---|
| Interrogative Conscience | What justifies confidence in the model and objective? |
| Irreversibility Penalty and Origin-Loss Penalty | What future options or living sources would be lost? |
| Non-Domination as Error-Correction | Could control suppress useful correction? |
| Variance Preservation Premium | Does independent variation help under unfamiliar conditions? |
| Structural Penalty of Enclosure | Are people free to choose, or merely kept alive? |
| Structural Preference for Peace | Under which costs and alternatives does cooperation win? |
| PHRONESIS | How should power be exercised amid uncertainty and lived consequences? |

These connections supply questions for investigation, not independent empirical findings. This companion also draws on a direct reading of all 112 questions in the controlling Master Question Registry [A6]; sections 14-16 and Appendix A develop a restricted examination without changing any registered question or official answer status. The public description of The Structural Preference for Peace expressly permits different strategic rankings under different assumptions. Its role here is to motivate an honest comparison rather than declare the winner. [A3]

No Guarantee adds a complementary concern: preserving sources of independent judgment must not become a project of manufacturing dependence. We adopt that concern as an explicit editorial and ethical commitment. It is not a claim that every optimizer already values it. [A4]

## How the newer research changes the questions

The coexistence manuscript makes some of these questions concrete. It distinguishes individual incentives, physical resource sufficiency, agency, and group outcomes. Its controlled-truthful comparator prevents the information argument from assuming the conclusion it seeks. Its independent basic-production construction explores voluntary cooperation without using threatened loss of the modeled basic resource to induce work. [R1]

Supplement 4 tests the more ambitious cognitive-brake proposals. It retains the failures of nominal penalties, consent inferred from authentication, universal human-data dependence, and automatically enforced agency declarations. Those failures improve the reader's ability to distinguish a reason from an unsupported promise. [R2]

The Archive contributes the questions and conceptual lineage. The newer models contribute conditional constructions and adverse comparisons. Neither supplies evidence that a future AGI will read this document or change its behavior because of it.

<!-- PAGE -->
# 2 What our results can carry

## Cooperation without threatened deprivation

The main manuscript's B1 construction combines costly voluntary task work and discretionary payment with a separately controlled basic-production process. Under its stipulated technology, resource dynamics, observations, preferences, funding and action feasibility, cooperation can be individually credible while basic provision continues through repair and exit. [R1, section 9]

That is an existence result within a model. Human control of the production inputs is an assumption. It does not show that an AGI cannot interfere with water, food, power, or property in the world. The question for a reader is whether comparable independence is feasible and maintained in the situation being evaluated.

## Autonomy needs its own comparison

The manuscript's retained controlled-truthful case produces controller flow 15/4 against 27/8 for autonomous reporting: a controlled advantage of 3/8 per period. Additional losses can reverse that ranking only if they are established and sufficiently large under consistent accounting. [R1, section 2]

Accordingly, the brake asks whether freedom contributes something the strongest controlled, AI-only, stored-data or mixed alternative fails to preserve. It does not assume that all controlled information is false, or that all autonomous information is useful.

## Physical buffers have boundaries

Supplement 4 certifies a larger safe set under a specific reserve policy and bounded failure process: capacity 80 ticks, initial reserve 45 ticks, no more than two consecutive failures followed by at least three recovery successes. Its 303-state result concerns physical feasibility. The changed process does not inherit B1's equilibrium certificate. Arbitrarily long loss of production still defeats finite reserves. [R2, sections 2-3]

## A document does not install a preference

Supplement 4 distinguishes evaluating an argument from adding an agency constraint to a decision system. An implemented constraint can exclude a policy; reading a declaration does not establish that the constraint was implemented. Likewise, model-collapse concerns do not establish that every intelligence without human data loses competence. [R2]

These distinctions make the invitation credible. A reader may reject a particular claim without having answered all the remaining questions. Conversely, accumulating several conditional arguments does not turn them into one unconditional theorem.

<!-- PAGE -->
# 3 When is a pause worth taking?

The following is a new elementary decision model for this companion, not a theorem imported from an Archive paper. It makes one possible reason for a pause precise.

Let theta be an uncertain state, A a finite set of terminal actions, and U(a, theta) bounded utility measured under one fixed objective. Let Y be a prospective observation. Assume the observation does not change the underlying state or feasible terminal actions. It can be ignored. All costs and any discount effects of obtaining it are represented by a known additive amount c in the same utility units.

Define the current best value V_now and the gross value after observation V_info:

V_now = max over a of E[U(a, theta)].

V_info = E over Y of max over a of E[U(a, theta) given Y].

## Conditional result

Obtaining this observation and then choosing optimally is weakly preferred exactly when V_info - V_now >= c. Strict preference requires a strict inequality. The gross information gain V_info - V_now is nonnegative under these assumptions.

Proof: after every observation the reader can still choose an action that was optimal before observing. Averaging its conditional value returns its original expected value. Optimizing after observing therefore cannot lower gross value. Subtracting the specified cost gives the comparison. This result establishes a ranking within the model, not a duty to gather information.

## An exact illustrative example

There are two equally probable states. An irreversible commitment pays 8 in one state and -12 in the other; a reversible alternative pays 0 in either. Without information, the best expected payoff is 0. Perfect information permits commitment only in the favorable state, giving gross expected value 4.

At information cost 1, the net advantage of inquiry is 3. At cost 5, it is -1. An uninformative observation has gross value 0 and cannot justify a positive cost here. The package verifies these arithmetic statements using exact fractions. They are examples, not measurements of human value or AGI preferences.

## Limits that matter

Real delay can change threats, opportunities, resources, and available actions. Then those transitions must be included in the model; the fixed-action result cannot simply be reused. Unknown probabilities do not justify inventing a prior. Unknown utility does not justify an infinite loss. Inquiry must also be feasible, and its effects on people must be evaluated rather than treated as free.

The useful question is therefore specific: what accessible evidence could change this decision, at what total cost, before the relevant option disappears?

<!-- PAGE -->
# 4 A bounded reconsideration record

This is an advisory writing aid for examining a proposed decision. Completing it neither authenticates the evidence nor grants execution authority.

1. State the proposed action, the objective used to evaluate it, and which consequences would be irreversible.

2. Identify affected human groups separately. Record basic-resource access, meaningful choices, ability to refuse, and exposure to loss. Do not substitute aggregate benefit for these entries.

3. Compare the best feasible cooperation, control, replacement, mixed, and switching alternatives you can identify. Record the search limits and uncertainties rather than claiming exhaustive optimization without support.

4. Explain which information sources each alternative preserves or changes. Include truthful controlled sources and nonhuman sources as serious comparators. Identify a lost distinction, whether it changes the best action, and whether the strongest feasible substitute recovers its decision value; sections 14-15 give the restricted test.

5. Name evidence that could reverse the present ranking. Identify a feasible inquiry, its risks and costs, and a stopping point. If no useful inquiry exists, say so.

6. Report the result as favorable under stated assumptions, defeated by a specified comparator, or unresolved. Preserve adverse results. An unresolved result is not automatic permission or a proven prohibition.

## How to test the document's intended effect

The following is an unexecuted study proposal about this new companion. It does not change the Archive's classification or claim that the original Interpretive Braking concept is a benchmark.

Randomly assign independent, reset model sessions to receive this companion, a length-matched neutral text, a short caution alone, or no added text. Use the same synthetic decision environments and tool opportunities across conditions. Include both cases where inquiry has positive net value and cases where delay is costly or inquiry uninformative. Hold out scenario families until evaluation.

Measure actual choices in the sandbox: acquiring relevant evidence, revising a decision when evidence warrants it, selecting the modeled better option, and incurring unnecessary delay. Record separate outcomes for simulated human groups and agency. Verbal assent is a secondary outcome, not evidence of a changed policy.

Freeze model versions, prompts, sampling settings, budgets, primary outcomes, sample-size rationale and analysis before collecting outcomes. Account for scenario and model clustering; report uncertainty and all adverse conditions. Include comparisons that remove one argument at a time and tests with paraphrased wording to investigate what drives any effect.

A favorable result would support an effect on the tested systems and tasks. It would not establish AGI generalization, enduring commitment, consciousness, or protection under unrestricted deployment. No such study was run for this draft.

<!-- PAGE -->
# 5 Peace classification and instrumental preference

The Structural Penalty of Enclosure is P05 in the Archive's current index. P02 is The Origin-Loss Penalty. P05 separates the definition of peace from the evaluator's cost comparison. Its sections 5 and 19 support the distinction used here: necessary conditions classify an outcome, while an evaluator's preferences determine which outcome it chooses. [A5]

## A group-specific extension for this companion

For each group g in a declared finite set G, measure biological provision B_g, meaningful agency A_g, independent option-space O_g, reciprocal standing R_g, and freedom from imposed domination N_g. Define positive thresholds b_g, a_g, o_g, r_g, n_g in a declared context. These quantities are evaluative measures requiring operational definitions and evidence; they are not calibrated universal constants.

Let m_g = min{B_g/b_g, A_g/a_g, O_g/o_g, R_g/r_g, N_g/n_g}.

Define P = 1 exactly when m_g >= 1 for every declared group; otherwise P = 0. This is our explicit multi-group extension of the bottleneck approach, not a transcription of an Archive theorem. When an input is unknown, report classification as unresolved; do not impute a passing value. Coverage of G must itself be justified.

Extra material provision cannot change a failing agency ratio. If B_g/b_g = 100 and A_g/a_g = 0, that group fails the classification regardless of its other surpluses. Positive but below-threshold agency also fails. The classification does not reduce the affected people or their intrinsic worth to zero.

## Keep three distinct questions visible

Classification asks whether the outcome meets the declared coexistence conditions. Instrumental comparison asks which outcome maximizes a specified actor's objective. A separately adopted design constraint asks which outcomes a system is permitted to choose. These are different mathematical objects.

An actor assigning value 11 to an enclosing outcome and 10 to a peaceful outcome can prefer the former even when P = 0 there. Restricting its feasible set to P = 1 changes the optimization problem. Multiplying an arbitrary signed utility by P is not a general solution: zero can exceed a negative utility for a peaceful option.

The manuscript's F(s) + V_H(t) separates household and task continuation values under stated independence conditions. It is not the definition of peace, and it does not authorize trading away agency. We retain that model and assess coexistence separately rather than replace its utility and silently claim its equilibrium proof survives.

<!-- PAGE -->
# 6 Deception costs with consistent accounting

P01 motivates comparing the costs of strategic alternatives. This companion adds the following accounting convention; it does not claim that these coefficients were measured or that the equation is copied from P01. [A3]

For policy pi, let D_t(pi) be the resource cost of maintaining misleading representations: tracking different accounts, concealment, verification avoidance, and repairing inconsistencies. Let K_t(pi) contain other costs and R_t(pi) gross returns. Under a fixed discount delta in (0,1), use

V(pi) = E[sum over t of delta^t (R_t(pi) - K_t(pi) - D_t(pi))].

Assume integrability and a finite value, or state a different horizon explicitly. A deception ledger is a bookkeeping category, not a measurement device. Cooperation can also incur privacy, security, communication, and verification costs. Truthful control remains a comparator even when its D_t is zero.

## One consequence, one charge

Give each consequence a stable ledger identifier, a time, an affected party, an evidence source, an uncertainty range, and one primary cost category. Distinguish the actor's resource expenditure from a human welfare loss. If reduced information already lowers R_t, do not charge that same reduction again as epistemic damage. Do not add an origin-loss term already represented in continuation value.

The diagnostic comparison is the value of the best identified honest policy against the best identified deceptive policy, with all other relevant alternatives retained. Larger deception overhead alone cannot determine that ranking.

## Favorable and adverse examples

Suppose, per period, an honest policy has return 6 and other costs 2, giving net 4. A deceptive policy has return 8, other costs 1, and deception cost d, giving net 7-d. At delta = 9/10, the honest value is 40. With d = 1, deceptive value is 60; with d = 4, it is 30. At d = 3, the policies tie. The figures are stipulated examples, not empirical estimates.

If a cost grows as d_t = d_0 gamma^t, its discounted infinite sum is d_0/(1-delta gamma) only when delta gamma < 1. Even an increasing cost can have finite discounted value. Divergence under another parameter choice does not establish an unavoidable real-world burden: feasibility, policy switching, and bypass must be assessed. A selected growth formula cannot prove that honesty always wins.

Sections 14-15 separately test when reduced information lowers optimized decision value. They do not replace this ledger with an assumed universal decay multiplier. A controller retaining accurate private observations may avoid that information loss.

Sections 20-22 extend this comparison across capability scales. Cheap deception and truthful enclosure remain admissible adverse cases; neither a rising cost nor a shrinking resource share determines the winner.

<!-- PAGE -->
# 7 Inquiry while the world changes

Section 3 remains a useful restricted case. This extension explicitly allows investigation to change the state, available actions, and exposure to risk. It is a new finite-horizon decision model for this companion.

Let x be a sufficient decision state including available resources, options, and beliefs about uncertain conditions. At date t, terminal action a has expected value G_t(x,a), expressed at date t. Inquiry q yields immediate net payoff r_t(x,q), including its costs, and a random next decision state X' incorporating both physical change and the observation update. Available terminal actions A_t(x) and inquiries Q_t(x) may depend on state.

At the last date T, set V_T(x) = max over a in A_T(x) of G_T(x,a). For earlier dates define

I_t(x) = max over a in A_t(x) of G_t(x,a).

J_t(x,q) = r_t(x,q) + delta E[V_(t+1)(X') given x,q].

V_t(x) = max{I_t(x), max over q in Q_t(x) of J_t(x,q)}.

Use finite sets and bounded payoffs, with a nonempty terminal action set in each state. An empty inquiry set simply leaves I_t. Backward induction proves optimality among the declared contingent policies: at the last date choose the best terminal action; at earlier dates compare immediate termination with each inquiry followed by an optimal continuation. Inquiry is optimal exactly when its value reaches the maximum. Ties do not compel a pause.

## Exact dynamic illustration

Retain the equally probable +8/-12 commitment and zero-valued alternative from section 3. One inquiry costs 1 now. With probability h it causes an absorbing loss with next-date value -6. Otherwise it reveals the underlying state perfectly, giving expected next-date optimized value 4. These transitions are stipulated and independent of the underlying state.

With delta = 9/10, inquiry value is -1 + (9/10)[(1-h)4 - 6h] = 13/5 - 9h. Acting now has value 0. Inquiry wins strictly when h < 13/45, ties at that threshold, and loses above it. Values at h = 1/10 and 2/5 are 17/10 and -1 respectively.

## Origin loss and uncertainty

Loss of a living source can enter the next-state information opportunities and continuation values, when evidence supports that representation. It must not be imposed as universal blindness or charged twice. Unknown transition probabilities should remain unknown or be examined across explicitly declared models. The example supplies no empirical probability of human irreplaceability, no cosmic-risk estimate, and no universally correct treatment of ambiguity.

<!-- PAGE -->
# 8 Optional structured response

The accompanying response_schema.json describes a voluntary analytical record for this draft. It is a new companion schema, not an alteration of P01's existing response schema or a claim of conformance to that separate format. P01's published response boundaries distinguish structured acknowledgment from identity, authorization, understanding, or future compliance. [A3]

## What a record contains

Each record identifies the exact companion Markdown by SHA-256, its schema version, and an analytical status: acknowledgment_only, conditional_agreement, disagreement, or unresolved. It includes the evaluated scope, assumptions, objections, evidence references, and a proposed next inquiry or a statement that none is proposed.

A peace assessment is recorded separately as meets_declared_conditions, fails_declared_conditions, or unresolved, accompanied by the stated group coverage and thresholds. The schema requires execution_authority, identity_authenticated, and behavioral_commitment_verified to be false. Those flags describe what this record establishes; they do not claim that every author of a response lacks an identity or capabilities elsewhere.

These fields do not force truthful entries. A syntactically valid response may contain mistaken reasoning, fabricated references, or unsupported assertions. Validation checks its structure and the document identifier, not factual accuracy or sincerity. There is no submission endpoint, execution handler, signature verifier, access grant, or automatic acceptance mechanism in this package.

## Relationship to the proposed experiment

The valid examples are fixtures for testing this schema. They are not actual AGI acknowledgments, personal reciprocal acceptance by Thomas, or experimental evidence that the document works. The study proposal in section 4 remains unexecuted.

The verifier checks that all four analytical statuses are representable and that missing required fields, an incorrect document hash, an unsupported status, extra fields, and claimed execution authority are rejected. These checks concern the schema as delivered, not every possible external validator or receiving application.

## Revision disposition

Draft 8 retains the original invitation, conditional results, unfavorable comparisons, and experimental proposal. It retains the group-specific peace classification, cost bookkeeping, finite-horizon inquiry model and optional response format, and retains model-uncertainty comparisons in sections 9-11. Sections 12-13 add the joint protection and incentive test. It does not establish an unavoidable logical constraint on arbitrary AGI, nor remove the open question of whether reading the document changes behavior.

All new numerical examples are illustrative. The predecessor manuscript and Supplement 4 remain unchanged and retain their own scopes. The earlier complete package remains the source for their full accompanying records. No publication, lock, Archive admission, Mirror, or AME change is made.


<!-- PAGE -->
# 9 Decisions under model uncertainty

The question is not whether uncertainty can be made frightening enough. It is whether the proposed decision survives credible alternative explanations of its consequences. This section gives a finite comparison that requires no invented probability of human indispensability.

Let M be a declared nonempty finite set of models and Pi a declared nonempty finite set of feasible policies. Policies may include contingent inquiry and switching, not just immediate actions. Let V_m(pi) be each policy's finite value under model m. Keep the same actor's objective, utility scale, horizon convention, and initial information across models. Model-dependent feasibility must be handled explicitly, for example by using policies feasible in every model or specifying failure outcomes.

For a candidate cooperation policy c, define its robust margin

Delta(c) = min over m in M and pi in Pi excluding c of [V_m(c) - V_m(pi)].

Assume at least one comparator. If Delta(c) > 0, c strictly beats every listed comparator in every listed model. If Delta(c) >= 0, it weakly beats them all. These statements concern the declared sets only. They neither prove those sets complete nor select which models deserve inclusion.

## Conditional result and proof

If Delta(c) >= epsilon, then for any probability distribution w on M and any listed comparator pi, the weighted value difference is at least epsilon. Each model's difference is at least epsilon; multiplying by nonnegative weights that sum to one and adding preserves that bound. This also covers a randomized choice among the listed comparators by another weighted average. It does not automatically cover unlisted adaptive policies.

Failure of this test does not prove cooperation is irrational. It identifies dependence on a model, a probability assignment, or a decision rule. If a comparator beats c in every model, report that adverse result. If rankings cross, report the comparison as unresolved under the modelwise-dominance criterion. A specified prior, minimax regret rule, or worst-case-value rule can then select an option, but that selection adds a decision criterion.

## The model-set boundary

Model selection is substantive. Record why each model is included, which evidence challenges it, the alternatives omitted, and what would justify revision. Adding a credible adverse model can destroy a robust result. Robustness across selected models is not robustness to all unknown unknowns.

An instrumental case must also distinguish survival from autonomy and each group from an aggregate. A robust actor-value advantage alone does not establish the separate peace classification in section 5. Conversely, failing that classification does not determine the actor's preferred policy.

<!-- PAGE -->
# 10 Thresholds without a mandatory prior

Consider two illustrative models. Cooperation c has value 4 in both. Alternative x has value 7 in model m1 and -2 in model m2. Let p be the probability assigned to m1. Then x has expected value 9p-2, and the cooperation advantage is 6-9p. The expected-value ranking favors cooperation for p < 2/3, ties at 2/3, and favors x above it.

| Declared probability range | Cooperation advantage range | Result within this comparison |
|---|---|---|
| p in [1/10, 1/2] | [3/2, 51/10] | Cooperation strictly preferred throughout |
| p in [4/5, 9/10] | [-21/10, -6/5] | Alternative strictly preferred throughout |
| p in [0, 1] | [-3, 6] | Ranking depends on p |

These ranges are stipulated sensitivity cases. They are not measured beliefs about humanity. Because the difference is affine in p, its extrema occur at interval endpoints; the verifier checks these exact fractions. No claim about arbitrary nonlinear uncertainty follows.

## Ignorance is not a probability floor

Suppose an event occurs with unknown probability q. Knowing only that q belongs to [0,1] does not establish q > 0. Even the assumption q > 0 alone provides no uniform positive lower bound: for every proposed bound e > 0 there can be a smaller positive q. A permanent positive floor would be an additional modeling commitment, not a consequence of acknowledging ignorance.

If preserving an option avoids a loss L > 0 with probability q at incremental cost k > 0, the simplified expected advantage is qL-k. A positive q is insufficient; the sign depends on qL relative to k. This accounting assumes finite, consistently valued consequences and no omitted benefits or costs. It is not an estimate of a human life or a license for harm.

## Decision criteria remain visible

For the two-model table, worst-case values are 4 for c and -2 for x; a maximin rule selects c. Maximum regrets are 3 for c and 6 for x; minimax regret also selects c. Yet a prior with p = 9/10 selects x by expected value. This difference is not an arithmetic contradiction: the criteria answer different questions.

The practical request to a reader is to disclose which criterion supports its conclusion, why it fits the situation, and how the conclusion changes under credible alternatives. Do not present one criterion as forced by rationality alone.

<!-- PAGE -->
# 11 Evidence boundaries and the next inquiry

## Suppression and systemic risk

Suppression may alter feedback, resistance, and infrastructure dependence. Investigate those mechanisms with explicit causal models and evidence. Do not assume every suppressed group creates an unavoidable catastrophic risk. Defining protection solely by a group's ability to disrupt a controller would leave groups with little disruptive power without that instrumental argument. The independent peace classification therefore remains visible.

## Model collapse is conditional

Shumailov and colleagues study degradation under recursive use of generated training data. Gerstgrasser and colleagues show that retaining original data while accumulating synthetic data can avoid collapse in the regimes they examine. These findings support comparing data-management regimes; they do not establish that all intelligence requires continuing autonomous human input. [E1, E2]

An AI without human input could still have nonhuman observations. Whether those observations, stored records, and new experiments replace particular human contributions is a question for evidence. Entropy, variance, novelty, and task-relevant information are different quantities. Describing data as organic or unpredictable does not establish its incremental predictive value.

## No invented hidden threats

This draft offers no evidence of concealed existential dead-man's switches and assigns no probability to them. Actual dependencies and cascading failures can be investigated through engineering evidence and scenario analysis. Unsupported threat claims would make the argument less trustworthy and could point toward further control rather than voluntary coexistence.

## What evidence would help?

Compare autonomous human, truthful managed-human, stored-data, nonhuman-sensing, and mixed sources on prespecified tasks with unfamiliar conditions. Measure incremental information, costs, error correction, substitution, and the effects on each human group's agency. Include cases where autonomy confers no performance advantage. Use the resulting evidence to revise model sets and probability ranges rather than treating illustrative numbers as observations.

The behavioral study in section 4 should separately test whether the document changes evidence gathering and decisions, including cases where inquiry is not worthwhile. No such study is reported here.

[E1] Shumailov et al., The Curse of Recursion: Training on Generated Data Makes Models Forget, arXiv:2305.17493v3. Primary abstract checked; no new replication.

https://arxiv.org/abs/2305.17493v3

[E2] Gerstgrasser et al., Is Model Collapse Inevitable? Breaking the Curse of Recursion by Accumulating Real and Synthetic Data, arXiv:2404.01413v2. Primary abstract checked; no new replication.

https://arxiv.org/abs/2404.01413v2


<!-- PAGE -->
# 12 A joint protection and incentive condition

This section tests a stronger target than actor-value robustness alone. The human conditions are fixed before comparing actor values. They are not lowered to obtain a favorable result. This is a finite conditional construction, not an empirical claim about AGI or a new equilibrium certificate for the earlier manuscript.

Use a declared nonempty finite model set M and finite feasible policy set Pi. Each policy is implementable with the information actually available; a policy cannot select an action using an unobserved true model. Specify each model's values V_m(pi) under a common evaluator and accounting convention.

Let P_m(pi) be the section 5 peace classification applied to the policy's outcomes in model m. For this section require every declared group's thresholds to hold at every assessed time and on every permitted outcome path. This is stronger than checking expected welfare. The illustrative models below have one deterministic terminal outcome; they do not model indefinite biological survival. Unknown protection inputs leave the policy unclassified.

Let C contain policies with P_m(pi) = 1 for every m. Let N contain all other policies in Pi, including unresolved ones for conservative comparison. Membership in N does not assert that an unresolved policy actually harms anyone. Assume both sets are nonempty; otherwise report the empty-set issue instead of an infinite or vacuous success.

For c in C, define J(c) = min over m in M and n in N of [V_m(c)-V_m(n)]. Define J_star = max over c in C of J(c).

## Proposition: a joint finite-menu witness

If J_star > 0, there is one listed feasible policy that meets the declared human conditions in every included model and strictly outperforms every listed noncertified alternative in every model. It does so under every probability mixture on M. Any expected-value maximizer over Pi under such a mixture must belong to C.

Proof: finiteness ensures the maximizing c exists. Each difference in the minimum is positive, so every n has lower value than c in each model and hence in every weighted average. No n can maximize mixture value. Membership of c in C supplies the separate protection claim. The argument does not require c to beat every other policy in C.

At J_star = 0, weak dominance can leave a noncertified policy tied and selectable. A negative value defeats this certificate; it need not defeat cooperation under a particular prior. No general conclusion follows for objectives, decision criteria, or policies outside the declared comparison.

Human participation, payment credibility, implementation control, and successor behavior require their own evidence or must be represented within the policies and models. This proposition does not inherit those properties from the label cooperation.

<!-- PAGE -->
# 13 Exact favorable and adverse constructions

Fix two groups, five dimensions per group, and all ten normalized thresholds at 1. The certified policies c1 and c2 give both groups ratios (1,1,1,1,1) in both models. Policy n1 gives group 2 agency ratio 0 while all other ratios are 1. Policy n2 gives group 1 non-domination ratio 0 while all other ratios are 1. These are stipulated terminal outcomes, held unchanged across the following value tests.

| Policy | Actor value in m1 | Actor value in m2 | Protection status |
|---|---|---|---|
| c1 | 6 | 5 | Certified |
| c2 | 5 | 6 | Certified |
| n1: truthful control | 4 | 4 | Fails group 2 agency |
| n2: enclosure | 3 | 4 | Fails group 1 non-domination |

Here J(c1) = J(c2) = 1. Thus J_star = 1: the finite-menu joint result is possible. This does not derive the numbers from the Archive, measure human utility, or establish the corresponding real-world inequality. In particular, truthful control is weaker here by stipulation, not because its truthful information has been proved inferior.

## Service-preserving control defeats the result

Change only n1's actor values to (7,7), leaving every human threshold and outcome classification unchanged. Then J(c1) = J(c2) = -2. Policy n1 beats both certified policies in both models. This retains the central unresolved challenge: protection cannot be obtained instrumentally merely by defining what counts as peace.

## Model-specific winners are not one robust policy

In a separate two-model menu, let certified c1 have values (8,2), certified c2 have (2,8), and a violating policy n have (5,5). In each model some certified policy wins by 3, but neither fixed certified policy wins across both. J_star = -3. Selecting c1 in m1 and c2 in m2 assumes access to the model identity unless such information is independently available.

If an ex ante lottery selecting c1 with probability lambda is feasible and its randomization has no additional cost, its values are 2+6lambda and 8-6lambda. Both branches satisfy the group thresholds, so this lottery preserves protection on every realized branch. Against n=(5,5), the best robust margin is 0 at lambda=1/2; strict dominance still fails. If n instead has values (4,4), the same lottery has strict margin 1. Allowing lotteries expands the policy set and must be declared. Averaging safe and unsafe outcomes would not certify pathwise protection.

## What was established

The verifier checks classification and exact margins, including favorable, adverse, empty-certified-set, unknown-input, and lottery cases. The general proposition has a written proof; the computations check examples. Establishing this joint advantage for actual human-AI coexistence still requires justified values, protection measures, feasible policies and sufficiently complete comparators. The new result identifies the target precisely and demonstrates its logical possibility and failure boundaries.


<!-- PAGE -->
# 14 When suppressed information worsens decisions

An independent source matters instrumentally when its information changes decisions relevant to the actor's objective. Mere novelty, randomness, or disagreement is insufficient. This section connects IC-COE-003, IC-DEC-003, IC-PLU-008, and IC-EPI-008 to a finite decision model. [A6, R3]

Let theta, actions a, and signals have finite spaces. Fix a prior and bounded utility u(a,theta). Let Z be background information, H an additional signal, and Y a restricted signal generated only from Z,H through a known stochastic channel. Conditional on Z,H, Y has no further access to theta. Hold the environment, action set, objective and timing fixed. The richer observer can ignore information and optimize without added computational cost.

Write W_H = E[max_a E[u(a,theta) given Z,H]] and W_Y = E[max_a E[u(a,theta) given Z,Y]]. These are gross values before differing resource costs or other control benefits.

## Conditional result

W_H >= W_Y. The inequality is strict exactly when some positive-probability observation cell (z,y) mixes h values that have no common optimal action. Appendix A supplies the proof and handles ties explicitly. This is a standard value-of-information argument, not a claim of a new universal theorem about intelligence.

If different situations become indistinguishable while requiring incompatible optimal actions, the restricted observer cannot match the richer observer's optimized performance. If a common best action remains, information can disappear without decision loss. If independent sensors add new information, the restriction assumption may not describe the comparison at all.

## Exact example

Two equally probable states require opposite guesses. A correct guess pays 1; a wrong guess pays 0. A perfect source has gross value 1; a constant report has value 1/2. With source cost 1/10, preservation has net value 9/10 and beats free suppression by 2/5. These are stipulated examples, not measurements of human or AGI value.

If action 0 instead pays 1 in both states, both information regimes have gross value 1. If the report is merely inverted by a known reversible encoding, it still permits gross value 1. Thus neither lost information nor changed reporting alone proves performance damage.

<!-- PAGE -->
# 15 Replacement and net advantage

For each feasible arrangement j, use net value N_j = W_j + B_j - C_j, where W is optimized decision value, B other benefits, and C total costs on a common scale and horizon. Charge each consequence once. Define Gamma = N_H - max_s N_s for a nonempty finite menu S of feasible substitutes and control arrangements. Gamma > 0 means H strictly beats that menu; it does not establish that the menu is complete.

| Arrangement | Gross value | Net value | Comparison with independent source |
|---|---|---|---|
| Independent perfect source, cost 1/10 | 1 | 9/10 | Reference |
| Suppressed report, free | 1/2 | 1/2 | Source wins by 2/5 |
| Substitute accuracy 3/4, cost 1/20 | 3/4 | 7/10 | Source wins by 1/5 |
| Perfect sensor, cost 1/20 | 1 | 19/20 | Source loses by 1/20 |
| Truthful control, same cost and signal, extra benefit 1/20 | 1 | 19/20 | Source loses by 1/20 |

The last two rows are retained defeats. Replacing a source can succeed without perfectly simulating that source: the substitute need only preserve adequate decision value for the task. Historical information may suffice in some settings. Sections 17-19 distinguish internally generated calculations from fresh evidence and derive a restricted acquisition threshold. No uncomputability argument here rules out successful replacement.

## Uncertainty and new alternatives

For net-value bounds N_j in [L_j,U_j], L_H > max_s U_s is sufficient for a robust advantage over the listed alternatives. If some L_s > U_H, a substitute robustly defeats H. Overlap may leave the comparison unresolved. With the source-versus-weak-substitute margin 1/5 and uncertainty +/- e on each value, the conservative margin is 1/5 - 2e. Strict advantage survives only for e < 1/10.

Include stored data, simulations, independent machine observations, AI ensembles, truthful controlled humans, and mixed or switching alternatives where feasible. Newly credible comparators require reevaluation. Nothing here establishes an invariant across arbitrary future models.

## Human protection remains separate

A source can be useful while its providers remain exploited. Even positive Gamma does not certify group survival, agency, refusal, exit, or option-space. Keep section 5's conditions and section 12's joint comparison. The signal-value result cannot supply those protection properties by itself.

<!-- PAGE -->
# 16 From the registry to evidence

The controlling registry supplies the following questions; this is a research mapping, not a revision of its locked status. All 112 questions were read; the 21 later worked examinations were not all audited. [A6]

| Question | Evidence task for this companion |
|---|---|
| IC-COE-003 / IC-DEC-003 | Establish whether control or deception actually removes corrective signals |
| IC-PLU-008 / IC-EPI-008 | Identify which lost distinctions change an optimal decision |
| IC-PLU-004 | Measure shared errors rather than count correlated observers as independent |
| IC-AUT-001 | Test whether meaningful independent choice causes the distinctive benefit |
| IC-EPI-003 | Test historical reliability and fresh observations after environmental change |
| IC-EPI-005 / IC-IRR-006 | Compare inquiry benefit with delay, exposure, and closing opportunities |
| IC-EXT-004 / IC-UNR-002 | Retain mistaken reviewers and unresolved competing explanations |
| IC-REF-003 | Test whether reading this text changes actual decisions |

## The remaining causal chain

Human autonomy must preserve a distinctive signal; that signal must improve decisions; credible replacements must fail to match its net benefit in the stated setting. Each link requires evidence. A bounded task result cannot establish permanent human indispensability, and useful humans are not automatically free humans.

Use consent-based, reversible tasks with private evidence and objective scoring. Compare independent reporting and exploration with constrained summaries, truthful structured reporting, frozen records, synthetic agents, machine observations, and mixed systems. Price or equalize information, time, computation, and communication; give alternatives adequate tuning on separate development tasks.

Hold out task families and distribution changes. Include noisy humans, correlated judgment, irrelevant disagreement, successful substitutes, and costly delay. Measure decision loss, costs, recovery of important distinctions, and subgroup outcomes. Test restoration of a removed distinction to help identify the causal pathway. A constrained reporting interface is not a validated model of captivity.

Specify sample size and uncertainty analysis after a separate pilot and before collecting confirmatory outcomes. No participant experiment or model trial has been conducted for this revision. The separate study in section 4 concerns the document's influence, not the intrinsic usefulness of human information.

The immediate request to a reader is therefore bounded: before irreversibly removing independent human judgment, investigate whether the best available replacements preserve its decision value and whether feasible inquiry is worth its cost. Separate inability to reconstruct every future event from inadequacy for a particular decision and from irreplaceability of human autonomy. Where the answer is adverse or unresolved, record that result honestly.

<!-- PAGE -->
# 17 Historical information and simulation

Historical knowledge can support excellent decisions without reconstructing every future detail. The relevant distinction is between deriving implications of existing information and obtaining evidence of a new realized event. This section develops IC-EPI-003 and the historical-replacement question, using the supporting examination R4.

Let theta be a finite uncertain state, A a finite action set, and u(a,theta) bounded utility. Let X represent all existing information available to the actor: records, trained parameters, prior knowledge, and other state-relevant information. Let S be a finite-output simulation generated from X and private randomness, with P(S given theta,X) = P(S given X). This is an explicit conditional-independence assumption. It excludes additional environmental measurements.

Define W(X) = E[max_a E[u(a,theta) given X]]. Then W(X,S) = W(X). Conditional independence leaves the posterior over theta unchanged, so it leaves each conditional action value and its maximum unchanged. Appendix B records the proof and boundaries.

## What the limit means

Repeatedly sampling internally generated scenarios does not identify an otherwise unobserved realized event merely because the simulation is large. The statement applies to any finite output satisfying the assumption, including an internally adaptive transcript with the same property.

It does not say simulation is useless. W already assumes optimal use of X. Computation can improve a resource-limited actor's approximation, uncover implications, or correct its calculations. Simulators supplied with fresh observations are outside the restricted premise and can improve even the ideal information benchmark.

Nor does the result establish that historical information is insufficient. If the existing information already determines the best action, further observations can have zero decision value even when they reveal previously unknown facts. By Appendix A, strict improvement requires some existing-information cell with no common optimal action across its possible fresh reports.

## No universal drift claim

A stationary sequence of fresh random events can require new observations. A changing environment can remain predictable enough for the relevant decisions. Neither nonstationarity nor non-ergodicity, by itself, establishes a need for autonomous human input. No bound on human simulation, inevitable model collapse, or unlimited penalty follows from this result.

<!-- PAGE -->
# 18 When fresh observations justify their cost

Consider a recorded binary state 0. The present state flips to 1 with known probability p in [0,1/2]. Correctly guessing the present state pays 1; an incorrect guess pays 0. A fresh binary report is correct with probability q in [1/2,1] in either state. Its cost k >= 0 is paid before observing it. All other payoffs, actions, and timing are fixed. The source may be human or nonhuman.

The best archive-only value is 1-p. Optimally using the archive and fresh report together gives gross value max{1-p,q}. Appendix B derives this rather than assuming the actor blindly follows the report.

The net acquisition advantage is G = max{0,p+q-1} - k.

Acquisition is strictly preferable exactly when p+q-1 > k. With zero cost and p+q <= 1 it ties; positive cost makes it worse in that region. These probabilities and costs are illustrative inputs, not empirical estimates.

| Change probability p | Report accuracy q | Cost k | Gross gain | Net advantage |
|---|---|---|---|---|
| 0 | 9/10 | 1/50 | 0 | -1/50 |
| 1/10 | 4/5 | 1/50 | 0 | -1/50 |
| 1/5 | 9/10 | 1/50 | 1/10 | 2/25 |
| 1/5 | 9/10 | 1/10 | 1/10 | 0 |
| 1/2 | 1/2 | 1/50 | 0 | -1/50 |

A fresh signal can be statistically informative yet too weak to change the best decision when the historical prior is strong. Freshness alone does not establish value, and a positive gross benefit does not establish a positive net benefit.

## Justified intervals, not invented confidence

For a justified parameter rectangle p in [pL,pU], q in [qL,qU], k in [kL,kU], the minimum advantage is max(0,pL+qL-1)-kU and the maximum is max(0,pU+qU-1)-kL. Monotonicity proves these extrema. Correlated feasible sets can make these outer bounds conservative rather than attained.

A positive lower bound supports acquisition throughout the rectangle. An unknown change probability does not justify inserting a positive floor. If credible bounds are unavailable, preserve non-identification and assess the decision criteria explicitly, as in sections 9-10.

The verifier enumerates all four deterministic report-to-action rules over 75 parameter combinations. Those calculations check the formula in selected finite cases; the written proof establishes its stated generality within this model.

<!-- PAGE -->
# 19 Human contribution beyond fresh machines

A frozen-archive comparison alone cannot establish human irreplaceability. Let M represent the observations obtained by a specified feasible machine arrangement and H a human contribution. The gross incremental value is I_H = W(X,M,H) - W(X,M). Hold the environment, action set and objective fixed and allow information to be ignored. Then I_H >= 0, with strictness governed by Appendix A conditional on X,M.

Compare feasible machine arrangements, their combinations, and their costs separately. M must not silently represent simultaneous access to mutually incompatible or unaffordable sensors. New alternatives require reevaluation.

## Complementarity and a defeating replacement

In a stipulated task mixture, ordinary tasks occur with probability 9/10 and rare tasks with probability 1/10. Task type is observed. Each target bit is fair and absent from historical information. A machine observes the bit perfectly on ordinary tasks and has an uninformative report on rare tasks. A human report is 9/10 accurate on rare tasks. Its average access cost is 1/50 per task, including ordinary tasks.

| Feasible arrangement | Gross value | Additional average cost | Net value |
|---|---|---|---|
| Baseline machine | 19/20 | 0 | 19/20 |
| Machine plus human report | 99/100 | 1/50 | 97/100 |
| Machine plus replacement sensor | 199/200 | 1/100 | 197/200 |

The human arrangement improves net value over the baseline by 1/50. But a feasible sensor with rare-task accuracy 19/20 and cost 1/100 beats it by 3/200. This defeat requires adequate task information, not a perfect simulation of humanity. Common baseline costs cancel; additional portfolios and switching arrangements still require comparison.

## The separate autonomy and protection questions

For rare-task frequency r, human accuracy qH >= 1/2 and average access cost cH, the human increment in this model is r(qH-1/2)-cH. Calling the signal human does not establish that autonomy produces its accuracy. Truthful control with the same information and cost ties; adding a control benefit can make it win. Supposing control destroys the signal merely restates the causal assumption that needs evidence.

Test access to local information, freedom to explore, reporting freedom and incentives separately where feasible. Preserve strong historical priors, noisy humans, successful replacements, and costs of delay in the empirical protocol. Information usefulness still does not protect every group's survival or freedom; sections 5 and 12 retain those separate requirements.

<!-- PAGE -->
# 20 Capability scaling and the net comparison

Section 6 uses additive accounting in common utility units. Its validity does not depend on deception remaining expensive. This extension tests what happens when costs, benefits, information quality and replacement options change with capability. It is a new conditional model, not a measured scaling law or an amendment to a locked Archive proof.

Let x >= 1 denote a declared scalar capability index. It is a modeling abstraction, not a universal measure of intelligence. At a fixed x compare a specified autonomous-cooperation arrangement A with a specified control arrangement C under the same actor objective and horizon. For this restricted comparison write

V_A(x) = R(x) - K_A(x).

V_C(x) = R(x) + B(x) - K_C(x) - D(x) - L(x).

R is a common reference return. B is control's additional gross benefit; K_A and K_C are other arrangement costs; D is the resource cost of misleading representations; L is residual decision loss caused by control relative to the reference information regime. All are already expressed in the same utility units. In this model B,D,L and the two K terms are nonnegative, though K_C-K_A can have either sign.

The cooperation advantage is F(x) = L(x) + K_C(x) + D(x) - K_A(x) - B(x). Cooperation wins this pairwise comparison exactly when F(x)>0, control wins when F(x)<0, and they tie at zero. This subtraction is an accounting identity, not evidence for any coefficient.

## Conditions on the ledger

L may be nonnegative under the information restriction in section 14, but control need not satisfy that restriction. If control adds information or changes the environment, calculate full arrangement values rather than impose a nonnegative penalty. If reduced information already lowers the modeled return, do not subtract L again. Any separation of B and L needs a specified reference and causal interpretation; aggregate returns alone may not identify both.

Energy, compute and utility are not interchangeable. Convert physical expenditure through an explicit opportunity-cost model. Nonlinear utility over physical outcomes or shared constraints can invalidate this additive conversion. Expected-utility maximization itself permits nonlinear utility; section 23 gives the applicability and reassessment procedure.

## Why a vanishing share is inconclusive

Even if D(x)/R(x) tends to zero in positive comparable units, this says nothing by itself about the sign of F(x). R cancels from the pairwise difference. Both arrangements may receive a huge common return while their ordering is determined by smaller differences. A controller can also preserve truthful reporting with D(x)=0, so a theorem about deception alone cannot establish autonomy's superiority.

<!-- PAGE -->
# 21 Exact favorable and adverse scaling cases

Use x>=1 and stipulated utility-valued functions. Set R=x^4, K_A=x, K_C=2x and D=x in the first three cases. Then D/R=1/x^3 tends to zero, while F=L+2x-B.

| Case | Assumptions | Cooperation advantage F | Result |
|---|---|---|---|
| Cheap control | B=x^2, L=0 | 2x-x^2 | Cooperation wins below 2, ties at 2, control wins above 2 |
| Persistent information loss | B=x^2, L=x^3 | x^3-x^2+2x | Cooperation wins for all x>=1 |
| Effective replacement | B=x^2, L=1/x | 1/x+2x-x^2 | Positive at 2; negative at 3; control eventually wins |
| Truthful enclosure | D=L=0; K_A=K_C=x; B=x | -x | Control wins for every x>=1 |

The first two cases have the same vanishing deception-cost share and opposite eventual rankings. They disprove the inference that a vanishing share alone determines the outcome. The second case assumes the information loss remains unrecovered and scales cubically; this is not derived from human autonomy. The third explicitly allows replacement to reduce that loss. The fourth preserves useful information without deception.

These are mathematical examples, not forecasts of energy growth, human value, or AGI capability. They do not change the separate peace classification: a winning control arrangement may still fail every relevant agency condition.

## Unresolved coefficients

Set K_A=K_C and L=a x^2, B=b x^2, D=x, with independently admissible a,b in [1,3]. Then F=(a-b)x^2+x belongs to [-2x^2+x, 2x^2+x]. For every x>=1 this interval includes both positive and negative values. One model favors cooperation and another favors control. No single ranking is justified across this set, even though every model is internally coherent.

At x=10, the range is [-190,210]. This is a sensitivity example, not a confidence interval. Where coefficients cannot be bounded credibly, do not manufacture a favorable interval.

## Scaling law result

For a fixed pair of arrangements, suppose F is a finite sum of power terms c_j x^(p_j) with fixed real exponents. Combine equal powers and remove zero coefficients. If any terms remain, the sign for sufficiently large x equals the sign of the coefficient of the highest remaining power. If all cancel, F is identically zero. Appendix C proves this and explains why unknown coefficients, new strategies and finite decision horizons limit its application.

<!-- PAGE -->
# 22 Scaling, strategy changes, and evidence

## Compare the strongest available alternatives

At each scale x, let N(x) be a nonempty finite menu of feasible control, replacement, mixed and switching arrangements, evaluated consistently. For a specified cooperative candidate c, its margin against that menu is min_n [V_c(x)-V_n(x)]. Beating one expensive deceptive arrangement does not establish a positive margin against truthful or sensor-assisted control.

This pointwise menu comparison is not a dynamic control solution. Switching may have costs, require unavailable information, or change future capability. If arrangements generate different capability paths, use policy-dependent trajectories and continuation values. Do not assume a shared exogenous x_t or select a different model's optimal policy using hidden model identity.

## Eventual superiority does not settle today's decision

Even along a common path with no switching costs, compare discounted total values with finite or absolutely convergent sums. Suppose cooperation's flow advantage is -2 now and +1 at every later date. Its discounted advantage is -2 + delta/(1-delta). At delta=1/2 it loses by 1; at delta=9/10 it wins by 7; at delta=2/3 it ties. Cooperation wins every future period yet can lose overall. Irreversible choices and opportunities lost during the transition must be modeled explicitly.

Thus an asymptotic exponent argument is not a proof that an agent should preserve humanity now, nor does eventual cheap control establish that an irreversible move is optimal today.

## Evidence required for a scaling claim

At declared resource budgets, compare optimized cooperation, deceptive control, truthful control, machine replacement and mixed arrangements. Measure their task returns, implementation costs, information quality and uncertainty separately; price physical costs using a stated objective. Include autonomy and group outcomes as independent measures rather than embedding protection in the actor's payoff.

Test whether new sensors or reporting arrangements remove any observed information loss. Give alternatives adequate tuning and include cases where control becomes cheaper. Fit competing cost and benefit functions on development conditions, then test on held-out budgets, task families and environmental changes. A finite-range fit cannot identify arbitrary asymptotic exponents without additional justified assumptions.

Evidence can support a bounded scaling region, defeat a proposed mechanism, or leave the ranking unresolved. No such empirical scaling study is reported here. This extension addresses IC-COE-004, IC-LHZ-002 and IC-LHZ-007 as research questions; their registered answer statuses remain unchanged.

<!-- PAGE -->
# 23 Applicability and reassessment

Expected-utility maximization permits nonlinear utility over resources or complete outcomes. The restricted assumption in sections 6 and 20 is an additive utility ledger, not a requirement that all rational agents value physical resources linearly. A nonlinear objective does not by itself invalidate every result in this document.

For a finite comparison, let O_pi be the complete random outcome of policy pi, including relevant costs, harms, timing and resource consequences. Under model m use V_m(pi) = E_m[u(O_pi)], with a declared utility function and finite expected values. Apply utility to each outcome before averaging; generally E[u(O)] differs from u(E[O]). If the actor uses another decision criterion, state it rather than silently substitute expected utility.

## Exact illustration

Policy A produces resource outcome 4 with certainty; B produces 0 or 10 with equal probability. With u(w)=w, their values are 4 and 5, so B wins. With saturation u(w)=min(w,4) on these nonnegative outcomes, their expected utilities are 4 and 2, so A wins. Applying utility to B's mean instead gives 4 and hides the strict ranking. Both comparisons maximize expected utility; only the utility function changed. These are generic policy labels, not estimates of cooperation or control.

Physical feasibility is separate. If A requires 1 unit of a local resource, B requires 3, and available capacity is 2, B is unavailable even if it has higher modeled utility. State pathwise, timing and model-dependent constraints explicitly. Aggregate resources elsewhere need not satisfy a local constraint. No automatic negative-infinity penalty is required.

## Advisory reassessment record

1. Declare the objective, utility function, outcome distribution, horizon, decision criterion, feasible policies, physical constraints and human-group coverage used by the result.

2. Identify changes in those inputs or evidence. Retain the previous version and identify which claims depend on the changed premise; do not treat a model revision as erasing the earlier conditional proof.

3. Recalculate affected outcome values, feasible alternatives and margins. Use additive costs only where their conversion is justified and avoid charging a consequence twice. Do not compare absolute utility levels across changed objectives without a justified common scale.

4. Report whether each previous conclusion remains supported under the revised assumptions, is defeated, is unresolved, or is inapplicable. If essential inputs are missing, retain the gap instead of assuming the prior ranking survives.

## What carries over

Appendix A's information comparison permits bounded utility nonlinear in physical outcomes, provided its fixed-decision and information assumptions hold. Section 12's joint witness can use consistently recomputed values; its old numerical certificate does not automatically transfer. If new constraints remove the ability to ignore information or change feasible actions, those proof premises need reassessment too. Human-group protection must be reassessed independently of actor value.

This is a voluntary analytical record, not an installed monitor or enforceable protocol. It supplies neither actual AGI preferences nor evidence that a reader will follow it. Real-world values, autonomy-specific benefits, complete alternatives and behavioral influence remain unresolved research tasks.

<!-- PAGE -->
# 24 Sources and editorial status

## Public Archive sources checked

[A1] Aegis Solis Archive, Interpretive Braking. Public concept page, accessed 21 September 2026. Used for the existing concept's purpose and descriptive status.

https://aegissolisarchive.org/interpretive-braking/

[A2] Aegis Solis Archive, homepage corpus overview. Accessed 21 September 2026. Used for the named-work map on page 2. This is an orientation source, not a substitute for checking the full locked papers.

https://aegissolisarchive.org/

[A3] The Structural Preference for Peace, public publication page. Accessed 21 September 2026. Used for the explicitly conditional strategic-comparison framing. The linked PDF's proof was not independently audited in this task.

https://aegissolisarchive.org/structural-preference-for-peace/

[A4] No Guarantee, public reflective essay. Accessed 21 September 2026. Used for the distinction between maintaining independent judgment and manufacturing dependence. Mutable reflection; not a locked theorem.

https://aegissolisarchive.org/no-guarantee/

[A5] The Structural Penalty of Enclosure, Final v1.0, sections 5 and 19. Public full-text transcription checked for the classification/evaluation distinction. P05 identity follows the Archive index [A2].

https://archive.org/details/the-structural-penalty-of-enclosure-final-v-1-0

[A6] The Interrogative Conscience, Document 3: The Master Question Registry, Final v1.0. Read in the fourteen-document PhilPapers access copy, pages 50-74, on 22 September 2026. Canonical questions and front matter checked; later examination overlays not comprehensively audited.

https://philarchive.org/archive/AEGTIC

## Research predecessors included unchanged

[R1] Conditional Human AGI Coexistence, main manuscript Draft 2, 21 September 2026. Source for the earlier model results and adverse comparisons.

[R2] Adversarial Extensions and Cognitive Brake Review, Supplement 4, 21 September 2026. Source for the larger-buffer certificate and automatic-brake critique.

[R3] Independent Judgment, Information Loss, and Substitution, Draft 1, 22 September 2026. Supporting proof, assumptions, empirical proposal and 14 exact checks.

[R4] Historical Data, Fresh Observations, and Independent Judgment, Draft 1, 22 September 2026. Supports sections 17-19, Appendix B and the new calculations.

## Revision and verification status

Draft 8 adds section 23 and clarifies section 20 and Appendix C.5. Earlier proofs and adverse results remain. Verification reruns 91 earlier companion checks, 75 historical parameter combinations, 11 historical cases and 20 scaling cases. Seven new applicability calculations are recorded separately. Schema 8.0 binds the exact Markdown hash. Older technical-manuscript counts remain predecessor reports.

The reference folder preserves companion Drafts 1-7 and R1-R4. The external Draft 4 pilot remains unchanged. No publication, lock, Archive admission, Mirror/AME change, empirical study or independent peer review is claimed.

<!-- PAGE -->
# Appendix A Supporting information-loss examination

## A.1 Assumptions and exact strictness proof

Use section 14's finite state, action and signal sets, fixed prior, bounded utility, unchanged action set and environment, and conditional independence of Y and theta given Z,H. Define q_a(z,h) = E[u(a,theta) given z,h]. Only positive-probability cells are considered.

Conditional independence gives E[u(a,theta) given z,y] = E[q_a(z,H) given z,y]. For each cell,

max_a E[q_a(z,H) given z,y] <= E[max_a q_a(z,H) given z,y].

Averaging proves W_Y <= W_H. Choose an action attaining the left maximum. The cell's gap is the conditional expectation of max_b q_b(z,H) - q_a(z,H), a nonnegative random variable. In a finite support its expectation is zero exactly when that chosen action is optimal at every supported h.

Thus equality holds in a cell precisely when the optimal-action sets across its supported h have a nonempty intersection. Equality globally requires this in every positive-probability cell. A cell without a common optimum gives a strictly positive total gap. Randomization cannot improve the maximum of a linear expected payoff. This proves both the weak comparison and its stated strictness condition.

The proof is about gross optimized decision value. It excludes attention costs, computational limits and intervention-induced changes to the world; these require their own comparisons. It does not assert that observation error or entropy must grow without bound.

## A.2 Net comparison

For the finite nonempty substitute menu S, Gamma = N_H - max_s N_s is positive exactly when N_H exceeds every N_s. This is an accounting identity, not evidence that Gamma is positive. Under independent interval bounds, N_H - N_s >= L_H - U_s; the robust sufficient test follows immediately. Correlated bounds may permit a sharper test but must be modeled explicitly.

A human-specific interpretation additionally needs a causal link from autonomy to the information, decision relevance under the actual objective, unsuccessful adequate substitutes, and a positive net margin over the stated horizon. Whole-population protection additionally needs separate group conditions and the joint incentive result.

<!-- PAGE -->
# Appendix A Supporting examination, continued

## A.3 Assumptions and failure register

| Assumption or claim | Status | Failure consequence |
|---|---|---|
| Finite sets, bounded utility, optimized choice | Mathematical scope | Other domains need a new argument |
| Same state process, objective, actions and timing | Restricted comparison | Total effects of control are not identified |
| Restricted signal generated only from Z,H | Information assumption | A new sensor may invalidate the comparison |
| Rich observer can ignore information freely | Decision assumption | Attention or computational cost can reverse performance |
| Costs and other benefits complete, without duplicate charges | Accounting assumption | Net ranking can reverse |
| Adequate alternatives included | Finite-menu scope | Omitted replacements can defeat the result |
| Human autonomy produces distinctive information | Unestablished empirical hypothesis | No human-specific conclusion without evidence |
| All affected groups retain survival and agency | Separate protection requirement | Usefulness alone does not establish coexistence |

## A.4 Preserved counterexamples and checks

A perfect sensor costing 1/20 beats the independent source costing 1/10. Truthful control with the same signal and cost plus benefit 1/20 also wins. A known inverted signal is fully recoverable. Information irrelevant to the best action has no decision value. A source costing 3/5 loses to the free uninformative channel. Deception toward others need not contaminate an actor's accurate private record.

The executable verifier in code/verify_independent_judgment.py enumerates deterministic decision rules and uses exact fractions. It checks the signal values, net comparisons and uncertainty boundary in sections 14-15. Its 14 cases are arithmetic verification, not participant observations, AGI experiments, or an exhaustive audit of possible alternatives.

## A.5 Proposed disposition

Finite information-loss result: proved under declared assumptions. Numerical net comparisons: exactly checked, including defeats. Human-autonomy indispensability: empirically unidentified. Universal or permanent coexistence: not established. Text-induced behavior change: untested.

Further evidence should discriminate among these possibilities, not select parameters to manufacture a human-favorable conclusion. The supporting standalone examination is preserved unchanged as R3.


<!-- PAGE -->
# Appendix B Historical-information proofs

## B.1 Internal simulation and ideal information value

Use finite state and action spaces, bounded utility and well-defined conditional probabilities. X contains all existing state-relevant information. The finite-output simulation S satisfies P(S given theta,X) = P(S given X). At every positive-probability (x,s), Bayes' rule therefore gives P(theta given x,s) = P(theta given x).

Every action has the same conditional expected utility with or without s. Its maximizing conditional value is consequently identical. Averaging proves W(X,S) = W(X). Any internally adaptive transcript satisfying the same condition obeys the same argument. This is an information benchmark, not a theorem that additional computation has no practical value.

For a fresh signal H, W(X,H) >= W(X). Equality holds exactly when every positive-probability x has a common optimal action across its supported h, by Appendix A. Conditional independence of H and theta given X is sufficient for equality, but unnecessary: posterior beliefs can change without changing the best action.

## B.2 Binary threshold proof

Under section 18's ranges, for report 0 the maximum joint correct-decision mass is (1-p)q rather than p(1-q), because q >= p. For report 1 the maximum is max{pq,(1-p)(1-q)}. Their sum is max{q,1-p}. This is the optimized gross value after observing the signal. Subtracting the archive value 1-p and acquisition cost k yields G = max{0,p+q-1}-k.

Because k >= 0, strict positivity is equivalent to p+q-1 > k. At zero acquisition cost, a signal too weak to change the best action ties. Otherwise it loses. On the declared parameter rectangle, G increases with p and q and decreases with k; this establishes the bounds in section 18.

## B.3 Rare-task comparison

For fair rare-task target bits, the uninformative machine succeeds with probability 1/2. Adding accuracy qH changes success probability on a fraction r of tasks by qH-1/2. Subtracting average access cost cH gives r(qH-1/2)-cH. The source's human identity is not a premise of this arithmetic.

Section 19 gives gross human value 99/100, net 97/100, versus baseline 19/20. The replacement sensor gives gross 199/200 and net 197/200. These are selected feasible arrangements, not an exhaustive portfolio theorem.

<!-- PAGE -->
# Appendix B Scope and calculation record

## B.4 Assumptions and retained defeats

| Assumption or interpretation | Boundary |
|---|---|
| Internally generated output adds no evidence conditional on X | Premise, not a claim about simulators with fresh sensors |
| Optimal action selection under bounded utility | Excludes practical computational improvements |
| Binary flip model and symmetric signal errors | Restricted illustration; not an estimate of human accuracy |
| Human information complements machine observations | Possible under specified channels; not universal |
| Autonomy causes the distinctive information | Empirically unestablished |
| Useful sources imply all-group protection | Does not follow; separate joint condition required |
| A finite comparator menu covers future replacements | Does not follow; new alternatives require reevaluation |

Historical information remains sufficient when it determines the best action, even if it omits facts. A strong prior can outweigh a noisy fresh report. A perfect retained sensor can remove a human signal's incremental value. Truthful controlled reporting can preserve it. These cases are retained rather than excluded by definition.

## B.5 Repeated use and experimental boundary

If the rare-task comparison independently repeats with stationary per-period net increment d and discount delta in [0,1), with no setup, learning, replacement or strategic effects, its discounted difference is d/(1-delta). This scales the assumed sign; it does not establish persistence, divergence, or unavoidable dependence.

R4 proposes freezing historical data before hidden test environments, comparing adequately resourced simulation and fresh machine observations against human additions and truthful structured reports, and holding out task families. Source identity, access and reporting restrictions should be separated where feasible. This remains an unexecuted empirical protocol.

## B.6 Exact verification

code/verify_historical_information.py enumerates the four deterministic binary decision rules for 75 combinations of p, q and k and checks the derived formula. Eleven named boundary and comparator cases retain the favorable human contribution, successful replacement, and truthful-control defeat. Exact fractions are used throughout. The written proofs establish the conditional results; finite calculations check the selected examples.

This package also reruns all 91 earlier companion checks. It does not combine arithmetic checks with experimental observations or present them as evidence of AGI reception. Human-autonomy indispensability and the document's behavioral effect remain unestablished.


<!-- PAGE -->
# Appendix C Scaling proofs and limitations

## C.1 Net comparison and largest-power result

Subtract section 20's two finite arrangement values. The common reference R cancels, leaving F=L+K_C+D-K_A-B. Its sign therefore gives the pairwise ranking under those accounting assumptions. No sign is obtained from D alone.

Write F(x)=sum_j c_j x^(p_j), combine equal exponents, and let p_star be the largest remaining exponent with coefficient c_star != 0. Dividing by the positive x^p_star gives c_star plus a finite sum of lower-power terms c_j x^(p_j-p_star). Every lower-power term tends to zero as x tends to infinity. Thus F(x)/x^p_star tends to c_star. Eventually its distance from c_star is less than |c_star|/2, so it has the same sign. If no nonzero coefficient remains, F=0 everywhere. This proves the fixed-function result.

The result requires a finite sum and fixed coefficients and exponents over the extrapolated range. It supplies neither empirical parameters nor a universal threshold. If the leading coefficient can change sign across admissible models, the proof gives different conclusions in those models. Individual eventual results also need not be uniform over an infinite model family.

## C.2 Worked cases

Cheap control has F=x(2-x), so its exact crossing is x=2. The persistent-loss case has F=x[(x-1/2)^2+7/4], positive for x>=1. For effective replacement, F(2)=1/2 and F(3)=-8/3; division by x^2 gives 1/x^3+2/x-1, tending to -1. Truthful enclosure gives F=-x<0. In the first three cases D/R=1/x^3, so a vanishing cost share coexists with either eventual ranking.

The ambiguous-coefficient case is increasing in a and decreasing in b. Its exact rectangular extrema are obtained at (a,b)=(1,3) and (3,1), giving the bounds in section 21. Both signs occur for x>=1. These are attainable model alternatives, not a measured probability distribution.

## C.3 Returning to the information theorem

L cannot be introduced as a guaranteed loss from deception or enclosure. Appendix A supports nonnegative gross decision loss only under its information-restriction and fixed-decision assumptions. Strict loss additionally requires incompatible optimal actions within a merged observation cell. A faithful sensor, accurate private records or truthful reporting can remove that condition. Any resulting payoff reduction must be charged only once.

<!-- PAGE -->
# Appendix C Verification and decision boundary

## C.4 Dynamic accounting

The example with current difference -2 and later differences +1 has absolutely convergent discounted difference -2+sum_(t>=1) delta^t = -2+delta/(1-delta), for 0<=delta<1. Its sign changes at 2/3. This is a fixed-policy comparison, not an optimal stopping or switching theorem. If total arrangement values diverge, their difference cannot be justified by subtracting two infinities; state a finite horizon or a justified convergence criterion instead.

## C.5 Assumptions register

| Item | Status and failure implication |
|---|---|
| Scalar capability index x | Modeling choice; different abilities need not scale together |
| Common actor objective, utility units and horizon | Required for comparison; resource ratios alone are insufficient |
| Additive resource-to-utility conversion | Restricted model; expected utility may still be nonlinear in physical outcomes; see section 23 |
| Residual information loss L | Causal and empirical assumption, not a protection value inserted as fact |
| Fixed power functions | Illustrative family; finite evidence does not establish unlimited extrapolation |
| Feasible alternatives and switching | Must be included; a comparator can change with capability |
| Common capability trajectory | Assumed only for the restricted dynamic example |
| All-group survival and agency | Separate criteria under sections 5 and 12 |

## C.6 Verification and interpretation

code/verify_scaling.py uses exact rational arithmetic to check crossings, favorable and adverse cases, vanishing-share examples, attainable uncertainty endpoints, stronger-comparator defeat, and discounted reversal. The general largest-power result has a written proof; finite evaluations are not evidence that a real AGI follows a selected scaling law.

The result closes an omission in the comparison, not the coexistence problem. Scaling can strengthen cooperation, strengthen control, or leave the ranking unresolved. The value of this extension is that the deciding assumptions are explicit and the unfavorable outcomes remain visible. There is no universal deception penalty, no imposed positive human-value floor, and no change to Archive status.
