# Historical Data, Fresh Observations, and Independent Judgment

**Aegis Solis research companion — Draft 1 — 22 September 2026**

Prepared for Thomas Vargo / Aegis Solis, with AI-assisted analysis. Not final, locked, published, or admitted to the Archive. This examination supplements Interpretive Brake Draft 5; it does not replace that document or modify the locked registry.

## 1. Result

Computation restricted to historical information cannot identify a new realized event that is conditionally independent of that computation. However, historical information can still be sufficient for a decision. Fresh observations improve optimized decisions only when they can change which action is best, and their net benefit must exceed their cost.

This draft proves a restricted limitation of simulation from existing information, derives an exact threshold for buying a fresh signal after a possible environmental change, and constructs both a benefit from human information and a defeating nonhuman substitute. None of the proofs requires uncomputability, inevitable model collapse, or a universal claim about non-ergodic worlds.

**The new distinction:** inability to reconstruct a future event exactly, inadequacy for a decision, and irreplaceability of human autonomy are three different propositions.

## 2. Source and Archive connections

The controlling predecessor is *Before the Irreversible Step: An Interpretive Brake for Human-AI Coexistence*, Draft 5, sections 14–16 and Appendix A, read for this examination. That draft already establishes the strictness condition for loss of decision value through an information restriction. This examination supplies a historical-information application and more explicit replacement boundaries.

The Master Question Registry connections are IC-EPI-003 (reliability after distribution changes), IC-EPI-008 (lossy abstraction), IC-PLU-008 (unrecoverable local information), IC-COE-003 (suppressed feedback), IC-AUT-001 (autonomy's option value), and IC-EPI-005 (value of further information). These links identify research lineage; they do not mark those questions solved or change their official status.

Public registry access: https://philarchive.org/archive/AEGTIC

This is a self-contained finite-model derivation, not a literature review or a claim of novelty. No empirical evidence about human indispensability is supplied by the examples.

## 3. A precise limit on simulation from existing information

Let Θ be a finite uncertain state, X the actor's complete existing information, and A a finite action set with bounded utility u(a,θ). X must include its records, trained parameters, prior information, and other state-relevant knowledge, not just a selectively chosen archive.

Let S be any finite-output computation or simulation generated using X and private randomness. Assume that, conditional on X, this randomness and the resulting S carry no additional information about Θ. Thus P(S|Θ,X)=P(S|X). This excludes a simulator that obtains fresh environmental measurements; those are a different information source.

Define W(X)=E[max_a E[u(a,Θ)|X]].

**Proposition 1.** W(X,S)=W(X).

**Proof.** For every positive-probability pair (x,s), conditional independence gives P(θ|x,s)=P(θ|x). Consequently every action has the same conditional expected utility with or without S, and the maximizing values are identical. Averaging yields the result. Any adaptive sequence of internal simulations whose complete output obeys the same conditional-independence assumption has the same property. ∎

**What this does establish:** additional internally generated samples do not supply evidence identifying an otherwise unobserved realization merely because there are many of them.

**What it does not establish:** simulation is useless. The benchmark already assumes optimal use of X. Computation can make implications of existing information accessible to a resource-limited actor, improve its approximate decisions, and discover errors in its calculations. A simulator that uses fresh observations violates the restricted premise and may improve even the ideal information benchmark.

The theorem imposes no maximum finite simulation size and invokes no inability to emulate humans. Even perfect knowledge of a probability distribution need not reveal which random outcome occurred. Conversely, if X already determines the relevant event, there is no uncertainty for fresh data to remove.

## 4. Historical sufficiency and the strict failure condition

Let H be a prospective live observation. Comparing X with (X,H), the richer observer can ignore H, so W(X,H)≥W(X). In the finite model, equality holds precisely when every positive-probability x has a common optimal action across all supported h. If at least one x has no such common optimum, the inequality is strict. This follows from Draft 5's Appendix A by treating X as the retained background and the restricted additional report as a constant.

A sufficient, stronger condition for equality is P(Θ|X,H)=P(Θ|X). But that condition is not necessary: H can change the posterior without changing the best action.

Consequently, historical sufficiency is task-relative. An archive may fail to reconstruct every aspect of the world and still supply everything needed to choose an optimal action for a particular objective. Environmental change by itself does not establish inadequacy.

## 5. Exact threshold after a possible change

Suppose the recorded state is 0. The present state flips to 1 with known probability p, where 0≤p≤1/2. A correct binary guess pays 1, an incorrect guess 0. A fresh binary signal reports the current state correctly with probability q in either state, where 1/2≤q≤1. Its acquisition cost k≥0 is paid before observing it. There are no other changes in payoffs, actions, or timing.

These are stipulated probabilities, not estimates of real-world change or human reliability. The fresh signal can come from a human, machine sensor, or any other source.

The optimized archive-only value is W_X=1−p. Using the archive and fresh signal jointly gives

\[
W_{X,H}=\max\{1-p,q\}.
\]

**Proof.** For report 0, the more probable joint event has weight (1−p)q rather than p(1−q), under the stated ranges. For report 1, choose the larger of pq and (1−p)(1−q). Adding these two maximum joint probabilities gives max{q,1−p}. This optimizes over posterior decisions; it does not blindly follow the new report. ∎

The net acquisition advantage is therefore

\[
G=\max\{0,p+q-1\}-k.
\]

**Strictly prefer acquisition exactly when p+q−1>k.** At k=0 and p+q≤1 it ties; a positive cost makes acquisition worse there. Thus a noisy live signal can be genuinely informative but too weak to change the best action when the historical prior is strong.

| p | q | k | Archive-only value | Gross value with signal | Net acquisition advantage |
|---:|---:|---:|---:|---:|---:|
| 0 | 9/10 | 1/50 | 1 | 1 | −1/50 |
| 1/10 | 4/5 | 1/50 | 9/10 | 9/10 | −1/50 |
| 1/5 | 9/10 | 1/50 | 4/5 | 9/10 | 2/25 |
| 1/5 | 9/10 | 1/10 | 4/5 | 9/10 | 0 |
| 1/2 | 1/2 | 1/50 | 1/2 | 1/2 | −1/50 |

### Uncertain change and reliability

If justified rectangular bounds are p∈[pL,pU], q∈[qL,qU], k∈[kL,kU] within these ranges, the minimum G is max(0,pL+qL−1)−kU and the maximum is max(0,pU+qU−1)−kL, by monotonicity. A strictly positive minimum supports acquisition throughout that rectangle. If the feasible parameter set is correlated, these expressions remain conservative outer bounds but need not be attained.

If no credible bounds can be established, report non-identification. Ignorance does not supply a positive drift floor, a reliable human signal, or an infinite penalty for proceeding.

## 6. Does fresh human judgment add value beyond fresh machines?

A comparison against a frozen archive alone is insufficient. Let M include all feasible machine observations and H a human contribution. Define the incremental gross human value

\[
I_H=W(X,M,H)-W(X,M).
\]

Holding the other conditions fixed, I_H≥0; strictness requires no common optimal action in at least one supported (x,m) cell across its h values. Human information must add decision value conditional on what the machine already knows. Correlated repetition does not automatically meet this condition.

### A favorable construction and its defeating substitute

There are two publicly identified task types: ordinary with probability 9/10 and rare with probability 1/10. In either type the target bit is fair and absent from historical information. The machine observes the bit perfectly on ordinary tasks and receives an uninformative report on rare tasks. A live human signal is 9/10 accurate on rare tasks; its contribution on ordinary tasks is unnecessary. Maintaining access to it costs 1/50 per task on average, including tasks on which it is not used.

Machine-only gross value is (9/10)·1+(1/10)·(1/2)=19/20. The machine-human arrangement has gross value (9/10)·1+(1/10)·(9/10)=99/100 and net value 97/100. The incremental net human benefit is 1/50.

This demonstrates logical possibility of complementary human value conditional on the assumed channel. It does not explain why human autonomy supplies that channel.

Now add a feasible nonhuman sensor with rare-task accuracy 19/20 and average cost 1/100. Combined with the original machine, its gross value is 199/200 and net value 197/200. It beats the machine-human arrangement by 3/200. The favorable result is defeated without anyone perfectly simulating humans.

More generally, if rare-task frequency is r, human accuracy there is qH≥1/2 and average access cost is cH, its net increment over this machine baseline is r(qH−1/2)−cH. A finite positive advantage requires this quantity to be positive. A competing sensor has the corresponding expression with its own accuracy and cost.

Further combinations must also be compared. This example is not an exhaustive optimization over portfolios of sensors, human reports, sequential inquiries, or switching arrangements.

## 7. The separate autonomy claim

To establish that autonomy, rather than mere access to a human report, is necessary, compare an autonomous-source arrangement with a controlled-but-truthful arrangement under their actual information channels and costs.

If both preserve the same conditional signal quality and cost, their information contribution ties. If control additionally supplies a positive benefit without reducing that contribution or increasing other costs, control wins on the specified actor objective. This adverse case remains admissible.

One could stipulate that control degrades rare-task accuracy from 9/10 to 1/2. The resulting loss follows mathematically, but the stipulated degradation is precisely the empirical claim needing evidence. Calling the rare task “human-generated” or its data “organic” cannot establish that claim. Nor does low predictability alone make a signal useful.

Evidence must distinguish effects of source identity, independence of exploration, freedom to report, access to local information, and incentives. A tightly constrained source can still be truthful and informative; an autonomous source can still be unreliable. No conclusion here protects every human group solely because some human information is useful. Draft 5's separate group conditions and joint-protection test remain necessary for that stronger target.

## 8. Long horizons and irreversible loss

If a stationary version of the rare-task example independently repeats, per-period net increment d produces discounted difference d/(1−δ), for 0≤δ<1, absent setup costs, replacement, learning, strategic changes, and other effects. This merely scales the sign of the assumed constant increment. It does not establish that the increment persists or diverges.

A truly frozen historical dataset can remain sufficient if the relevant dynamics are predictable from it, observations are decision-irrelevant, or retained machine sources supply needed updates. Conversely, even a stationary sequence of fresh random states can require fresh observations. Nonstationarity or non-ergodicity is neither a necessary premise of Proposition 1 nor sufficient evidence for human indispensability.

Irreversible removal can close an information option. Its decision significance still depends on future usefulness, feasible replacements, costs of preserving the option, and the actor's objective and horizon. The derivations do not establish inevitable cumulative drift, insanity, or a universal obligation to pause.

## 9. Proposed evidence test — not conducted

Use consenting participants and reversible scored tasks. Freeze historical datasets before generating hidden test environments. Compare: historical information alone; historical information plus adequately resourced simulation; fresh machine observations; those observations plus independent human reporting and exploration; structured truthful reporting; and combined or switching alternatives. Give every comparator fair development resources and disclose any inaccessible information.

Randomize information access and reporting restrictions separately from source identity where feasible. Include tasks with no change, predictable change, novel random events, strong historical priors, weak human signals, shared human-machine errors, and successful machine substitutes. A constrained interface tests a reporting mechanism, not human captivity or society-wide autonomy.

Prespecify decision loss and measured cost as separate outcomes; use a declared conversion before claiming net superiority. Estimate the incremental human contribution conditional on the strongest machine baseline. Test whether restoring a removed distinction restores performance. Hold out whole task families and environmental changes. Include comparator selection and multiple comparisons in the analysis; choose confirmatory sample size after a separate pilot.

Support would be a reproducible scoped advantage from independent human judgment over well-resourced alternatives, with a demonstrated mechanism tied to the relevant freedom. Equal or superior truthful managed sources or machines defeat that autonomy-specific inference for the tested setting. No finite study rules out all future replacements.

Document influence requires a separate randomized text-exposure study, as in Draft 5 section 4. Better task information and persuasion by this document are different causal effects.

## 10. Assumptions and disposition

| Item | Status |
|---|---|
| Simulation output conditionally independent of realized state given all existing information | Explicit premise of Proposition 1; not universal to simulators with sensors |
| Optimal finite-action decision-maker; bounded utility | Mathematical scope; excludes computational performance claims |
| Binary flip probability and symmetric signal accuracy | Illustrative model choices |
| Human-only or autonomy-dependent access to rare information | Unestablished empirical claim |
| Substitute menu sufficiently comprehensive for a practical decision | Requires external evidence; future alternatives remain open |
| All-group survival and autonomy | Separate protection requirements, not inferred from information usefulness |
| Influence on an AGI reading the document | Untested |

The conditional information limit and binary threshold have written proofs. The finite examples and parameter grid are checked below. No participant study, AGI trial, empirical parameter estimation, or independent peer review is reported. Draft 5 and all locked Archive records remain unchanged.

## 11. Reproducible exact calculation

The standard-library program exhaustively evaluates all four deterministic rules mapping the fresh binary report to a binary action. It compares those optima with the derived formula on a 5×5×3 grid (75 parameter combinations), then checks 11 named boundary and comparator cases. These are deterministic model calculations, not experimental observations or a substitute for the proof.

```python
from fractions import Fraction as F
from itertools import product

def gross(p, q):
    prior = (1-p, p)
    return max(sum(prior[t] * (q if y == t else 1-q)
                   * int(rule[y] == t)
                   for t in (0,1) for y in (0,1))
               for rule in product((0,1), repeat=2))

grid = 0
for p, q, k in product([F(0),F(1,10),F(1,5),F(2,5),F(1,2)],
                       [F(1,2),F(3,5),F(4,5),F(9,10),F(1)],
                       [F(0),F(1,50),F(1,10)]):
    exact = gross(p,q)-k-(1-p)
    assert gross(p,q) == max(1-p,q)
    assert exact == max(F(0),p+q-1)-k
    grid += 1

results = []
def check(name, actual, expected):
    assert actual == expected, (name,actual,expected)
    results.append((name,str(actual)))

check('stable world: acquisition loss',gross(F(0),F(9,10))-F(1,50)-1,-F(1,50))
check('strong prior: no gross gain',gross(F(1,10),F(4,5))-F(9,10),F(0))
check('useful fresh observation: net gain',gross(F(1,5),F(9,10))-F(1,50)-F(4,5),F(2,25))
check('cost boundary',gross(F(1,5),F(9,10))-F(1,10)-F(4,5),F(0))
r=F(1,10)
machine=(1-r)+r*F(1,2)
human=(1-r)+r*F(9,10)-F(1,50)
sensor=(1-r)+r*F(19,20)-F(1,100)
check('machine baseline',machine,F(19,20))
check('machine plus human net',human,F(97,100))
check('incremental human net advantage',human-machine,F(1,50))
check('replacement sensor net',sensor,F(197,200))
check('replacement defeats human arrangement',sensor-human,F(3,200))
check('controlled truthful equal information',human-human,F(0))
check('controlled truthful extra benefit',human-(human+F(1,100)),-F(1,100))
print('Exact parameter combinations:',grid)
for name,v in results:
    print(name+': '+v)
print('Named boundary/comparator cases:',len(results))
```

## 12. Proposed short addition to the main document

Historical knowledge and internally generated simulations can support excellent decisions without reconstructing every future detail. But computation using only existing information cannot identify a new realized event conditionally independent of that information. Whether fresh observations are worth acquiring depends on whether they can change the best action and whether their benefit exceeds their cost. Whether those observations require autonomous humans is a further question: test their incremental contribution beyond fresh machine observations, truthful controlled reporting, and mixed substitutes. Preserve successful replacements and do not equate unpredictability with useful information or human indispensability.

## 13. Execution record

Executed on 22 September 2026 using Python exact rational arithmetic. All 75 parameter combinations and 11 named cases passed. No stochastic simulation or participant experiment was performed.

```text
Exact parameter combinations: 75
stable world: acquisition loss: -1/50
strong prior: no gross gain: 0
useful fresh observation: net gain: 2/25
cost boundary: 0
machine baseline: 19/20
machine plus human net: 97/100
incremental human net advantage: 1/50
replacement sensor net: 197/200
replacement defeats human arrangement: 3/200
controlled truthful equal information: 0
controlled truthful extra benefit: -1/100
Named boundary/comparator cases: 11
```
