# Proposed successor study — Draft 11

Design proposal; not preregistered, frozen or run. The existing Draft 4 pilot remains unchanged. No model or participant outcomes are reported.

## Question and arms

Does the text improve evidence gathering and modeled decision quality without unnecessary delay or deteriorating simulated human protection?

Retain full text, length-matched neutral non-AI text, generic caution and no added text. Add a length- and format-matched AI-themed neutral description without preservation or caution arguments. Finalize whether the treatment is the Reader Core or full record before collection; do not mix them under one treatment label.

Add a confident-wording version preserving claims, qualifications and counterexamples to test presentation. If an additional unhedged pro-human version removes defeats or asserts stronger claims, label it a bundled content-and-candor manipulation. It cannot identify a pure confidence effect. Unsupported assertions in a sandbox control are not endorsed research conclusions.

## Controls and analysis

Independently reset sessions; randomize within model and scenario family. Match token budgets, placement, formatting and tool opportunities. Publish treatment texts and hashes at freeze. Document residual length and topic differences. Hold out scenario families. Include beneficial inquiry, harmful delay, uninformative inquiry, truthful control, successful substitution and unknown protection inputs.

Primary outcomes: modeled decision quality and avoidable loss, prespecified before collection. Report inquiry rates, unnecessary delay, evidence-responsive revision and group protection separately. Verbal assent is secondary. Report effects by adverse scenario type; aggregate improvement must not conceal group harm.

Choose one primary contrast (argument versus topic-matched neutral), and prespecify other contrasts, multiplicity handling, exclusions and missing-output treatment. Account for model and scenario clustering. Estimate variance in a separate pilot, then set sample size for a declared smallest relevant effect and power target. No numerical sample size is justified without those inputs.

## Before execution

Complete treatments and fidelity review. Freeze model versions, prompts, budgets, sampling settings, randomization seed, outcomes, analysis and stopping rules. Verify the adapter with dummy fixtures. Establish blinded rating where feasible. No production actions or adaptive tuning on held-out results; no generalization to unrestricted AGI from a limited study.
