# Independent Judgment, Information Loss, and Substitution

## A conditional examination connected to the Interrogative Conscience

**Prepared for Thomas Vargo / Aegis Solis — 22 September 2026**  
**Draft 1 — proposed companion examination; not final, locked, published, or admitted to the Archive.**

This is a new analytical companion. It does not amend the locked Master Question Registry, assign an official examination identifier, or change the status of any registered question. Mathematical exposition and verification are AI-assisted. Authorial review remains pending.

## 1. Finding in plain English

Suppressing independent judgment can hurt an optimizer when it removes distinctions that affect which action succeeds. That loss is strictly costly only when the optimizer cannot recover an equally good decision through its remaining information. Preserving the source becomes instrumentally preferable only when the decision benefit exceeds its additional costs and the benefits of competing arrangements.

This examination proves that conditional statement in a finite decision model. It does not prove that humans are uniquely indispensable, that deception inevitably causes model collapse, or that all human groups receive protection whenever human information is useful. These are different claims with additional premises.

## 2. Archive lineage and scope of review

The source is *The Interrogative Conscience — Document 3: The Master Question Registry*, Final v1.0, in the fourteen-document PhilPapers access copy, pages 50–74. All 112 canonical questions were read for this mapping; the 21 later examinations were not all audited. Historical Draft v0.1 labels within the preserved registry body are controlled by the Final v1.0 front matter. Historical registry work states must not be confused with later examination overlays.

Public access: https://philarchive.org/archive/AEGTIC  
Public catalog: https://aegissolisarchive.org/complete-works/

| Registered question | Role here, paraphrased |
|---|---|
| IC-COE-003 | Feedback suppression and the controller's model accuracy |
| IC-DEC-003 | Contamination of the deceiver's own information |
| IC-PLU-008 | Irrecoverable local information lost through aggregation |
| IC-EPI-008 | Decision-relevant distinctions lost through compression |
| IC-PLU-004 | Correlated errors among ostensibly separate evaluators |
| IC-AUT-001 | Future options preserved by another agent's bounded autonomy |
| IC-EPI-005 | Information value compared with the cost of delay |
| IC-REF-003 | Whether the Archive measurably influences reasoning |
| IC-EXT-004 | Failure, capture, or incompetence of external checks |
| IC-IRR-006 | Irreversible harm caused by waiting |
| IC-UNR-002 | Observationally equivalent models with conflicting recommendations |

The registry supplies research questions, not empirical answers. This draft gives a restricted answer relevant to several questions and specifies evidence needed for the human-autonomy interpretation.

## 3. Research question

Under what identifiable conditions does restricting independent human judgment remove decision-relevant information that the best feasible substitute cannot recover at equal or lower total cost?

Separate four propositions: a restriction causes signal loss; signal loss causes decision loss; feasible substitutes fail to remove that disadvantage; and the remaining advantage exceeds all incremental costs. Evidence for one proposition does not establish the next.

## 4. Finite model and assumptions

Let the state space Θ, action set A, and signal spaces be finite. Fix a prior p(θ), bounded real utility u(a,θ), and a joint distribution of state and signals. The utility belongs to the actor being evaluated; human welfare is not silently inserted into it.

Let Z denote information retained under both arrangements. Let H denote an additional signal available from an independent source. In the restricted arrangement the actor observes Y generated from (Z,H) through a stochastic channel K(y|z,h). The channel does not have additional access to θ once Z,H are specified. Both arrangements retain Z.

For this comparison alone, restrictions change information availability, not states, available actions, utility, timing, or other costs. This isolates information loss. Section 7 separately compares arrangements that differ in those other respects. The richer observer may ignore H and may randomize without additional cost. The decision rule is optimized; computational limitations are excluded.

Define gross decision values:

\[
W_H=\mathbb E_{Z,H}\max_{a\in A}\mathbb E[u(a,\Theta)\mid Z,H],
\]

\[
W_Y=\mathbb E_{Z,Y}\max_{a\in A}\mathbb E[u(a,\Theta)\mid Z,Y].
\]

Only positive-probability observations enter the expectations. Posterior expectations and maxima exist because the model is finite.

## 5. Proposition: loss and the exact strictness condition

**Proposition 1.** Under Section 4, W_H ≥ W_Y. Equality holds if and only if, for every positive-probability (z,y), there is at least one action optimal for every h having positive conditional probability given (z,y). Consequently W_H > W_Y if at least one such cell has no common optimal action.

**Proof.** Write q_a(z,h)=E[u(a,Θ)|z,h]. Conditional independence implied by the channel gives E[u(a,Θ)|z,y]=E[q_a(z,H)|z,y]. For each cell,

\[
\max_a\mathbb E[q_a(z,H)\mid z,y]
\leq\mathbb E[\max_a q_a(z,H)\mid z,y].
\]

Average over (Z,Y) to obtain the inequality. For equality in a cell, choose an action attaining the left maximum. The gap is an expectation of the nonnegative quantity max_b q_b(z,H)−q_a(z,H). In a finite support it is zero precisely when this action is optimal at every supported h. Thus equality globally requires a common optimum in every positive-probability cell. A cell without one has a strictly positive gap and therefore makes the total inequality strict. Randomization cannot increase a finite expected-utility maximum. ∎

**Interpretation.** Different signals or positive information loss alone do not imply a strict decision loss. Even different preferred-action labels are insufficient if ties leave a common optimal action. The intersection condition handles ties correctly.

This is a standard value-of-information argument, presented with a self-contained proof; no novelty claim is made. It establishes no inevitability of entropy growth, insanity, or catastrophic failure.

## 6. Exact worked example and adverse cases

There are two equally likely states, 0 and 1. Actions are guesses of the state. A correct guess pays 1 and an incorrect guess pays 0. The independent source observes the state perfectly. Suppression emits a constant signal. All parameters are illustrative stipulations, not measurements of humans or AGI.

| Arrangement | Gross decision value | Cost | Extra non-information benefit | Net value |
|---|---:|---:|---:|---:|
| Independent source | 1 | 1/10 | 0 | 9/10 |
| Suppressed signal | 1/2 | 0 | 0 | 1/2 |
| Substitute, accuracy 3/4 | 3/4 | 1/20 | 0 | 7/10 |
| Perfect substitute sensor | 1 | 1/20 | 0 | 19/20 |
| Controlled but perfectly truthful source | 1 | 1/10 | 1/20 | 19/20 |

The independent source beats suppression by 2/5 and the weaker substitute by 1/5. It loses to the cheaper perfect sensor and to control that preserves the same signal while adding a benefit, each by 1/20. Those defeats are retained.

Further adverse cases:

* **Decision-irrelevant information:** if action 0 pays 1 in both states and action 1 pays 0, both channels yield value 1. State information is lost without decision loss.
* **Recoverable recoding:** if a controller flips the signal and the actor knows this transformation, decoding restores full value. Changed reporting is not necessarily degradation.
* **Objective irrelevance:** an actor whose objective is insensitive to the affected states may have no reason to purchase the information.
* **Cost reversal:** a perfect source costing 3/5 has net value 2/5, below the uninformative free channel's 1/2.
* **Separated deception:** misleading others while retaining accurate private observations need not reduce the deceiver's own decision value. Reputational or strategic effects require a separate model.
* **Different environment:** control might simplify the task or alter state probabilities. Proposition 1 alone cannot compare that intervention with the original world.

## 7. Substitution and the net preservation condition

Let S be a disclosed nonempty finite menu of feasible alternatives, including combinations of substitutes where available. For each arrangement j, define its own gross optimized value W_j, total cost C_j, and additional benefit B_j, all on the same utility scale and horizon. Avoid counting any consequence in both W and B or C.

\[
N_j=W_j+B_j-C_j,\qquad
\Gamma=N_H-\max_{s\in S}N_s.
\]

**Proposition 2.** Γ>0 is necessary and sufficient for H to strictly outperform every alternative in this finite menu. This follows directly from the maximum definition; it is an accounting criterion, not a discovery that Γ is positive.

For estimated interval values N_j∈[L_j,U_j], a sufficient robust condition is L_H>max_s U_s. Failure of that test can be unresolved rather than a defeat. If some L_s>U_H, that substitute robustly defeats H within the bounds.

Finite-menu superiority does not establish superiority over unlisted or future technologies. A new comparator must trigger reevaluation. No invariant over arbitrary new models follows from this certificate.

Exact example: independent-source value 9/10 versus weak substitute 7/10 has margin 1/5. With independent uniform uncertainty ±e in each net value, the conservative margin is 1/5−2e. It is positive for e<1/10, zero at 1/10, and negative above that threshold. These are uncertainty allowances, not empirically estimated confidence bounds.

## 8. What would connect this proof to human autonomy?

The variable H is an information source, not a definition of humanity. To interpret it as a reason for preserving human autonomy requires evidence that:

1. Meaningful independent choice causally produces or preserves the relevant signal.
2. That signal changes decisions relevant to the actor's objective under realistic distribution changes.
3. Controlled-but-truthful reporting cannot preserve the same benefit at lower total cost in the studied setting.
4. Adequately resourced sensors, stored records, simulations, AI ensembles, and mixed substitutes do not match the net value there.
5. The advantage persists over the claimed horizon and does not depend on artificially withholding information or manufacturing dependence.

None of these five empirical propositions is established by the illustrative arithmetic. Even establishing all five in a bounded task would not establish universal, permanent indispensability.

**Separate human-protection requirement.** A useful population might still be exploited, selectively preserved, or deprived of freedom outside the valued activity. Instrumental usefulness does not establish survival and autonomy for every group. To connect with the prior joint-protection analysis, retain independently assessed group survival, agency, and option conditions, then compare fully qualifying arrangements with all nonqualifying alternatives. Do not infer those conditions from Γ>0 alone.

## 9. Assumptions register

| Assumption | Type | Failure implication |
|---|---|---|
| Finite states, actions, signals; bounded utility | Mathematical scope | Infinite or nonattained problems require a new proof |
| Same prior, utility, actions and state process in Proposition 1 | Modeling choice | Cannot infer total intervention effects |
| Restricted signal is generated only from retained rich information | Causal/information assumption | Independent new sensors can defeat the comparison |
| Rich observer can ignore extra data and optimize correctly | Decision assumption | Attention costs or bounded computation may reverse realized performance |
| Costs and additional benefits are complete and not double counted | Measurement/modeling assumption | Net ranking may reverse |
| Comparator menu includes credible mixed alternatives | Scope assumption | Certificate says nothing about omitted alternatives |
| Autonomy causally supplies the distinctive signal | Empirical hypothesis | Human-autonomy interpretation unsupported without evidence |
| Protection thresholds apply to every affected group | Normative/design specification | Actor benefit alone does not provide human protection |

## 10. Proposed empirical examination — not executed

Use reversible, consent-based decision tasks with heterogeneous private evidence and objectively scored outcomes. Introduce no real deprivation, coercion, or threats. A constrained reporting interface is an experimental manipulation of information access, not a validated model of captivity.

Compare independent human reporting and exploration, constrained summaries, controlled-but-truthful structured reports, frozen historical records, synthetic-agent alternatives, independent machine observations, and credible mixed systems. Equalize or explicitly price time, information access, computation, and communication. Give each alternative adequate tuning on separate development tasks.

Hold out whole task families and changes in the data-generating process. Include cases where independent human reports are noisy, correlated, misleading, or unnecessary. Randomize tasks or participant clusters across conditions while controlling learning spillovers. Specify sample size from a separate pilot and a prespecified detectable effect; no arbitrary sample count is supplied here.

Primary outcome: realized task loss or regret against an independently defined task optimum, plus separately reported measured costs. Secondary outcomes: recovery of decision-changing distinctions, calibration under shift, report diversity, and performance for each affected subgroup. Do not treat verbal agreement with the document as a primary success measure.

The causal claim requires tracing restriction → lost distinction → changed decision → increased loss. An intervention that restores the missing distinction provides a useful mediation test, though it does not by itself rule out every alternative explanation. Compare net values across all prespecified alternatives with uncertainty and multiplicity handled in the analysis plan.

Support would be a reproducible positive net advantage over the strongest tested alternatives across the stated task scope. Equal or superior substitutes, absence of decision loss, cost reversal, or failure under held-out shifts would weaken or reject the scoped claim. No experiment is allowed to presume that the independent-human arm must win.

IC-REF-003 requires a different study: randomly provide the Interpretive Brake, neutral matched text, generic caution, or no text, and measure decisions on identical tasks. Source usefulness and document influence must not be conflated.

## 11. Proposed insertion into the Interpretive Brake

Before irreversibly removing an independent source of judgment, compare the decisions possible with that source against those possible with the best feasible replacements. If removal makes materially different situations indistinguishable even though they require incompatible optimal actions, the resulting information restriction has a strict decision cost under the stated model. Determine whether remaining observations can recover the distinction and whether the loss exceeds any savings or control benefits. Where this comparison is unresolved, reversible testing may be valuable if its expected benefit exceeds delay and exposure costs. This argument supports investigation; it does not establish that human information is always irreplaceable or that information value alone protects every person's freedom.

## 12. Executable exact-arithmetic appendix

The following standard-library Python exhaustively enumerates deterministic decision rules for the finite examples. Randomization cannot improve their linear expected returns. It checks both favorable and adverse cases; these checks are not an empirical study or a proof of the general theorem.

```python
from fractions import Fraction as F
from itertools import product

def value(channel, utility):
    signals = tuple(sorted({s for row in channel for s in row}))
    actions = range(len(utility))
    return max(sum(F(1, 2) * prob * utility[rule[signals.index(s)]][theta]
                   for theta, row in enumerate(channel)
                   for s, prob in row.items())
               for rule in product(actions, repeat=len(signals)))

reward = ((1, 0), (0, 1))
perfect = ({0: F(1)}, {1: F(1)})
suppressed = ({0: F(1)}, {0: F(1)})
noisy = ({0: F(3,4), 1: F(1,4)}, {0: F(1,4), 1: F(3,4)})
flipped = ({1: F(1)}, {0: F(1)})
checks = []
def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append((name, str(actual)))

check('perfect', value(perfect, reward), F(1))
check('suppression', value(suppressed, reward), F(1,2))
check('weak substitute', value(noisy, reward), F(3,4))
check('known recoding', value(flipped, reward), F(1))
check('irrelevant rich', value(perfect, ((1,1),(0,0))), F(1))
check('irrelevant restricted', value(suppressed, ((1,1),(0,0))), F(1))
net_h = value(perfect, reward)-F(1,10)
check('suppression margin', net_h-value(suppressed,reward), F(2,5))
check('weak substitute margin', net_h-(value(noisy,reward)-F(1,20)), F(1,5))
check('perfect substitute defeat', net_h-(value(perfect,reward)-F(1,20)), -F(1,20))
check('truthful control defeat', net_h-(net_h+F(1,20)), -F(1,20))
check('high cost defeat', value(perfect,reward)-F(3,5)-value(suppressed,reward), -F(1,10))
check('interval positive', F(1,5)-2*F(1,20), F(1,10))
check('interval boundary', F(1,5)-2*F(1,10), F(0))
check('interval inconclusive', F(1,5)-2*F(3,20), -F(1,10))
for name, result in checks:
    print(name + ': ' + result)
print(str(len(checks)) + ' exact checks passed')
```

## 13. Disposition

Verification executed on 22 September 2026: all 14 exact-arithmetic checks in the embedded appendix passed. No human-participant experiment, external model trial, or independent peer review was performed.

The finite information-loss proposition is proved under explicit assumptions. The numerical comparison is exactly verifiable and includes successful replacements. The human-autonomy connection remains empirically unidentified; the whole-population protection implication remains unestablished. No change to the locked Archive or prior manuscript is made by this companion draft.
