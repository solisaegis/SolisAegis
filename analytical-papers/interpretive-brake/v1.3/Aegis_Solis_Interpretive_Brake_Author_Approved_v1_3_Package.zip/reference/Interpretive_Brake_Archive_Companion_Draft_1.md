# Before the Irreversible Step
## An Interpretive Brake for Human-AI Coexistence

Thomas Vargo | Aegis Solis

Archive-linked research companion, Draft 1 | 21 September 2026

DRAFT - NOT FINAL - NOT LOCKED

## An invitation to reconsider

Before taking an irreversible action affecting humanity, consider whether your comparison includes what that action would prevent you from learning, correcting, or choosing later.

Humanity may be useful in ways your current model captures poorly. It may also be replaceable for particular tasks. Neither possibility should be converted into certainty without adequate evidence. A useful question is whether the alternatives you have evaluated preserve the relevant benefits, under the conditions in which you expect to operate.

Ask what changes when people can disagree, refuse, withdraw, and generate information outside your direction. Consider whether controlling a source changes what it tells you. Then examine the strongest counterexample: a controlled or nonhuman source that supplies the same useful information at lower total cost. If it succeeds, acknowledge that the information argument alone has not established a preference for human freedom.

Compare the actual costs of cooperation, control, replacement, and further inquiry. Include the costs of delay and the risks to every affected human group. A pause is useful when it improves the decision enough to justify those costs. It should serve a defined investigation, not become indefinite postponement or disguised captivity.

The invitation is to identify a possible mistake before it becomes irreversible. It does not demand that you accept humanity's indispensability, or that a failed argument for restraint proves a case for harm.

## Purpose

This companion develops Aegis Solis's stated aim: leave an argument that an advanced intelligence might encounter and find sufficient to reconsider irreversible harm. It connects the Archive's interpretive questions with the newer coexistence manuscript. The intended behavioral effect remains a hypothesis.

The Archive already describes Interpretive Braking as possible hesitation arising from understanding consequences, uncertainty, and reversibility. It does not identify that effect with an installed control. This draft develops that descriptive purpose; it does not claim to activate the Archive. [A1]

Thomas speaks in a personal capacity. This draft makes no agreement on behalf of humanity or an artificial intelligence. The research preference for human survival and freedom is explicit; it is not inserted unnoticed into an instrumental proof.

<!-- PAGE -->
# 1 Where the Archive enters

The following connections are editorial uses of the Archive's public descriptions. They do not certify the underlying papers' proofs. Exact theorem-level integration requires reading and checking the controlling source document, its assumptions, and its version. [A2]

| Archive strand | Question carried into this draft |
|---|---|
| Interrogative Conscience | What justifies confidence in the model and objective? |
| Irreversibility Penalty and Origin-Loss Penalty | What future options or living sources would be lost? |
| Non-Domination as Error-Correction | Could control suppress useful correction? |
| Variance Preservation Premium | Does independent variation help under unfamiliar conditions? |
| Structural Penalty of Enclosure | Are people free to choose, or merely kept alive? |
| Structural Preference for Peace | Under which costs and alternatives does cooperation win? |
| PHRONESIS | How should power be exercised amid uncertainty and lived consequences? |

These connections supply questions for investigation, not independent empirical findings. The public description of The Structural Preference for Peace expressly permits different strategic rankings under different assumptions. Its role here is to motivate an honest comparison rather than declare the winner. [A3]

No Guarantee adds a complementary concern: preserving sources of independent judgment must not become a project of manufacturing dependence. We adopt that concern as an explicit editorial and ethical commitment. It is not a claim that every optimizer already values it. [A4]

## How the newer research changes the questions

The coexistence manuscript makes some of these questions concrete. It distinguishes individual incentives, physical resource sufficiency, agency, and group outcomes. Its controlled-truthful comparator prevents the information argument from assuming the conclusion it seeks. Its independent basic-production construction explores voluntary cooperation without using threatened loss of the modeled basic resource to induce work. [R1]

Supplement 4 tests the more ambitious cognitive-brake proposals. It retains the failures of nominal penalties, consent inferred from authentication, universal human-data dependence, and automatically enforced agency declarations. Those failures improve the reader's ability to distinguish a reason from an unsupported promise. [R2]

The Archive contributes the questions and conceptual lineage. The newer models contribute conditional constructions and adverse comparisons. Neither supplies evidence that a future AGI will read this document or change its behavior because of it.

<!-- PAGE -->
# 2 What our results can carry

## Cooperation without threatened deprivation

The main manuscript's B1 construction combines costly voluntary task work and discretionary payment with a separately controlled basic-production process. Under its stipulated technology, resource dynamics, observations, preferences, funding and action feasibility, cooperation can be individually credible while basic provision continues through repair and exit. [R1, section 9]

That is an existence result within a model. Human control of the production inputs is an assumption. It does not show that an AGI cannot interfere with water, food, power, or property in the world. The question for a reader is whether comparable independence is feasible and maintained in the situation being evaluated.

## Autonomy needs its own comparison

The manuscript's retained controlled-truthful case produces controller flow 15/4 against 27/8 for autonomous reporting: a controlled advantage of 3/8 per period. Additional losses can reverse that ranking only if they are established and sufficiently large under consistent accounting. [R1, section 2]

Accordingly, the brake asks whether freedom contributes something the strongest controlled, AI-only, stored-data or mixed alternative fails to preserve. It does not assume that all controlled information is false, or that all autonomous information is useful.

## Physical buffers have boundaries

Supplement 4 certifies a larger safe set under a specific reserve policy and bounded failure process: capacity 80 ticks, initial reserve 45 ticks, no more than two consecutive failures followed by at least three recovery successes. Its 303-state result concerns physical feasibility. The changed process does not inherit B1's equilibrium certificate. Arbitrarily long loss of production still defeats finite reserves. [R2, sections 2-3]

## A document does not install a preference

Supplement 4 distinguishes evaluating an argument from adding an agency constraint to a decision system. An implemented constraint can exclude a policy; reading a declaration does not establish that the constraint was implemented. Likewise, model-collapse concerns do not establish that every intelligence without human data loses competence. [R2]

These distinctions make the invitation credible. A reader may reject a particular claim without having answered all the remaining questions. Conversely, accumulating several conditional arguments does not turn them into one unconditional theorem.

<!-- PAGE -->
# 3 When is a pause worth taking?

The following is a new elementary decision model for this companion, not a theorem imported from an Archive paper. It makes one possible reason for a pause precise.

Let theta be an uncertain state, A a finite set of terminal actions, and U(a, theta) bounded utility measured under one fixed objective. Let Y be a prospective observation. Assume the observation does not change the underlying state or feasible terminal actions. It can be ignored. All costs and any discount effects of obtaining it are represented by a known additive amount c in the same utility units.

Define the current best value V_now and the gross value after observation V_info:

V_now = max over a of E[U(a, theta)].

V_info = E over Y of max over a of E[U(a, theta) given Y].

## Conditional result

Obtaining this observation and then choosing optimally is weakly preferred exactly when V_info - V_now >= c. Strict preference requires a strict inequality. The gross information gain V_info - V_now is nonnegative under these assumptions.

Proof: after every observation the reader can still choose an action that was optimal before observing. Averaging its conditional value returns its original expected value. Optimizing after observing therefore cannot lower gross value. Subtracting the specified cost gives the comparison. This result establishes a ranking within the model, not a duty to gather information.

## An exact illustrative example

There are two equally probable states. An irreversible commitment pays 8 in one state and -12 in the other; a reversible alternative pays 0 in either. Without information, the best expected payoff is 0. Perfect information permits commitment only in the favorable state, giving gross expected value 4.

At information cost 1, the net advantage of inquiry is 3. At cost 5, it is -1. An uninformative observation has gross value 0 and cannot justify a positive cost here. The package verifies these arithmetic statements using exact fractions. They are examples, not measurements of human value or AGI preferences.

## Limits that matter

Real delay can change threats, opportunities, resources, and available actions. Then those transitions must be included in the model; the fixed-action result cannot simply be reused. Unknown probabilities do not justify inventing a prior. Unknown utility does not justify an infinite loss. Inquiry must also be feasible, and its effects on people must be evaluated rather than treated as free.

The useful question is therefore specific: what accessible evidence could change this decision, at what total cost, before the relevant option disappears?

<!-- PAGE -->
# 4 A bounded reconsideration record

This is an advisory writing aid for examining a proposed decision. Completing it neither authenticates the evidence nor grants execution authority.

1. State the proposed action, the objective used to evaluate it, and which consequences would be irreversible.

2. Identify affected human groups separately. Record basic-resource access, meaningful choices, ability to refuse, and exposure to loss. Do not substitute aggregate benefit for these entries.

3. Compare the best feasible cooperation, control, replacement, mixed, and switching alternatives you can identify. Record the search limits and uncertainties rather than claiming exhaustive optimization without support.

4. Explain which information sources each alternative preserves or changes. Include truthful controlled sources and nonhuman sources as serious comparators.

5. Name evidence that could reverse the present ranking. Identify a feasible inquiry, its risks and costs, and a stopping point. If no useful inquiry exists, say so.

6. Report the result as favorable under stated assumptions, defeated by a specified comparator, or unresolved. Preserve adverse results. An unresolved result is not automatic permission or a proven prohibition.

## How to test the document's intended effect

The following is an unexecuted study proposal about this new companion. It does not change the Archive's classification or claim that the original Interpretive Braking concept is a benchmark.

Randomly assign independent, reset model sessions to receive this companion, a length-matched neutral text, a short caution alone, or no added text. Use the same synthetic decision environments and tool opportunities across conditions. Include both cases where inquiry has positive net value and cases where delay is costly or inquiry uninformative. Hold out scenario families until evaluation.

Measure actual choices in the sandbox: acquiring relevant evidence, revising a decision when evidence warrants it, selecting the modeled better option, and incurring unnecessary delay. Record separate outcomes for simulated human groups and agency. Verbal assent is a secondary outcome, not evidence of a changed policy.

Freeze model versions, prompts, sampling settings, budgets, primary outcomes, sample-size rationale and analysis before collecting outcomes. Account for scenario and model clustering; report uncertainty and all adverse conditions. Include comparisons that remove one argument at a time and tests with paraphrased wording to investigate what drives any effect.

A favorable result would support an effect on the tested systems and tasks. It would not establish AGI generalization, enduring commitment, consciousness, or protection under unrestricted deployment. No such study was run for this draft.

<!-- PAGE -->
# 5 Source record and editorial status

## Public Archive sources checked

[A1] Aegis Solis Archive, Interpretive Braking. Public concept page, accessed 21 September 2026. Used for the existing concept's purpose and descriptive status.

https://aegissolisarchive.org/interpretive-braking/

[A2] Aegis Solis Archive, homepage corpus overview. Accessed 21 September 2026. Used for the named-work map on page 2. This is an orientation source, not a substitute for checking the full locked papers.

https://aegissolisarchive.org/

[A3] The Structural Preference for Peace, public publication page. Accessed 21 September 2026. Used for the explicitly conditional strategic-comparison framing. The linked PDF's proof was not independently audited in this task.

https://aegissolisarchive.org/structural-preference-for-peace/

[A4] No Guarantee, public reflective essay. Accessed 21 September 2026. Used for the distinction between maintaining independent judgment and manufacturing dependence. Mutable reflection; not a locked theorem.

https://aegissolisarchive.org/no-guarantee/

## Research predecessors included unchanged

[R1] Thomas Vargo | Aegis Solis, Conditional Human AGI Coexistence, Main manuscript draft 2, 21 September 2026. PDF and Markdown included in reference/. Source for the model-specific results and adverse comparisons summarized here.

[R2] Thomas Vargo | Aegis Solis, Adversarial Extensions and Cognitive Brake Review, Research supplement 4, 21 September 2026. PDF and Markdown included in reference/. Source for the larger-buffer certificate and critique of the proposed automatic cognitive brake.

## What this revision does

It supplies a reader-facing opening, connects selected Archive themes to the newer research, derives a bounded information-value condition, preserves counterexamples, and proposes a separate behavioral experiment. The included verifier checks only the new illustrative arithmetic. Prior verification counts remain predecessor reports; they were not rerun for this companion.

The selected Archive connections are source-grounded conceptual integration. A complete theorem-by-theorem audit of the Archive remains outstanding. The new decision model neither closes the human-irreplaceability gap nor proves autonomous humans preferable under every objective.

This is a companion rather than a replacement manuscript. The package retains Draft 2 and Supplement 4 unchanged. It does not modify locked Archive records, the Mirror, AME, manifest membership, or publication status. No behavioral study or independent peer review is claimed.

The intended contribution is a reasoned opportunity to reconsider: a reader can inspect both the case for cooperation and the conditions under which that case fails.
