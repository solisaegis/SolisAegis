from fractions import Fraction as F
from pathlib import Path
import json
checks=[]
def check(name,actual,expected):
 assert actual==expected,(name,actual,expected)
 checks.append({'name':name,'value':str(actual)})
a=[(F(1),F(4))];b=[(F(1,2),F(0)),(F(1,2),F(10))]
def eu(dist,u):return sum(p*u(w) for p,w in dist)
linear=lambda w:w
sat=lambda w:min(w,F(4))
check('linear A',eu(a,linear),F(4))
check('linear B',eu(b,linear),F(5))
check('saturating A',eu(a,sat),F(4))
check('saturating B',eu(b,sat),F(2))
check('utility of mean differs',sat(eu(b,linear))-eu(b,sat),F(2))
check('ranking reverses',eu(b,linear)>eu(a,linear) and eu(a,sat)>eu(b,sat),True)
needs={'A':1,'B':3};capacity=2
check('local capacity excludes B',[p for p in needs if needs[p]<=capacity],['A'])
(Path(__file__).resolve().parents[1]/'results/applicability.json').write_text(json.dumps({'named_calculations':len(checks),'checks':checks,'empirical_study':False},indent=2)+'\n')
print(len(checks),'applicability calculations passed')
