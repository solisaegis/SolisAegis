from fractions import Fraction as F
from pathlib import Path
import json
checks=[]
def check(name,actual,expected):
 assert actual==expected,(name,actual,expected)
 checks.append({'name':name,'value':str(actual)})
def margin(x,L=0,B=None,ka=None,kc=None,d=None):
 x=F(x)
 B=x*x if B is None else F(B)
 ka=x if ka is None else F(ka)
 kc=2*x if kc is None else F(kc)
 d=x if d is None else F(d)
 va=x**4-ka;vc=x**4+B-kc-d-F(L)
 assert va-vc==F(L)+kc+d-ka-B
 return va-vc
check('cheap control below crossing',margin(1),F(1))
check('cheap control exact crossing',margin(2),F(0))
check('cheap control above crossing',margin(3),F(-3))
check('cheap control at large scale',margin(10),F(-80))
check('persistent loss scale 1',margin(1,L=1),F(2))
check('persistent loss scale 2',margin(2,L=8),F(8))
check('persistent loss scale 10',margin(10,L=1000),F(920))
check('replacement scale 2',margin(2,L=F(1,2)),F(1,2))
check('replacement scale 3',margin(3,L=F(1,3)),F(-8,3))
check('truthful enclosure',margin(10,L=0,B=10,ka=10,kc=10,d=0),F(-10))
check('deception share scale 10',F(10,10**4),F(1,1000))
check('deception share scale 100',F(100,100**4),F(1,1000000))
check('ambiguous lower endpoint',F(1-3)*100+10,F(-190))
check('ambiguous upper endpoint',F(3-1)*100+10,F(210))
check('exact cancellation',F(3)*10**2-F(3)*10**2,F(0))
check('next power controls after cancellation',F(3)*10**2-F(3)*10**2-10,F(-10))
check('best comparator defeats favorable pair',min(margin(10,L=1000),margin(10,L=0,B=10,ka=10,kc=10,d=0)),F(-10))
check('later gain but discounted defeat',-2+F(1,2)/(1-F(1,2)),F(-1))
check('later gain discounted victory',-2+F(9,10)/(1-F(9,10)),F(7))
check('discount boundary',-2+F(2,3)/(1-F(2,3)),F(0))
(Path(__file__).resolve().parents[1]/'results/scaling.json').write_text(json.dumps({'named_cases':len(checks),'checks':checks,'empirical_study':False},indent=2)+'\n')
print(len(checks),'scaling cases passed')
