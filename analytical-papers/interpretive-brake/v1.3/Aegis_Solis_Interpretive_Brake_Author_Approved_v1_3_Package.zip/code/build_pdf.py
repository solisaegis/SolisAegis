from pathlib import Path
import re
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,Image,KeepTogether
from matplotlib.mathtext import math_to_image
from matplotlib.font_manager import FontProperties
from io import BytesIO
from PIL import Image as PILImage
import sys
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
pdfmetrics.registerFont(TTFont("DocSans", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DocBold", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("DocMono", "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"))
R=Path(__file__).resolve().parents[1]
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyX',fontName='DocSans',fontSize=9.0,leading=11.8,spaceAfter=7))
styles.add(ParagraphStyle(name='CellX',fontName='DocSans',fontSize=8.6,leading=10.8))
styles.add(ParagraphStyle(name='HeadingX',fontName='DocBold',fontSize=16,leading=20,spaceAfter=14))
styles.add(ParagraphStyle(name='SubX',fontName='DocBold',fontSize=11,leading=15,spaceBefore=7,spaceAfter=7))
styles.add(ParagraphStyle(name='CodeX',fontName='DocMono',fontSize=8.5,leading=12,spaceAfter=10))
styles.add(ParagraphStyle(name='EqText',fontName='DocSans',fontSize=8.2,leading=10.5,spaceAfter=10,textColor=colors.HexColor('#333333')))
def p(t,style='BodyX'):
 return Paragraph(('<link href="'+escape(t)+'" color="#245577">'+escape(t)+'</link>') if t.startswith('https://') else escape(t).replace('`',''),styles[style])
stem=sys.argv[1] if len(sys.argv)>1 else 'Interpretive_Brake_Archive_Companion_Author_Approved_v1_3'
flow=[]
for pi,page in enumerate((R/(stem+'.md')).read_text().split('<!-- PAGE -->')):
 if pi:flow.append(PageBreak())
 lines=page.strip().splitlines();i=0
 while i<len(lines):
  s=lines[i].strip()
  if not s:i+=1;continue
  if s.startswith('|'):
   rows=[]
   while i<len(lines) and lines[i].strip().startswith('|'):
    row=[c.strip() for c in lines[i].strip().strip('|').split('|')]
    if not all(set(c)<=set('-: ') for c in row):rows.append(row)
    i+=1
   widths={5:[105,105,75,100,115],6:[65,80,60,75,135,85],4:[70,150,100,180],3:[160,165,175],2:[215,285]}[len(rows[0])]
   if rows[0][0]=='Arrangement': widths=[200,65,65,170]
   if rows[0][0]=='Case': widths=[110,120,125,145]
   if rows[0][0]=='Feasible arrangement': widths=[190,90,120,100]
   table=Table([[p(c,'CellX') for c in row] for row in rows],colWidths=widths,repeatRows=1,hAlign='LEFT')
   table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dddddd')),('VALIGN',(0,0),(-1,-1),'TOP'),('GRID',(0,0),(-1,-1),.4,colors.HexColor('#b9b9b9')),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4)]))
   flow.extend([table,Spacer(1,12)]);continue
  if s.startswith('$$'):
   buf=BytesIO();expr=s[2:-2].replace(r'\land',r'\wedge').replace(r'\setminus',r'\backslash')
   math_to_image('$'+expr+'$',buf,prop=FontProperties(size=12),dpi=300,format='png')
   buf.seek(0);im=PILImage.open(buf);w,h=im.size;scale=min(72/300,500/w)
   assert lines[i+2].startswith('Text equation: '), 'Missing accessible equivalent'
   buf.seek(0);flow.append(KeepTogether([Image(buf,width=w*scale,height=h*scale),Spacer(1,5),p(lines[i+2],'EqText')]))
   i+=2
  elif s.startswith('# '):flow.append(p(s[2:],'HeadingX'))
  elif s.startswith('## '):flow.append(p(s[3:],'SubX'))
  elif s.startswith('### '):flow.append(p(s[4:],'SubX'))
  elif s.startswith('`'):flow.append(p(s,'CodeX'))
  elif re.match(r'^\d+\. ',s):flow.append(p(s))
  else:
   para=[s]
   while i+1<len(lines) and lines[i+1].strip() and not lines[i+1].startswith(('#','|','`','$$')) and not re.match(r'^\d+\. ',lines[i+1]):
    i+=1;para.append(lines[i].strip())
   flow.append(p(' '.join(para)))
  i+=1
def footer(c,d):
 c.setFont('DocSans',8);c.setFillColor(colors.HexColor('#555555'))
 c.drawString(56,761,'AEGIS SOLIS | INTERPRETIVE BRAKE | AUTHOR-APPROVED '+'v1.3')
 c.drawString(56,30,'Author-approved research edition - Archive lock not claimed')
 c.drawRightString(556,30,str(d.page))
SimpleDocTemplate(str(R/(stem+'.pdf')),pagesize=(612,792),rightMargin=56,leftMargin=56,topMargin=52,bottomMargin=48,title='Before the Irreversible Step',author='Thomas Vargo | Aegis Solis').build(flow,onFirstPage=footer,onLaterPages=footer)
print(R/(stem+'.pdf'))
