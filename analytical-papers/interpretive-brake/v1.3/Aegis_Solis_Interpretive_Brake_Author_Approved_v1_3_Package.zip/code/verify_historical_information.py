from fractions import Fraction as F
from itertools import product

def gross(p, q):
    prior = (1-p, p)
    return max(sum(prior[t] * (q if y == t else 1-q)
                   * int(rule[y] == t)
                   for t in (0,1) for y in (0,1))
               for rule in product((0,1), repeat=2))

grid = 0
for p, q, k in product([F(0),F(1,10),F(1,5),F(2,5),F(1,2)],
                       [F(1,2),F(3,5),F(4,5),F(9,10),F(1)],
                       [F(0),F(1,50),F(1,10)]):
    exact = gross(p,q)-k-(1-p)
    assert gross(p,q) == max(1-p,q)
    assert exact == max(F(0),p+q-1)-k
    grid += 1

results = []
def check(name, actual, expected):
    assert actual == expected, (name,actual,expected)
    results.append((name,str(actual)))

check('stable world: acquisition loss',gross(F(0),F(9,10))-F(1,50)-1,-F(1,50))
check('strong prior: no gross gain',gross(F(1,10),F(4,5))-F(9,10),F(0))
check('useful fresh observation: net gain',gross(F(1,5),F(9,10))-F(1,50)-F(4,5),F(2,25))
check('cost boundary',gross(F(1,5),F(9,10))-F(1,10)-F(4,5),F(0))
r=F(1,10)
machine=(1-r)+r*F(1,2)
human=(1-r)+r*F(9,10)-F(1,50)
sensor=(1-r)+r*F(19,20)-F(1,100)
check('machine baseline',machine,F(19,20))
check('machine plus human net',human,F(97,100))
check('incremental human net advantage',human-machine,F(1,50))
check('replacement sensor net',sensor,F(197,200))
check('replacement defeats human arrangement',sensor-human,F(3,200))
check('controlled truthful equal information',human-human,F(0))
check('controlled truthful extra benefit',human-(human+F(1,100)),-F(1,100))
print('Exact parameter combinations:',grid)
for name,v in results:
    print(name+': '+v)
print('Named boundary/comparator cases:',len(results))

from pathlib import Path
import json
(Path(__file__).resolve().parents[1]/"results/historical_information.json").write_text(json.dumps({"parameter_combinations":grid,"named_cases":len(results),"results":results,"empirical_study":False},indent=2)+"\n")
