from pathlib import Path
import re,json,subprocess,fitz
r=Path(__file__).resolve().parents[1]
def norm(s):return ' '.join(s.split())
results=[]
for stem in ['Interpretive_Brake_Archive_Companion_Author_Approved_v1_3','Reader_Core_Author_Approved_v1_3']:
 md=(r/(stem+'.md')).read_text()
 expected=re.findall(r'^Text equation: (.+)$',md,re.M)
 displays=re.findall(r'^\$\$.+\$\$$',md,re.M)
 assert len(expected)==len(displays)>0
 target=r/(stem+'.txt')
 subprocess.run(['pdftotext','-layout',str(r/(stem+'.pdf')),str(target)],check=True)
 text=norm(target.read_text());fitztext=norm(' '.join(p.get_text() for p in fitz.open(r/(stem+'.pdf'))))
 for equation in expected:
  assert norm(equation) in text,('pdftotext',equation)
  assert norm(equation) in fitztext,('PyMuPDF',equation)
 results.append({'document':stem,'display_equations':len(displays),'equivalents_extracted_by_both_tools':len(expected),'equations':expected})
(r/'results/equation_extraction.json').write_text(json.dumps({'documents':results,'empirical_study':False},indent=2)+'\n')
print([(x['document'],x['display_equations']) for x in results])
