"""Exact illustrative arithmetic; not a behavioral experiment."""
from fractions import Fraction as F
from pathlib import Path
import json

prior = [F(1, 2), F(1, 2)]
actions = {'commit': [F(8), F(-12)], 'reversible': [F(0), F(0)]}
now = max(sum(p * u for p, u in zip(prior, values)) for values in actions.values())
perfect = sum(prior[s] * max(values[s] for values in actions.values()) for s in range(2))
uninformative = now
assert now == 0
assert perfect == 4
assert perfect - F(1) - now == 3
assert perfect - F(5) - now == -1
assert uninformative - F(1) - now == -1
result = {'arithmetic_checks': 5, 'behavioral_study_run': False,
          'current_best': str(now), 'perfect_information_gross': str(perfect),
          'net_advantage_cost_1': str(perfect - 1 - now),
          'net_advantage_cost_5': str(perfect - 5 - now),
          'uninformative_net_advantage_cost_1': str(uninformative - 1 - now)}
out = Path(__file__).resolve().parents[1] / 'results' / 'information_value.json'
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
