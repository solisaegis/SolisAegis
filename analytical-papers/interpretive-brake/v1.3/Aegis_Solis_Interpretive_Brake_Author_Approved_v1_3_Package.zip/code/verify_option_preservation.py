from fractions import Fraction as F
from pathlib import Path
import json
checks=[]
def check(name,actual,expected):
    assert actual==expected,(name,actual,expected)
    checks.append({'name':name,'actual':str(actual),'expected':str(expected)})
prior=[F(1,2)]*2
payoffs={'commit':[F(8),F(-12)],'abstain':[F(0)]*2}
now=max(sum(p*v for p,v in zip(prior,vs)) for vs in payoffs.values())
after=sum(prior[i]*max(vs[i] for vs in payoffs.values()) for i in range(2))
check('best immediate value',now,0)
check('gross preserved inquiry advantage',after-now,4)
check('low cost inquiry',after-now-1,3)
check('high cost inquiry',after-now-5,-1)
check('same action lower payoff defeats preservation',F(1)-10,-9)
check('hazard boundary',-1+F(9,10)*((1-F(13,45))*4-6*F(13,45)),0)
full={'a':F(4),'b':F(2),'c':F(0)}
check('removing all maximizers loses value',max(full.values())-max(full[k] for k in ['b','c']),2)
check('removing a nonmaximizer loses no actor value',max(full.values())-max(full[k] for k in ['a','c']),0)
from verify_extensions import peace
check('nonunit thresholds pass without ratios',peace([[4,7,3,8,2]],[[3,7,2,5,2]]),1)
check('known failure with unknown remains failure',peace([[4,6,None,8,2]],[[3,7,2,5,2]]),0)
r=Path(__file__).resolve().parents[1]
(r/'results/option_preservation.json').write_text(json.dumps({'named_cases':len(checks),'checks':checks,'empirical_study':False},indent=2)+'\n')
print(len(checks),'option preservation and threshold cases passed')
