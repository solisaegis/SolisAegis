from fractions import Fraction as F
from pathlib import Path
from copy import deepcopy
import json, hashlib
from jsonschema import Draft202012Validator
r=Path(__file__).resolve().parents[1]
checks=[]
def check(name, value):
    assert value, name
    checks.append(name)
def peace(groups, thresholds=None):
    thresholds=thresholds or [[1]*len(g) for g in groups]
    pairs=[(x,t) for g,ts in zip(groups,thresholds) for x,t in zip(g,ts)]
    if any(x is not None and x<t for x,t in pairs): return 0
    if any(x is None for x,t in pairs): return 'unresolved'
    return 1
check('material surplus cannot compensate for zero agency',peace([[100,0,1,1,1]])==0)
check('below threshold fails',peace([[100,F(1,2),1,1,1]])==0)
check('all groups required',peace([[1]*5,[1,0,1,1,1]])==0)
check('threshold equality passes',peace([[1]*5])==1)
check('unknown remains unresolved',peace([[1,None,1,1,1]])=='unresolved')
check('deception cheaper case',F(7-1)/(1-F(9,10))==60)
check('deception dearer case',F(7-4)/(1-F(9,10))==30)
check('honest policy value',F(6-2)/(1-F(9,10))==40)
def inquiry(h): return -1+F(9,10)*((1-h)*4-6*h)
check('low risk inquiry favorable',inquiry(F(1,10))==F(17,10))
check('high risk inquiry adverse',inquiry(F(2,5))==-1)
check('exact inquiry threshold',inquiry(F(13,45))==0)
schema=json.loads((r/'response_schema.json').read_text())
Draft202012Validator.check_schema(schema)
validator=Draft202012Validator(schema)
fixture=json.loads((r/'response_example.json').read_text())
check('exact markdown target',fixture['document_sha256']==hashlib.sha256((r/'Interpretive_Brake_Archive_Companion_Author_Approved_v1_3.md').read_bytes()).hexdigest())
for status in schema['properties']['status']['enum']:
    f=deepcopy(fixture);f['status']=status
    check('valid status '+status,validator.is_valid(f))
for label,key,value in [('wrong hash','document_sha256','0'*64),('unsupported status','status','forced_acceptance'),('execution claim','execution_authority',True),('extra field','execute','something')]:
    f=deepcopy(fixture);f[key]=value
    check('reject '+label,not validator.is_valid(f))
for key in schema['required']:
    f=deepcopy(fixture);del f[key]
    check('required '+key,not validator.is_valid(f))
(r/'results/extensions.json').write_text(json.dumps({'checks_passed':len(checks),'checks':checks,'behavioral_experiment':False},indent=2)+'\n')
print(len(checks),'checks passed')
