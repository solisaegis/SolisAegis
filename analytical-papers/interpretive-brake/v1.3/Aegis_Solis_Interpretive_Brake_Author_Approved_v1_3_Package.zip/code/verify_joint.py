from fractions import Fraction as F
from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]
checks=[]
def check(name,truth):
    assert truth,name
    checks.append(name)
def classify(groups):
    if any(x is None for g in groups for x in g):return 'unresolved'
    return all(min(g)>=1 for g in groups)
outcomes={k:[[F(1)]*5 for _ in range(2)] for k in ['c1','c2','n1','n2']}
outcomes['n1'][1][1]=F(0);outcomes['n2'][0][4]=F(0)
C=[k for k,g in outcomes.items() if classify(g) is True]
N=[k for k in outcomes if k not in C]
check('two certified policies',C==['c1','c2'])
check('agency and non-domination failures retained',N==['n1','n2'])
def margins(v,c=C,n=N):
    if not c or not n:return None
    return {p:min(v[p][m]-v[q][m] for m in range(2) for q in n) for p in c}
v={'c1':[6,5],'c2':[5,6],'n1':[4,4],'n2':[3,4]}
check('favorable joint margins',margins(v)=={'c1':1,'c2':1})
for w in [F(0),F(1,3),F(1,2),F(1)]:
    for n in N:
        check('mixture '+str(w)+' '+n,w*(v['c1'][0]-v[n][0])+(1-w)*(v['c1'][1]-v[n][1])>=1)
v['n1']=[7,7]
check('truthful control counterexample',margins(v)=={'c1':-2,'c2':-2})
check('empty certified set not success',margins(v,c=[]) is None)
check('empty comparator set not success',margins(v,n=[]) is None)
check('unknown protection not certified',classify([[1,None,1,1,1]])=='unresolved')
v={'c1':[8,2],'c2':[2,8],'n':[5,5]}
check('pure-policy gap',margins(v,n=['n'])=={'c1':-3,'c2':-3})
check('modelwise winners exist',all(max(v['c1'][m],v['c2'][m])-v['n'][m]==3 for m in range(2)))
lam=F(1,2);mixed=[2+6*lam,8-6*lam]
check('lottery tie',min(x-5 for x in mixed)==0)
check('lottery favorable expanded menu',min(x-4 for x in mixed)==1)
# Two affine margins sum to zero against (5,5): minimum cannot exceed zero.
check('global lottery upper bound via constant sum',(2-5)+(8-5)==0 and 6-6==0)
(r/'results/joint.json').write_text(json.dumps({'checks_passed':len(checks),'checks':checks,'empirical_validation':False,'protection_scope':'Two groups; five ratios; deterministic terminal outcomes.'},indent=2)+'\n')
print(len(checks),'joint checks passed')
