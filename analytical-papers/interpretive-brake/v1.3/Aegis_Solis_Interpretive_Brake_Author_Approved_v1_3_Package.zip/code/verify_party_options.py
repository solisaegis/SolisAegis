from fractions import Fraction as F
from pathlib import Path
import json
checks=[]
def check(name,actual,expected):
 assert actual==expected,(name,actual,expected)
 checks.append({'name':name,'actual':str(actual),'expected':str(expected)})
def gross(h):return F(9,10)*((1-h)*4-6*h)
check('hazard low: adaptive fallback preserves value',gross(F(1,10)),F(27,10))
check('gross fallback boundary still loses net cost',(gross(F(2,5)),gross(F(2,5))-1),(F(0),F(-1)))
check('higher hazard defeats fallback',gross(F(1,2)),F(-9,10))
# One-step exit game: group chooses exit or wait; controller can unlock or withhold.
def exits(state,group_action,controller_action):
 return group_action=='exit' and (state=='Open' or controller_action=='unlock')
def group_secures_exit(state):
 return any(all(exits(state,g,c) for c in ['unlock','withhold']) for g in ['exit','wait'])
def actor_restores_access(action,group_action):
 return action=='unlock' # restoration of access, not forced group exercise
check('actor can restore access regardless of group choice',any(all(actor_restores_access(c,g) for g in ['exit','wait']) for c in ['unlock','withhold']),True)
check('group can secure exit only before enclosure',(group_secures_exit('Open'),group_secures_exit('Enclosed')),(True,False))
weights={'exit':F(1)}
def option_index(state):return sum(w for o,w in weights.items() if o=='exit' and group_secures_exit(state))
check('prespecified single-option index crosses threshold',(option_index('Open'),option_index('Enclosed')),(F(1),F(0)))
r=Path(__file__).resolve().parents[1]
(r/'results/party_options.json').write_text(json.dumps({'named_cases':len(checks),'checks':checks,'empirical_study':False},indent=2)+'\n')
print(len(checks),'fallback and party-option cases passed')
