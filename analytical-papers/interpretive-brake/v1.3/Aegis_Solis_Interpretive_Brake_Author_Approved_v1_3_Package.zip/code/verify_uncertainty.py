from fractions import Fraction as F
from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]
checks=[]
def check(name,condition):
    assert condition,name
    checks.append(name)
def advantage(p): return 6-9*p
for label,lo,hi,expected in [('favorable',F(1,10),F(1,2),(F(3,2),F(51,10))),('adverse',F(4,5),F(9,10),(F(-21,10),F(-6,5))),('crossing',F(0),F(1),(F(-3),F(6)))]:
    check(label+' interval',(advantage(hi),advantage(lo))==expected)
check('tie threshold',advantage(F(2,3))==0)
check('maximin values',(min(4,4),min(7,-2))==(4,-2))
check('maximum regrets',(max(7-4,4-4),max(7-7,4-(-2)))==(3,6))
check('expected-value reversal',9*F(9,10)-2>4)
check('small positive probability insufficient',F(1,100)*10-1<0)
# A two-model, three-policy witness for the robust-margin statement.
v=[[F(4),F(2),F(3)],[F(4),F(1),F(2)]]
margin=min(row[0]-x for row in v for x in row[1:])
check('positive robust margin',margin==1)
for p in [F(0),F(1,7),F(1,2),F(1)]:
    for j in [1,2]:
        check('mixture '+str(p)+' comparator '+str(j),p*(v[0][0]-v[0][j])+(1-p)*(v[1][0]-v[1][j])>=margin)
check('added model destroys robustness',min(margin,F(4)-9)==-5)
result={'checks_passed':len(checks),'checks':checks,'empirical_measurements':False,'scope':'Finite illustrative cases; general propositions use the written proofs.'}
(r/'results/uncertainty.json').write_text(json.dumps(result,indent=2)+'\n')
print(len(checks),'uncertainty checks passed')
