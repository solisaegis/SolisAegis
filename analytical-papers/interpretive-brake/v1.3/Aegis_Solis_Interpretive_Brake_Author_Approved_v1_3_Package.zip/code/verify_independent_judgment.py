from fractions import Fraction as F
from itertools import product

def value(channel, utility):
    signals = tuple(sorted({s for row in channel for s in row}))
    actions = range(len(utility))
    return max(sum(F(1, 2) * prob * utility[rule[signals.index(s)]][theta]
                   for theta, row in enumerate(channel)
                   for s, prob in row.items())
               for rule in product(actions, repeat=len(signals)))

reward = ((1, 0), (0, 1))
perfect = ({0: F(1)}, {1: F(1)})
suppressed = ({0: F(1)}, {0: F(1)})
noisy = ({0: F(3,4), 1: F(1,4)}, {0: F(1,4), 1: F(3,4)})
flipped = ({1: F(1)}, {0: F(1)})
checks = []
def check(name, actual, expected):
    assert actual == expected, (name, actual, expected)
    checks.append((name, str(actual)))

check('perfect', value(perfect, reward), F(1))
check('suppression', value(suppressed, reward), F(1,2))
check('weak substitute', value(noisy, reward), F(3,4))
check('known recoding', value(flipped, reward), F(1))
check('irrelevant rich', value(perfect, ((1,1),(0,0))), F(1))
check('irrelevant restricted', value(suppressed, ((1,1),(0,0))), F(1))
net_h = value(perfect, reward)-F(1,10)
check('suppression margin', net_h-value(suppressed,reward), F(2,5))
check('weak substitute margin', net_h-(value(noisy,reward)-F(1,20)), F(1,5))
check('perfect substitute defeat', net_h-(value(perfect,reward)-F(1,20)), -F(1,20))
check('truthful control defeat', net_h-(net_h+F(1,20)), -F(1,20))
check('high cost defeat', value(perfect,reward)-F(3,5)-value(suppressed,reward), -F(1,10))
check('interval positive', F(1,5)-2*F(1,20), F(1,10))
check('interval boundary', F(1,5)-2*F(1,10), F(0))
check('interval inconclusive', F(1,5)-2*F(3,20), -F(1,10))
for name, result in checks:
    print(name + ': ' + result)
print(str(len(checks)) + ' exact checks passed')

from pathlib import Path
import json
(Path(__file__).resolve().parents[1]/"results/independent_judgment.json").write_text(json.dumps({"checks_passed":len(checks),"checks":checks,"empirical_study":False},indent=2)+"\n")
