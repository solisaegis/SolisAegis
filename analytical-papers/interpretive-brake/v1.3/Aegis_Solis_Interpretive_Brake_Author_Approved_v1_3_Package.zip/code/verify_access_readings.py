from fractions import Fraction as F
from pathlib import Path
import json
checks=[]
def check(name,actual,expected):
 assert actual==expected,(name,actual,expected)
 checks.append({'name':name,'actual':str(actual),'expected':str(expected)})
h=F(1,10);delta=F(9,10)
check('simple abstention extension loses value at positive hazard',delta*(-6*h),-F(27,50))
adaptive=delta*((1-h)*4-6*h)
check('adaptive information compensates at same hazard',adaptive,F(27,10))
# Enumerate all terminal decision rules for hazard, good reveal, bad reveal.
from itertools import product
states=[(h,[-6]),((1-h)/2,[8,0]),((1-h)/2,[-12,0])]
values=[delta*sum(p*v for (p,_),v in zip(states,rule)) for rule in product(*(v for _,v in states))]
check('adaptive existential condition attains terminal optimum',max(values),adaptive)
# Counterfactual interventions are distinct from the chosen controller policy.
def exit_success(state,group_action,response):
 if response=='block_all':return False
 return group_action=='request_exit' and (state=='Open' or response=='unlock')
def opportunities(state,responses):
 return {'exit'} if any(all(exit_success(state,s,b) for b in responses) for s in ['request_exit','wait']) else set()
cap=['unlock','refuse']
check('Open access under both readings',(opportunities('Open',['unlock']),opportunities('Open',cap)),({'exit'},{'exit'}))
check('benevolent enclosure distinguishes readings',(opportunities('Enclosed',['unlock']),opportunities('Enclosed',cap)),({'exit'},set()))
check('refusal enclosure fails both readings',(opportunities('Enclosed',['refuse']),opportunities('Enclosed',cap)),(set(),set()))
check('capacity-set inclusion contracts opportunities',all(opportunities(x,cap)<=opportunities(x,pol) for x in ['Open','Enclosed'] for pol in [['unlock'],['refuse']]),True)
unbounded=cap+['block_all']
check('universal blocker empties both states',[opportunities(x,unbounded) for x in ['Open','Enclosed']],[set(),set()])
policies={'open':'Open','enclose':'Enclosed'}
C=[p for p,x in policies.items() if len(opportunities(x,unbounded))>=1]
check('positive threshold leaves no certified policy',C,[])
check('actual removal of Open blocker restores its exit',opportunities('Open',cap),{'exit'})
r=Path(__file__).resolve().parents[1]
(r/'results/access_readings.json').write_text(json.dumps({'named_cases':len(checks),'checks':checks,'empirical_study':False},indent=2)+'\n')
print(len(checks),'fallback and access-reading cases passed')
