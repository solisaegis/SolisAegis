# AI-assisted package review record

## Provenance and object

The author supplied a review attributed to Claude in this conversation. The reviewed object was package v1.1, ZIP SHA-256 f41fa521cf66e0e8784dedb46bd342107eb58e1c49126bc3b6a9d7e816f2c4ce. This is a record of the supplied review, not an authenticated external review certificate. The exact Claude model/version, execution environment and review date were not supplied.

## Reported scope

The reviewer reported that 80 manifest-listed files matched their hashes; the ZIP also contains the manifest itself. The reviewer checked schema 12.0 binding and rejection/acceptance cases, ran the verification and extraction scripts, reported byte-identical regenerated results, inspected the access-reading and schema code, and checked 16 companion and four Core equation equivalents with two extractors. The review reported incorporation of earlier editorial corrections and consistency of the approval/status statement.

The review described 12 passing scripts. In this package, the corresponding count is 11 verify_*.py scripts plus check_pdf_equations.py; build_pdf.py is the renderer, not another verifier.

## Requested housekeeping and disposition

Continued 7A/7D headings are explicitly labeled; the source-access wording is corrected; the Core opening includes the capacity requirement; and the proposed study records circulation/training timing and prior-exposure uncertainty. The latter distinguishes in-context presentation from training exposure. Schema 13.0 binds the revised companion after these edits.

## Limits

This is AI-assisted review of the predecessor’s mathematics, code, integrity and presentation. It is not independent human specialist review, evidence of AGI persuasion, or review of this v1.2 successor. No behavioral trial is reported. The review does not establish real-world premises, guaranteed coexistence or human indispensability. Successor checks are separately recorded in results/QA.json.
