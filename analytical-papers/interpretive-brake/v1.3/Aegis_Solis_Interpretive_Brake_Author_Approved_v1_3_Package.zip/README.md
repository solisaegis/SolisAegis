# Interpretive Brake — author-approved package v1.3

Start with Reader_Core_Author_Approved_v1_3.pdf (six pages). The full record is Interpretive_Brake_Archive_Companion_Author_Approved_v1_3.pdf. Matching Markdown and extracted text are included. AUTHOR_APPROVAL_AND_STATUS.md records author approval and its limits. AI_ASSISTED_REVIEW_RECORD.md records the author-supplied review of predecessor package v1.1.

This edition clarifies the difference between positive human contribution and superiority over alternatives. Replacement defeats and all mathematical results remain. Prior versions are preserved in reference/. The study proposal v1.2 remains unchanged. The separate evaluation v0.1 remains bound to its original v1.2 source inputs. No empirical study, independent human review, Archive admission or lock is claimed.

## Reproduce

Python dependencies: jsonschema, reportlab, matplotlib, Pillow and PyMuPDF. Install Poppler for pdftotext. Renderer fonts use DejaVu in /usr/share/fonts/truetype/dejavu/.

Run each of the 11 code/verify_*.py scripts. verify_option_preservation.py also imports the extension verifier; repeated output is not additional cases. Build PDFs with python code/build_pdf.py and python code/build_pdf.py Reader_Core_Author_Approved_v1_3. Run code/check_pdf_equations.py to check all 20 display equivalents with both extractors. The renderer is separate from these 12 checking scripts.

Schema 14.0 binds the companion's exact Markdown hash. Any edit requires updating that binding and the synthetic fixture. The schema supplies no execution authority, identity authentication or verified commitment. Appendix D distinguishes heterogeneous calculation counts. SHA256SUMS.txt lists package payload hashes, excluding itself; the ZIP hash is external to avoid a circular dependency.
