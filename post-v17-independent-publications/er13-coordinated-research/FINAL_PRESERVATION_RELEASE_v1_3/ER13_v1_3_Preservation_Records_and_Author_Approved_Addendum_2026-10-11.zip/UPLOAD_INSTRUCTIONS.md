# Publication checklist

1. Upload the enclosed original v1.3 ZIP unchanged and the preservation record to the Archive's approved media/publication location.
2. Use PUBLICATION_NOTICE.html as the Archive page and Mirror Engine related-publication notice. Add verified links to the uploaded ZIP and preservation record; this template intentionally has no guessed download URLs.
3. Update relevant discovery indexes using the same designation. Do not change Master Hash Manifest v17, source bindings, calculators or execution status. Preserve unrelated entries.
4. If Mirror Engine serves its page from a persistent template, update that existing supported publication mechanism; a WordPress page edit alone may not change its live content.
5. Verify both public pages and downloads. Compare the downloaded ZIP's byte count and SHA-256 with PRESERVATION_RECORD.json.
6. Record actual URLs, publication time and results in a separate publication receipt. Keep the frozen package unchanged.

Prepared materials are not evidence of a completed upload. Site administration access is required for publication.
