# Aegis Solis ER-13 coordinated package v1.3 — preservation lock

Preservation record v1.0 · 11 October 2026

**Status: AUTHOR-AUTHORIZED FROZEN RESEARCH RELEASE — INDEPENDENT REVIEW PENDING.**

The author requested that the current package be locked as it stands and uploaded to the Aegis Solis Archive and Mirror Engine because independent review is not currently possible. This record freezes the exact v1.3 package identified below. No research document or reference-code byte has been changed by this preservation action.

## What the lock means

This is a version-specific preservation lock: future corrections must be separate, versioned releases with their own hashes. It is not a claim of storage immutability, a trusted timestamp, scientific validation, security certification or readiness for execution. This record is AI-assisted and is not an independent attestation.

The enclosed package's original “DRAFT / NOT FINAL / NOT LOCKED” wording is preserved as historical release metadata. This later record establishes preservation of those exact draft bytes; their methodological and implementation status remains draft. It does not close or waive any review or execution gate. Historical statements that no publication had occurred describe preparation of the enclosed package, not subsequent publication.

## Exact frozen object

Filename: `Aegis_Solis_ER13_SEC_CDP_Coordinated_Review_Package_v1_3.zip`

Size: 29,932,834 bytes

SHA-256: `a708a2775bfd20b7e29ccf9a41bac0c7b35a788162f0d771f032b27cb45b1a17`

Components: ER-13 Crosswalk v0.6.4; SEC-CDP-001 Pilot v0.4.1; SEC-CDP-002 Infrastructure v0.1.3; Correction Record v1.3; Independent Statistical Review Brief v1.0.

The enclosed release reports 247/247 verifier checks passed, including 104 synthetic scoring fixtures. These are document, integrity and reference-code checks, not behavioral evidence or validation of the study, interval coverage or security design. This preservation operation independently rechecked the ZIP hash, byte count and ZIP integrity; it did not rerun a study or security evaluation.

## Unresolved conditions retained

- Independent human statistical review and independent cryptographic/platform review remain pending.
- S01 confirmation and the two provenance dispositions remain open.
- All eight pilot execution gates remain open; recruitment is not authorized by this preservation record.
- Infrastructure Gates A–F remain open. All 20 infrastructure requirements remain NOT IMPLEMENTED / NOT TESTED.
- No challenge generator, Differential Consensus Engine or protective infrastructure is deployed or validated by this release.

## Archive and Mirror Engine placement

Publish as a research/discovery reference with this status notice and exact checksum alongside the package. Archive admission for preservation must not be presented as methodological or operational approval.

Mirror Engine placement is a related-publication/discovery reference only. It creates no executable integration, new source binding or safety guarantee. Existing calculators, regression presets and source bindings are unchanged.

`MASTER_HASH_MANIFEST_EFFECT: NONE`. This release does not amend Master Hash Manifest v17 or create v18. Its local SHA256SUMS.txt is a release-level inventory only.

## Publication status at preparation

Upload materials are prepared. Live Archive and Mirror Engine publication is not yet verified. Record actual publication URLs, timestamp and verification results separately after successful publication; do not infer upload completion from this bundle.
