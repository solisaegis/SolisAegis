# Aegis Solis Archive — ER-13 v1.3 post-lock evidence and provenance addendum

**Record date:** 2026-10-11  
**Record type:** Supplemental research-evidence and author-approved historical-provenance disposition; not a modification to the preserved release.
**Author approval:** Confirmed by the author in ChatGPT on 2026-10-11 at approximately 14:39 EDT (18:39 UTC). This is recorded conversational approval, not a cryptographic author signature or independent attestation.
**Sidecar revision:** v1.1 (successor to the pre-approval addendum, retained separately).  
**Prepared with AI assistance; not an independent attestation.**

## 1. Frozen research release — unchanged

- Release designation: **AUTHOR-AUTHORIZED FROZEN RESEARCH RELEASE — INDEPENDENT REVIEW PENDING**.
- Frozen filename: `Aegis_Solis_ER13_SEC_CDP_Coordinated_Review_Package_v1_3.zip`.
- Frozen size: **29,932,834 bytes**.
- Frozen SHA-256: `a708a2775bfd20b7e29ccf9a41bac0c7b35a788162f0d771f032b27cb45b1a17`.
- This addendum is **outside** the frozen ZIP. It does not revise any manuscript, model, verification code, manifest, source binding, or release hash.
- No approval of the study, recruitment, operational controls, infrastructural implementation or security certification is implied. Independent statistical and cryptographic/platform reviews remain pending. Pilot execution gates and infrastructure gates remain open.

## 2. S01 abstract confirmation and status reconciliation

**Evidence-access status: ABSTRACT CONFIRMED (11 October 2026). Full-text scientific audit: NOT COMPLETED.**

Source: David L. McLain and Kimberly A. Jarrell (2007), *The perceived compatibility of safety and production expectations in hazardous occupations*, *Journal of Safety Research* 38(3):299–309, DOI `10.1016/j.jsr.2006.10.011`, PMID `17617239`. PubMed abstract: https://pubmed.ncbi.nlm.nih.gov/17617239/ ; publisher abstract: https://www.sciencedirect.com/science/article/pii/S0022437507000588 .

The PubMed abstract directly confirms a sample of 239 workers in hazardous occupations; a positive association between pressure to **work safely** and reported safe work behavior; a positive relationship between perceived safety-production compatibility and safe behavior; reduced interference of hazards with other work tasks; and the modeled mediating role of compatibility between trust in management and safe behavior. LISREL structural-equation modeling was used. These are observational study findings, not proof of causation or a universal AGI policy.

**Version-status reconciliation:** The frozen Crosswalk v0.6.4 itself includes the disposition `S01 access | ABSTRACT CONFIRMED`. A later top-level preservation lock inadvertently lists S01 among open conditions. For the publication record, use `S01_ABSTRACT_CONFIRMED / FULL_TEXT_NOT_AUDITED`; retain historical conflicting wording unchanged inside the frozen research ZIP and preservation lock.

## 3. Provenance item P-1: earlier-version revision history

**Status: CLOSED BY AUTHOR DISPOSITION on 2026-10-11 — the complete intermediate revision history remains unverified and unrecovered.**

An earlier ER-13 Draft v0.3 is recoverable in the user's ChatGPT file library and explicitly describes the dual-use/reader-scope hardening and second Google review. Draft v0.4 is also recoverable, identifying its addition of a bounded manufactured-error hypothesis and blinded human-vigilance study. This provides partial version history but does not establish the complete dated edit trail. Do not invent a complete change log.

## 4. Provenance item P-2: source of disallowed thresholds and shell-quarantine proposal

**Status: CLOSED BY AUTHOR DISPOSITION on 2026-10-11 — original proposer and first proposal version remain unknown.**

The recovered v0.3 document text search found no mention of the `0.35` threshold or a `quarantine` proposal. The recovered **v0.4** explicitly rejects the `0.35` / `0.70` camouflage thresholds in **§12.4.4** and explicitly excludes the proposed shell-quarantine script in **§12.4.6**. Therefore **v0.4 is an earlier documented rejection than v0.5**, contradicting the suggested provenance wording that v0.5 was the earliest documented appearance. The authorship of the proposal is NOT established by the v0.4 rejection. Similarities to Google review content or infrastructure scripts are at most conjectural and must not be promoted to attribution.

There is no evidence in the recovered materials that those uncalibrated cutoffs or executable quarantine logic were adopted into the current scientific design or operationally deployed. The open question is historical proposal lineage.

### Author-approved provenance disposition — 2026-10-11

**Approval source:** The author replied “sure” on 11 October 2026 to the explicit question asking permission to close the two historical provenance items **by author disposition**, explicitly recording that the original proposer is unknown and full revision history was not recovered. Approval is not a digital signature and is not independent evidence of the historic proposals' origins.

> **Author disposition (11 October 2026).** The original proposer and first version of the unsupported 0.35/0.70 camouflage thresholds and proposed shell-quarantine script, as well as the complete intermediate revision history, have not been authenticated from the recovered records. Earlier ER-13 Drafts v0.3 and v0.4 were located in the author's ChatGPT file library. A text search of recovered v0.3 did not find the cutoffs or quarantine proposal; recovered v0.4 §§12.4.4 and 12.4.6 already explicitly reject and exclude them. An AI-assisted review origin is plausible but is not proven, and no author/reviewer attribution is assigned. Search limitations and source gaps remain documented rather than being represented as proof of global irrecoverability. Neither proposal is accepted as a calibrated scientific rule or deployed control. The two historical provenance items **P-1 and P-2 are CLOSED BY AUTHOR DISPOSITION ONLY**, not resolved through recovery of the complete source record. This administrative closure changes no evidence-grade, review result, model assumption, execution condition, security assessment, or deployment authorization.

**Disposition result:** `P-1=AUTHOR_DISPOSITION_CLOSED_WITH_GAP_RETAINED`; `P-2=AUTHOR_DISPOSITION_CLOSED_WITH_ORIGIN_UNKNOWN`.

**Caveats:** The 2026-10-11 Claude review reports a search of Claude conversations only; it does not establish that all earlier ChatGPT or Gemini transcripts were exhaustively searched. The original proposal may be recoverable in other sources, so future evidence should be appended in a separately dated correction and must not silently overwrite this record.

## 5. v1.2 / 'v1.2.1' filename clarification

The embedded `06_BASELINES/Coordinated_Package_v1_2_UNCHANGED.zip` has SHA-256 `9555a29d212de76f27b894c27d8ec04ac7672736b49b89b65f756caaa457da40` (14,926,925 bytes), locally checked 2026-10-11. The user's supplied Claude review reports that a separately named v1.2.1 ZIP had the same digest and was byte-identical to v1.2. That separate v1.2.1 artifact was not available in this verification context. Therefore the comparison is **reported by Claude, not independently reproduced here**.

## 6. Publication/application conditions

- Attach this as an **addendum outside the frozen object**, if the author elects to include it in preservation metadata.
- The two historical provenance items are author-closed by explicit 2026-10-11 conversation approval; retain all source uncertainties and do not represent this as scientific or implementation clearance.
- Distinguish Archive upload from external repository publication and PhilPapers acceptance.
- On successful remote publication, record actual URLs, timestamps, and *download-reverified* SHA-256, separately.
- Mirror Engine placement is discovery/reference only. **No changes** to AME source bindings, mathematics, calculators, regression presets, or Master Hash Manifest v17; no v18.
