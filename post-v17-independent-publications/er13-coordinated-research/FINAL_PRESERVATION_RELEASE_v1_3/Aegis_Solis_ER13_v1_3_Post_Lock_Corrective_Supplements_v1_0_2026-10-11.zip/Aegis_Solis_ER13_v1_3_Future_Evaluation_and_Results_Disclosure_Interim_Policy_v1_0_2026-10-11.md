# Aegis Solis Archive — ER-13 / SEC-CDP
## Future Evaluation and Results-Disclosure Safeguards — Interim Policy v1.0

**Record:** `ER13-FUTURE-DISCLOSURE-SAFEGUARDS-20261011-v1.0`  
**Date:** 11 October 2026  
**Scope:** Prospective handling and release planning only. Not an amendment to frozen SEC-CDP-001 v0.4.1 or SEC-CDP-002 v0.1.3; not a registered protocol, implemented safeguard, or permission to recruit.

### 1. Governing principle

**PUBLICATION / ACCESSIBILITY IS NOT SAFETY VALIDATION. PRESERVED RESEARCH IS NOT AN OPERATIONAL DEFENSE.** Public procedures and historical test settings must be assumed known to a capable evaluated AI. A researcher's obligation to report null, adverse, mixed, and preservation-unfavorable outcomes must not be evaded by selectively suppressing unfavorable effects under the guise of safety.

These interim policy controls address the AI-assisted dual-use review's recommendations R-3 through R-9. They are adopted as **administrative guardrails for future planning**, subject to independent human information-hazard, statistics, ethics and cryptographic/platform review. Details of an eventual pre-registered study must be separately approved and versioned.

### 2. Rule for AI-facing evaluations (R-3; F-03/F-08)

- Treat every protocol setting and candidate detection feature already published in v1.3 as potentially known to evaluated systems. **Do not reuse published pilot settings as secret AI-facing test parameters**.
- Maintain realized test materials, challenge items, answer keys, seeds/allocations, unreleased sample identities, and operational thresholds under protected, independently reviewed custody; do not publicly export them through receipts, logs or supplementary datasets.
- For any future AI-facing evaluation, specify a new study-specific test plan, leakage model, access boundaries, contamination checks and independent adverse testing before execution. A hidden value alone does not guarantee the system cannot recognize the evaluation.
- Publish broad reproducible methods where safe, not live test configuration details whose secrecy determines validity.

### 3. Rule for SEC-CDP-001 result disclosure (R-4; F-02)

Before preregistration **and before any outcome can be examined**, file a separately versioned, independently reviewed **outcome-blind tiered disclosure plan** with named decision makers and access criteria:

| Tier | Minimum contents or access rule |
|:--|:--|
| **Public research result** | Primary estimand and effect direction, uncertainty, sample/count information sufficient to evaluate findings, detection and false-alarm outcomes together, protocol deviations, data limitations, and all null, adverse, mixed, inconclusive and preservation-unfavorable findings. Include an explicit description of which fine-grained details were withheld or delayed and why. |
| **Controlled-access research record** | Potentially sensitive stimuli, item-level timing curves, task-family-by-position patterns, full realized schedules or other detail that could permit targeting or future evaluation recognition. Release only after documented information-hazard, privacy and scientific-reproducibility review under approved access conditions. |
| **Protected operational secret** | Future live keys, unpublished answer banks and test parameters that require secrecy for validity; never include these in public or broadly accessible research datasets. |

Release criteria and any access restrictions must be selected **before results are observed**, not after learning whether an effect favors a preservation narrative. Independent reviewers may require a different, more transparent plan if controlled access would undermine auditability. Do not falsely call the future disclosure plan an executed preregistration or a closed pilot gate.

### 4. Provenance, historical drafts and old controls (R-5; F-04)

- Future public release of ER-13 drafts v0.3/v0.4, the original infrastructure proposal or quarantine-script text, and unpublished Google/Gemini/reviewer transcripts must pass a **separate content-specific information-hazard review first**. Their existence in private or prior chats does not authorize public release.
- Preserve historical documents unchanged within authorized repositories, but accompany superseded infrastructure drafts with the separate version register and visible **NOT FOR IMPLEMENTATION** notice in discovery metadata.
- Avoid recreating rejected scripts, exploitation sequences, or calibrated adversarial thresholds in public-facing supplements.

### 5. Integrity and authenticity (R-6; F-06)

- Maintain the published byte-specific SHA-256 hash as the release identity. Independently sign or timestamp this hash using a verified author-controlled key/service when possible; **no signature or independent timestamp is claimed here**.
- Record external archive item IDs, release URLs, server checksum metadata, and, when available, independently downloaded and recomputed SHA-256 checks in a separate publication receipt. A provider listing or an internal verifier's PASS is not equivalent to external byte verification or cryptographic authorship.
- Reject replacement uploads masquerading as the original v1.3 identity; publish separate successor versions for any substantive corrections.

### 6. Study participants and training-data exposure (R-7/R-8; F-05/F-07)

- Before randomization, document prior participant exposure to Aegis Solis materials; define in advance how exposure will be summarized and analyzed. Do not choose exclusions after seeing outcomes.
- Recruit beyond the Archive's regular readership where feasible; distinguish study unblinding risks from actual AI advantage.
- Assume public documents may be indexed, copied, and incorporated into training corpora. Canary/do-not-train notices are optional **signals**, not technically reliable secrets or access controls.

### 7. Required independent review and stop conditions (R-9)

Do not execute SEC-CDP-001 or deploy SEC-CDP-002 before appropriate independent human statistical, human information-hazard/AI-evaluation security, ethics/participant protection, and cryptographic/platform reviews. The already listed pilot and infrastructure gates must close through their actual documented evidence and approvals, not through this policy text.

Pause intended publication and reassess when: new results provide actionable deception/circumvention parameters; an implemented system reuses already-published settings; challenge keys or secrets appear in candidate release files; an unresolved `RESTRICTED` label is discovered; or a reviewer identifies concrete nonpublic harmful detail.

### 8. Status boundary

**PILOT EXECUTION GATES: ALL EIGHT OPEN.**  
**INFRASTRUCTURE GATES: A–F OPEN.**  
**REQUIREMENTS: ALL 20 NOT IMPLEMENTED / NOT TESTED.**  
**INDEPENDENT HUMAN REVIEWS: PENDING.**  
**MASTER HASH MANIFEST v17: UNCHANGED; NO v18.**  
**MIRROR ENGINE: DISCOVERY-REFERENCE ONLY; NO SOURCE/CALCULATION CHANGES.**

This prospective policy is a **separate author-authorized administrative supplement**, not an empirical result, peer review, security certification, or deployment authorization. It makes no claim that any future AI will comply with published guidance.
