# ER-13 v1.3 — Post-Lock Corrective Supplements (2026-10-11)

**Author decision:** Public historical preservation of SEC-CDP-002's already-released `ARCHIVE RESTRICTED` drafts is affirmed by author response "proceed" to the handling-disposition question. This is **not** an authorization to publish future restricted material.

**Controlling frozen research ZIP:** `Aegis_Solis_ER13_SEC_CDP_Coordinated_Review_Package_v1_3.zip`  
**SHA-256:** `a708a2775bfd20b7e29ccf9a41bac0c7b35a788162f0d771f032b27cb45b1a17`  
**This supplemental ZIP is not a replacement for that frozen research ZIP.**

## Three records

1. `Handling_Disposition_FINAL_v1_0`: retrospective administrative disposition of already-published SEC-CDP-002 drafts' handling label; no declassification of future secrets.
2. `Superseded_Version_Register_v1_0`: v0.1/v0.1.1/v0.1.2 **SUPERSEDED — NOT FOR IMPLEMENTATION**; v0.1.3 **RESEARCH ONLY / NOT IMPLEMENTED OR TESTED**.
3. `Future_Evaluation_and_Results_Disclosure_Interim_Policy_v1_0`: AI-facing evaluation secret protection, predetermined tiered results disclosure, historical provenance hazard gate, integrity anchoring, participant screening, and independent human review.

Each record is provided in Markdown and PDF. `DISPOSITION_RECORD.json` is machine-readable; `SHA256SUMS.txt` covers package contents. The review prompting the supplements is `Aegis_Solis_ER13_v1_3_Independent_Adversarial_Dual-Use_Review_v1_0.md` (AI-assisted, not independent human security certification). It is **referenced**, not reproduced, in this package.

## No change to science or infrastructure

The original frozen ZIP, deposited PDF, prior lock, and existing upload records are not changed. No new Archive, Internet Archive, Zenodo, GitHub, PhilPapers or Mirror Engine upload occurs merely by generating these documents. **Master Hash Manifest v17 remains unchanged; no v18.** All human review, pilot and infrastructure gates stay open.

## Publication receipts

Reported public research records: [Internet Archive](https://archive.org/details/aegis-solis-er-13-evidence-crosswalk-draft-v-0-6-4-exact-from-v-1-3) and [Zenodo](https://zenodo.org/records/23303565). Claude's review reports IA's server metadata matched four original local file MD5/SHA-1/byte sizes, without independent re-download SHA-256. Zenodo's public copy was not verified. **Do not call these supplements published until their upload and retrieval are verified.**

Suggested GitHub repository: `https://github.com/solisaegis/SolisAegis` (create a separately versioned post-lock supplements entry or release asset; do not overwrite the frozen source).
