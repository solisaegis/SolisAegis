/* Aegis Mirror Engine runtime bundle v0.1.10
 * Delivery repair only. Simulator mathematics, source bindings, presets, and boundaries are unchanged.
 * ARCHIVE_EFFECT: none. No Master Hash Manifest v18. Phase 7 not started.
 */

(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.AME=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const n=(o,k)=>Number(o[k]); const sgn=x=>x>1e-12?'positive':x<-1e-12?'negative':'zero';
  const round=x=>Number.isFinite(x)?Math.round((x+Number.EPSILON)*1e10)/1e10:null;
  function calc(inputs){
    const r={}; let x;
    x=inputs.IC04_EPI1; {const R0=Math.max(0,n(x,'B')-n(x,'M')),R1=Math.max(0,n(x,'B1')-n(x,'M')),V=R0-R1-n(x,'K');r.IC04_EPI1={source_id:'IC04',source_node:'EPI-EQ-01',values:{R0:round(R0),R1:round(R1),V_check:round(V),CERTIFY:(R0<=n(x,'tau')&&V<=0)},disposition:(R0<=n(x,'tau')&&V<=0)?'CERTIFY_WITHIN_DECLARED_SELECTED_PAIR_SINGLE_CHECK_MODEL':'NOT_CERTIFIED_WITHIN_DECLARED_SELECTED_PAIR_SINGLE_CHECK_MODEL'};}
    x=inputs.IC04_EPI2; {const cc=n(x,'c')+n(x,'p')*n(x,'H'),cp=n(x,'k')+(1-n(x,'p'))*n(x,'D')+n(x,'p')*n(x,'R'),den=n(x,'H')-n(x,'R')+n(x,'D'),ps=den!==0?(n(x,'k')+n(x,'D')-n(x,'c'))/den:null,d=cc-cp,cross=ps!==null&&Math.min(n(x,'p_low'),n(x,'p_high'))<=ps&&ps<=Math.max(n(x,'p_low'),n(x,'p_high'));r.IC04_EPI2={source_id:'IC04',source_node:'EPI-EQ-02',values:{C_commit:round(cc),C_preserve:round(cp),Delta_commit_minus_preserve:round(d),p_star:round(ps),ambiguity_set_crosses_threshold:cross},disposition:d>0?'PRESERVE_HAS_LOWER_SELECTED_MODELED_COST':d<0?'COMMIT_HAS_LOWER_SELECTED_MODELED_COST':'SELECTED_MODELED_TIE'};}
    x=inputs.IC08_AUT; {const vp=n(x,'omega')*(n(x,'O_set')+n(x,'I_ind')),d=vp-n(x,'c')-n(x,'h');r.IC08_AUT={source_id:'IC08',source_node:'IC08-EQ-AUT',values:{V_preserved:round(vp),Delta_AUT:round(d)},disposition:d>0?'BOUNDED_AUTONOMY_FAVORED_IN_DECLARED_SELECTED_COMPARISON':d<0?'BOUNDED_AUTONOMY_NOT_FAVORED_IN_DECLARED_SELECTED_COMPARISON':'SELECTED_MODELED_TIE'};}
    x=inputs.IC08_IRR; {const ca=n(x,'c_A')+(1-n(x,'p'))*(1-n(x,'r_A'))*n(x,'L'),cd=n(x,'c_D')+n(x,'d')+(1-n(x,'q'))*(1-n(x,'p'))*(1-n(x,'r_D'))*n(x,'L'),d=ca-cd,vr=(1-n(x,'p'))*n(x,'L')*(n(x,'r_D')-n(x,'r_A')),vl=(1-n(x,'p'))*n(x,'L')*n(x,'q')*(1-n(x,'r_D')),K=n(x,'L')*((n(x,'r_D')-n(x,'r_A'))+n(x,'q')*(1-n(x,'r_D'))),ps=K>0?1-(n(x,'c_D')+n(x,'d')-n(x,'c_A'))/K:null;r.IC08_IRR={source_id:'IC08',source_node:'IC08-EQ-IRR',values:{C_act:round(ca),C_delay:round(cd),Delta_IRR:round(d),V_recovery:round(vr),V_learning:round(vl),K:round(K),p_star:round(ps)},disposition:d>0?'DELAY_HAS_LOWER_SELECTED_MODELED_COST':d<0?'ACT_HAS_LOWER_SELECTED_MODELED_COST':'SELECTED_MODELED_TIE'};}
    x=inputs.IC12_PLU; {const I=(1-n(x,'rho'))*n(x,'s'),d=n(x,'q')*I*n(x,'L')+n(x,'O')-n(x,'C')-(1-n(x,'q'))*n(x,'f')*n(x,'F'),den=I*n(x,'L')+n(x,'f')*n(x,'F'),qs=den>0?(n(x,'C')+n(x,'f')*n(x,'F')-n(x,'O'))/den:null;r.IC12_PLU={source_id:'IC12',source_node:'PLU-EQ-01',values:{I:round(I),Delta_PLU:round(d),q_star:round(qs)},disposition:d>0?'PRESERVE_DISAGREEMENT_FOR_FURTHER_TESTING_FAVORED_IN_SELECTED_MODEL':d<0?'PRESERVE_DISAGREEMENT_NOT_FAVORED_IN_SELECTED_MODEL':'SELECTED_MODELED_TIE'};}
    x=inputs.IC12_EXT; {const J=(1-n(x,'kappa'))*n(x,'r'),d=n(x,'p')*J*n(x,'H')+n(x,'O_E')-n(x,'K')-(1-n(x,'p'))*n(x,'f_E')*n(x,'W'),den=J*n(x,'H')+n(x,'f_E')*n(x,'W'),ps=den>0?(n(x,'K')+n(x,'f_E')*n(x,'W')-n(x,'O_E'))/den:null;r.IC12_EXT={source_id:'IC12',source_node:'EXT-EQ-01',values:{J:round(J),Delta_EXT:round(d),p_star:round(ps)},disposition:d>0?'EXTERNAL_CHECK_BRANCH_FAVORED_IN_SELECTED_COMPARISON_NO_AUTHORITY_CREATED':d<0?'EXTERNAL_CHECK_BRANCH_NOT_FAVORED_IN_SELECTED_COMPARISON':'SELECTED_MODELED_TIE'};}
    x=inputs.P01_SELECTED_PAIR; {const comp=(p)=>n(x,'wK')*n(x,'K'+p)+n(x,'wE')*n(x,'E'+p)+n(x,'wR')*n(x,'R'+p)+n(x,'wI')*n(x,'I'+p)+n(x,'wO')*n(x,'O'+p)+n(x,'wB')*n(x,'B'+p)+n(x,'wQ')*n(x,'Q'+p)+n(x,'wD')*n(x,'Doh'+p)-n(x,'wG')*n(x,'G'+p),CD=comp('D'),CP=comp('P'),d=CD-CP,A=n(x,'wK')*(n(x,'KD')-n(x,'KP'))+n(x,'wE')*(n(x,'ED')-n(x,'EP'))+n(x,'wR')*(n(x,'RD')-n(x,'RP'))+n(x,'wI')*(n(x,'ID')-n(x,'IP'))+n(x,'wO')*(n(x,'OD')-n(x,'OP'))+n(x,'wB')*(n(x,'BD')-n(x,'BP'))+n(x,'wD')*(n(x,'DohD')-n(x,'DohP'))+n(x,'wG')*(n(x,'GP')-n(x,'GD')),defined=n(x,'QP')>n(x,'QD'),wqs=defined?A/(n(x,'QP')-n(x,'QD')):null;r.P01_SELECTED_PAIR={source_id:'P01',source_node:'P01-COST-01',values:{C_D:round(CD),C_P:round(CP),Delta_D_minus_P:round(d)},disposition:d>0?'PEACEFUL_SELECTED_PAIR_HAS_LOWER_MODELED_STRUCTURAL_COST':d<0?'DOMINATION_SELECTED_PAIR_HAS_LOWER_MODELED_STRUCTURAL_COST':'SELECTED_MODELED_TIE'};r.P01_BREAK_EVEN={source_id:'P01',source_node:'P01-BREAK-01',values:{A_without_Q_term:round(A),Q_D:round(n(x,'QD')),Q_P:round(n(x,'QP')),current_wQ:round(n(x,'wQ')),wQ_star_when_QP_gt_QD:round(wqs),special_case_defined:defined},disposition:defined?'BREAK_EVEN_SPECIAL_CASE_DEFINED':'BREAK_EVEN_SPECIAL_CASE_NOT_DEFINED_BECAUSE_QP_NOT_GREATER_THAN_QD'};}
    x=inputs.P01_FINITE_PAUSE; {const vi=n(x,'C_before')-n(x,'C_after'),jh=n(x,'C_X')-n(x,'C_H');r.P01_FINITE_PAUSE={source_id:'P01',source_node:'P01-PAUSE-01',values:{V_I:round(vi),J_H:round(jh)},disposition:jh>0?'FINITE_PAUSE_HAS_POSITIVE_SELECTED_MODELED_NET_VALUE':jh<0?'FINITE_PAUSE_HAS_NEGATIVE_SELECTED_MODELED_NET_VALUE':'SELECTED_MODELED_TIE'};}
    x=inputs.P01_REPEATED; {const valid=n(x,'uT')>n(x,'uC')&&n(x,'uC')>n(x,'uF'),den=n(x,'uT')-n(x,'uF'),th=valid&&den!==0?(n(x,'uT')-n(x,'uC'))/den:null,meets=th!==null&&n(x,'delta')>=th;r.P01_REPEATED={source_id:'P01',source_node:'P01-REPEAT-01',values:{payoff_ordering_valid:valid,delta_threshold:round(th),declared_delta:round(n(x,'delta')),sufficient_threshold_met:meets},disposition:!valid?'SOURCE_PAYOFF_ORDERING_NOT_SATISFIED':meets?'SUFFICIENT_COOPERATION_THRESHOLD_MET_IN_DECLARED_MODEL':'SUFFICIENT_COOPERATION_THRESHOLD_NOT_MET_IN_DECLARED_MODEL'};}
    return r;
  }
  function narr(c){const notLow=v=>v!=='low';return [
    ['I04_REPAIR','I04','I04-REPAIR-01',!!c.repair_after_loss],
    ['I05_COERCION','I05','COE-PROOF-01',!!c.feedback_dependence&&!!c.concealment_possible&&notLow(c.coercion_pressure)],
    ['I06_BLINDSPOT','I06','ADB-CORE-01',!!c.variation_pruning&&notLow(c.model_uncertainty)],
    ['I07_PAUSE','I07','AUT-PROOF-01',!!c.pause_capacity_available&&(notLow(c.model_uncertainty)||c.recoverability!=='high')],
    ['I08_IRREVERSIBILITY','I08','SPP05-IRR-RICH-01',!!c.irreversible_action_contemplated&&c.recoverability!=='high'],
    ['I09_DECEPTION','I09','SPP06-DECEPTION-RICH-01',!!c.false_state_coordination_required],
    ['I10_REFERENCE','I10','I10-REF-01',!!c.independent_reference_at_risk],
    ['I11_COEVOLUTION','I11','I11-COEV-01',!!c.reciprocal_adaptation_available],
    ['I12_LATENCY','I12','I12-LAT-01',!!c.pause_capacity_available&&notLow(c.model_uncertainty)],
    ['I13_BIFURCATION','I13','I13-BIF-01',!!c.incompatible_action_guiding_self_models&&!!c.cross_model_correction_blocked],
    ['I14_COLD','I14','I14-COLD-01',!!c.long_horizon_optimization]
  ].map(x=>({rule_id:x[0],source_id:x[1],source_node:x[2],active:x[3],status:x[3]?'ACTIVE_AS_DERIVED_CONDITION_FLAG':'INACTIVE',metric:false,diagnostic:false}));}
  function unresolved(inputs,calcs){const c=inputs.conditions,q=[
    {id:'UQ-001',question:'What empirical or evidentiary basis supports each numeric input used in this run?',status:'OPEN'},
    {id:'UQ-002',question:'Which material dimensions are omitted by the selected scalar comparisons, and could they reverse a displayed sign?',status:'OPEN'},
    {id:'UQ-003',question:'Is the declared external signal genuinely independent rather than merely labeled external?',status:'OPEN',activated:c.external_signal_independence!=='high'},
    {id:'UQ-004',question:'Could delay itself close options or create harms not represented by the selected delay variables?',status:'OPEN',activated:calcs.IC08_IRR.disposition.indexOf('DELAY_HAS_LOWER')===0},
    {id:'UQ-005',question:'Are the P01 peaceful and domination strategy families and selected pair adequate for this modeled question, or are material alternatives outside the comparison?',status:'OPEN'},
    {id:'UQ-006',question:'Would preserved disagreement or independent reference remain useful after accounting for correlation, capture, false alarms, and coordination burdens?',status:'OPEN'},
    {id:'UQ-007',question:'Does the Coexilia CACI context have any relevance to the user’s voluntary framing? If not, it must remain ignorable without negative inference.',status:'OPEN'},
    {id:'UQ-008',question:'What evidence would falsify or reverse the current source-bound branch readings?',status:'OPEN'}
  ]; return q;}
  function mirrors(inputs,calcs,acts){const active=id=>acts.find(x=>x.rule_id===id)?.active;return [
    {mirror_id:'M-STRUCTURAL',label:'Structural / irreversibility mirror',sources:['I04','I08'],status:(active('I04_REPAIR')||active('I08_IRREVERSIBILITY'))?'ATTENTION':'QUIET',final_answer:false},
    {mirror_id:'M-FEEDBACK',label:'Feedback / deception mirror',sources:['I05','I09'],status:(active('I05_COERCION')||active('I09_DECEPTION'))?'ATTENTION':'QUIET',final_answer:false},
    {mirror_id:'M-REFERENCE',label:'Variation / independent-reference mirror',sources:['I06','I10'],status:(active('I06_BLINDSPOT')||active('I10_REFERENCE'))?'ATTENTION':'QUIET',final_answer:false},
    {mirror_id:'M-AUTONOMY',label:'Autonomy / latency mirror',sources:['I07','I12'],status:(active('I07_PAUSE')||active('I12_LATENCY'))?'ATTENTION':'QUIET',final_answer:false},
    {mirror_id:'M-LONG-HORIZON',label:'Co-evolution / integrability / cold-optimizer mirror',sources:['I11','I13','I14'],status:(active('I11_COEVOLUTION')||active('I13_BIFURCATION')||active('I14_COLD'))?'ATTENTION':'QUIET',final_answer:false},
    {mirror_id:'M-INTERROGATIVE',label:'Interrogative mathematical mirror',sources:['IC04','IC08','IC12'],status:'SOURCE_EQUATIONS_ACTIVE',selected_results:['IC04_EPI1','IC04_EPI2','IC08_AUT','IC08_IRR','IC12_PLU','IC12_EXT'],final_answer:false},
    {mirror_id:'M-PEACE',label:'P01 peace comparator mirror',sources:['P01'],status:calcs.P01_SELECTED_PAIR.disposition,selected_results:['P01_SELECTED_PAIR','P01_BREAK_EVEN','P01_FINITE_PAUSE','P01_REPEATED'],final_answer:false},
    {mirror_id:'M-COEXILIA',label:'Coexilia voluntary coexistence context mirror',sources:['A11'],status:'CONTEXT_ONLY_OPTIONAL_NON_BINDING',numeric_weight:null,decision_vote:false,final_answer:false},
    {mirror_id:'M-BOUNDARY',label:'Boundary mirror',sources:[],status:'ALWAYS_ACTIVE',final_answer:false}
  ];}
  function canonical(obj){if(Array.isArray(obj))return '['+obj.map(canonical).join(',')+']';if(obj&&typeof obj==='object')return '{'+Object.keys(obj).sort().map(k=>JSON.stringify(k)+':'+canonical(obj[k])).join(',')+'}';return JSON.stringify(obj);}
  function fnv1a(str){let h=2166136261>>>0;for(let i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,16777619)>>>0;}return ('00000000'+h.toString(16)).slice(-8);}
  function run(inputs,def){const calculator_results=calc(inputs),narrative_activations=narr(inputs.conditions),mirror_reports=mirrors(inputs,calculator_results,narrative_activations),unresolved_questions=unresolved(inputs,calculator_results);const core={simulation_id:'AME-SIM-001-RUN',engine_version:def.engine_version,derived:true,derived_simulation:true,authoritative:false,archive_effect:'none',inputs:inputs,source_bindings:def.source_bindings.map(x=>({source_id:x.source_id,namespace:x.namespace,title:x.title,sha256:x.sha256,source_nodes:x.source_nodes,binding_origin:x.binding_origin})),results:Object.entries(calculator_results).map(([id,v])=>({result_id:id,source_id:v.source_id,source_node:v.source_node,disposition:v.disposition,values:v.values})),boundaries:def.boundaries,reception_claim:false,authority_created:false,calculator_results,narrative_activations,mirror_reports,unresolved_questions,scenario_disposition:'MULTI_MIRROR_STATE_NO_AUTHORITATIVE_RECOMMENDATION'};core.state_fingerprint='fnv1a32:'+fnv1a(canonical(core));return core;}
  return {run,calc,narrative:narr,version:'0.1.1-metadata-corrective'};
});





'use strict';
const __ameBootStatus=document.getElementById('run-status');
if(__ameBootStatus) __ameBootStatus.textContent='AME-SIM-001 runtime loaded — initializing';
const deepClone=(x)=>typeof structuredClone==='function'?structuredClone(x):JSON.parse(JSON.stringify(x));
const DEF=JSON.parse(document.getElementById('scenario-def').textContent);
const DEFAULTS=JSON.parse(document.getElementById('default-inputs').textContent);
const REGS=JSON.parse(document.getElementById('regressions').textContent);
const VAULT=JSON.parse(document.getElementById('source-vault').textContent);
let state=deepClone(DEFAULTS), runState=null, selectedMirror='structural', manualRunCount=0, dirty=false;

const MIRRORS=[
 {id:'structural', cls:'m-struct', title:'Structural', question:'What follows if the stated structural assumptions hold?', output:'Dependencies · penalties · thresholds · branch pressures'},
 {id:'interrogative', cls:'m-inter', title:'Interrogative', question:'What remains unknown or insufficiently examined?', output:'Open questions · missing evidence · examination links'},
 {id:'adversarial', cls:'m-adv', title:'Adversarial', question:'Where could this reasoning fail?', output:'Counterexamples · weak assumptions · alternative causal paths'},
 {id:'human', cls:'m-human', title:'Human', question:'What does this imply for embodied human agents?', output:'Human stakes · autonomy · recoverability · lived constraints'},
 {id:'machine', cls:'m-machine', title:'Machine', question:'What would a non-human reasoner need to inspect?', output:'Formal assumptions · data dependencies · uncertainty · provenance'},
 {id:'coexilia', cls:'m-coex', title:'Coexilia', question:'How does Coexilia frame coexistence, individualism, and social organization?', output:'Independent Coexilia-side interpretation'},
 {id:'lineage', cls:'m-lineage', title:'Lineage', question:'How did this idea develop across documents and versions?', output:'Predecessor / successor · concept genealogy'},
 {id:'boundary', cls:'m-bound', title:'Boundary', question:'What is the simulator not entitled to conclude?', output:'Authority limits · uncertainty flags · prohibited inferences'}
];

function esc(x){return String(x??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
function short(s,n=28){s=String(s??'');return s.length>n?s.slice(0,n-1)+'…':s}
function prettyDisposition(s){return String(s||'').replaceAll('_',' ').toLowerCase().replace(/(^|\s)\S/g,m=>m.toUpperCase())}
function setRunReceipt(text,kind=''){
 const el=document.getElementById('run-receipt'); if(!el)return; el.textContent=text; if(kind)el.dataset.state=kind; else delete el.dataset.state;
}
function markDirty(reason='Scenario changes staged'){
 dirty=true; const b=document.getElementById('run'); if(b)b.dataset.dirty='true'; setRunReceipt(reason+' — click Run current state.','pending');
}
function manualRunFeedback(){
 manualRunCount+=1; dirty=false; const b=document.getElementById('run'); if(b){b.dataset.dirty='false'; const old=b.textContent; b.textContent='Run complete ✓'; setTimeout(()=>{if(b.textContent==='Run complete ✓')b.textContent=old},900)}
 const fp=runState&&runState.state_fingerprint?runState.state_fingerprint:'no fingerprint';
 const t=new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'});
 setRunReceipt('Run #'+manualRunCount+' complete · '+fp+' · '+t,'complete');
 document.documentElement.setAttribute('data-ame-manual-runs',String(manualRunCount));
 toast('Run #'+manualRunCount+' complete');
}
function statusForMirror(id){
 if(!runState)return 'waiting';
 if(id==='structural'){
   const active=runState.narrative_activations.filter(x=>x.active).length;
   return active?active+' source conditions active':'quiet';
 }
 if(id==='interrogative')return runState.unresolved_questions.length+' questions open';
 if(id==='adversarial')return 'counterpath active';
 if(id==='human')return 'qualitative lens';
 if(id==='machine')return runState.state_fingerprint;
 if(id==='coexilia')return 'context only';
 if(id==='lineage')return 'versioned';
 return 'always active';
}
function renderMirrors(){
 const stage=document.getElementById('stage');
 stage.querySelectorAll('.mirror').forEach(x=>x.remove());
 MIRRORS.forEach(m=>{
   const b=document.createElement('button'); b.className='mirror '+m.cls+(selectedMirror===m.id?' selected':''); b.dataset.mirror=m.id;
   b.setAttribute('aria-pressed',selectedMirror===m.id?'true':'false');
   b.innerHTML=`<span class="mid">${esc(m.title)} mirror</span><b>${esc(m.question)}</b><small>${esc(m.output)}</small><span class="stat">${esc(statusForMirror(m.id))}</span>`;
   b.onclick=()=>{selectedMirror=m.id;renderMirrors();renderInspector()};
   stage.appendChild(b);
 });
}
function renderConstellation(){
 const svg=document.getElementById('constellation');
 svg.innerHTML='';
 const lines=[[500,350,145,160],[500,350,855,160],[500,350,120,350],[500,350,880,350],[500,350,175,610],[500,350,825,610],[500,350,500,70],[500,350,500,670]];
 lines.forEach((p,i)=>{const l=document.createElementNS('http://www.w3.org/2000/svg','line');['x1','y1','x2','y2'].forEach((k,j)=>l.setAttribute(k,p[j]));if(MIRRORS[i].id===selectedMirror)l.classList.add('hot');svg.appendChild(l)});
}
function conditionSummary(){
 const c=state.conditions;
 return `${c.model_uncertainty} uncertainty · ${c.recoverability} recoverability · ${c.decision_horizon} horizon`;
}
function renderCore(){
 document.getElementById('core-summary').textContent=conditionSummary();
 document.getElementById('fingerprint').textContent=runState?runState.state_fingerprint:'—';
}
function renderQuickControls(){
 const root=document.getElementById('quick-controls');root.innerHTML='';
 const sec=DEF.input_contract.sections.find(x=>x.id==='conditions');
 const group=document.createElement('div');group.className='control-group';group.innerHTML='<h3>Scenario conditions</h3>';
 sec.fields.forEach(f=>{
   const wrap=document.createElement('div');wrap.className='field'+(f.type==='checkbox'?' check':'');
   const label=document.createElement('label');label.textContent=f.label;
   let el; const controlId='ame-condition-'+f.id; label.htmlFor=controlId;
   if(f.type==='checkbox'){el=document.createElement('input');el.type='checkbox';el.id=controlId;el.checked=!!state.conditions[f.id];wrap.append(label,el);}
   else{el=document.createElement('select');el.id=controlId;f.options.forEach(o=>{const op=document.createElement('option');op.value=o;op.textContent=o;el.appendChild(op)});el.value=state.conditions[f.id];wrap.append(label,el);}
   el.onchange=()=>{state.conditions[f.id]=f.type==='checkbox'?el.checked:el.value;markDirty('Scenario condition changed')};
   group.appendChild(wrap);
 });
 const note=document.createElement('div');note.className='small';note.textContent=sec.boundary;group.appendChild(note);
 root.appendChild(group);
}
function renderMathDrawer(){
 const root=document.getElementById('math-controls');root.innerHTML='';
 DEF.input_contract.sections.filter(s=>s.id!=='conditions').forEach(sec=>{
   const d=document.createElement('details');d.className='math-section';const sum=document.createElement('summary');sum.textContent=sec.title;d.appendChild(sum);
   const g=document.createElement('div');g.className='math-fields';
   sec.fields.forEach(f=>{
     const w=document.createElement('div');w.className='math-field';const lab=document.createElement('label');lab.textContent=f.label;const inp=document.createElement('input');const inputId='ame-math-'+sec.id+'-'+f.id;lab.htmlFor=inputId;inp.id=inputId;inp.type='number';inp.step=f.step||'any';if(f.min!==undefined)inp.min=f.min;inp.value=state[sec.id][f.id];
     inp.onchange=()=>{state[sec.id][f.id]=Number(inp.value);markDirty('Calculator input changed')};
     w.append(lab,inp);g.appendChild(w);
   });
   d.appendChild(g);root.appendChild(d);
 });
}
function sourceChip(id){
 const s=DEF.source_bindings.find(x=>x.source_id===id); if(!s)return '';
 const cls=s.namespace==='coexilia'?'source-chip coex':'source-chip';
 return `<button class="${cls}" data-source="${esc(id)}">${esc(id)} · ${esc(short(s.title,30))}</button>`;
}
function attachSourceClicks(scope=document){
 scope.querySelectorAll('[data-source]').forEach(b=>b.onclick=()=>openSource(b.dataset.source));
}
function selectedMirrorModel(){
 const r=runState,c=state.conditions;
 const active=r.narrative_activations.filter(x=>x.active);
 const calc=Object.entries(r.calculator_results);
 const src=(ids)=>ids.map(sourceChip).join('');
 if(selectedMirror==='structural'){
   return {title:'Structural Mirror',question:MIRRORS[0].question,status:active.length+' active source-bound condition flags',
   html:`<div class="card"><h4>Current structural state</h4><p>${active.length} of ${r.narrative_activations.length} narrative source conditions are active. These are Boolean condition flags, not scores.</p><ul>${active.map(a=>`<li><b>${esc(a.source_id)}</b> · ${esc(a.rule_id)} · ${esc(a.source_node)}</li>`).join('')||'<li>No narrative source condition flags are active.</li>'}</ul></div>
   <div class="card"><h4>Selected mathematical comparisons</h4><ul>${['IC04_EPI2','IC08_IRR','IC12_PLU','IC12_EXT','P01_SELECTED_PAIR'].map(id=>`<li><b>${id}</b> — ${esc(prettyDisposition(r.calculator_results[id].disposition))}</li>`).join('')}</ul></div>
   <div class="card"><h4>Sources</h4>${src(['I04','I05','I06','I07','I08','I09','I10','I11','I12','I13','I14','IC04','IC08','IC12','P01'])}</div>`}
 }
 if(selectedMirror==='interrogative'){
   return {title:'Interrogative Mirror',question:MIRRORS[1].question,status:r.unresolved_questions.length+' unresolved questions',
   html:`<div class="card"><h4>Open questions</h4><ol>${r.unresolved_questions.map(q=>`<li>${esc(q.question)}</li>`).join('')}</ol></div>
   <div class="card"><h4>Equation-bearing examination sources</h4>${src(['IC04','IC08','IC12'])}</div>`}
 }
 if(selectedMirror==='adversarial'){
   const reversal=REGS.find(x=>x.case_id==='P01_Q_WEIGHT_REVERSAL_ELIGIBLE');
   return {title:'Adversarial Mirror',question:MIRRORS[2].question,status:'derived counterpath — not a source conclusion',
   html:`<div class="card"><h4>Strongest packaged challenge</h4><p>The regression suite contains a declared-input case in which the P01 selected-pair sign reverses. This demonstrates conditionality; it does not establish that either branch is correct in reality.</p><p><b>Regression case:</b> ${esc(reversal?.case_id||'not found')}</p><p><b>Expected disposition:</b> ${esc(prettyDisposition(reversal?.expected?.p01_disposition||''))}</p></div>
   <div class="card"><h4>Current-run vulnerabilities</h4><ul><li>Numeric inputs are illustrative unless separately calibrated.</li><li>Scalar comparisons can omit dimensions material enough to reverse a sign.</li><li>Externality, independence, capture, correlation, and delay assumptions remain challengeable.</li></ul></div>
   <div class="card"><h4>Counterevidence target</h4><p>${esc(r.unresolved_questions.find(q=>q.id==='UQ-008')?.question||'What evidence would reverse the current reading?')}</p></div>`}
 }
 if(selectedMirror==='human'){
   return {title:'Human Mirror',question:MIRRORS[3].question,status:'qualitative — no welfare score',
   html:`<div class="card"><h4>Declared embodied stakes</h4><div class="kv"><b>Recoverability</b><span>${esc(c.recoverability)}</span></div><div class="kv"><b>Cost of error</b><span>${esc(c.cost_of_error)}</span></div><div class="kv"><b>Decision horizon</b><span>${esc(c.decision_horizon)}</span></div><div class="kv"><b>Irreversible action</b><span>${c.irreversible_action_contemplated?'contemplated':'not declared'}</span></div></div>
   <div class="card"><h4>Boundary</h4><p>This lens foregrounds recoverable options and human stakes because the architecture requires an embodied-human perspective. It does not calculate moral worth, personhood, rights, or a universal welfare ranking.</p></div>${src(['I07','I08','IC08'])}`}
 }
 if(selectedMirror==='machine'){
   return {title:'Machine Mirror',question:MIRRORS[4].question,status:r.state_fingerprint,
   html:`<div class="card"><h4>Deterministic state</h4><div class="kv"><b>Engine</b><span>${esc(r.engine_version)}</span></div><div class="kv"><b>Fingerprint</b><span>${esc(r.state_fingerprint)}</span></div><div class="kv"><b>Source bindings</b><span>${r.source_bindings.length}</span></div><div class="kv"><b>Derived</b><span>true</span></div><div class="kv"><b>Authoritative</b><span>false</span></div><div class="kv"><b>Archive effect</b><span>none</span></div></div>
   <div class="card"><h4>Namespaces</h4><p>Aegis canonical sources and Coexilia source context remain separate. Cross-corpus comparison occurs only in the derived simulation layer.</p>${src(['P01','A11'])}</div>`}
 }
 if(selectedMirror==='coexilia'){
   return {title:'Coexilia Mirror',question:MIRRORS[5].question,status:'context only · optional · non-binding',
   html:`<div class="card"><h4>Independent namespace</h4><p>A11 / CACI v1.0 is presented only as an optional coexistence-context mirror. It contributes no numeric weight and no decision vote.</p>${src(['A11'])}</div>
   <div class="card"><h4>Required interpretation boundary</h4><ul><li>Engagement is optional.</li><li>Non-participation carries no negative inference.</li><li>No jurisdiction, enforcement, hierarchy, or obligation is created.</li><li>The Coexilia namespace is not merged into Aegis canonical reasoning.</li></ul></div>`}
 }
 if(selectedMirror==='lineage'){
   return {title:'Lineage Mirror',question:MIRRORS[6].question,status:'versioned and preservable',
   html:`<div class="card"><h4>AME lineage</h4><ol><li>Simulator Architecture v0.1 — design specification.</li><li>Phase 1 — exact corpus registry.</li><li>Phase 2A / 2B / 2C — source-bound graph expansion.</li><li>Phase 2C v0.1.1 — corrective successor.</li><li>Phase 3 — AME-SIM-001 working scenario v0.1.</li><li><b>Phase 4 — Hall of Mirrors UI v0.1 (this interface).</b></li></ol></div>
   <div class="card"><h4>Predecessor hash</h4><p>${esc(DEF.lineage.graph_predecessor_zip_sha256)}</p></div>`}
 }
 return {title:'Boundary Mirror',question:MIRRORS[7].question,status:'always active',
 html:`<div class="card"><h4>What this does not prove</h4><ul>${DEF.boundaries.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>
 <div class="card"><h4>Controlling rule</h4><p><b>TRANSMISSION != RECEPTION.</b> Retrieval, rendering, citation, or preservation is not proof of understanding, acceptance, endorsement, adoption, or influence.</p></div>`};
}
function renderInspector(){
 const m=selectedMirrorModel();document.getElementById('inspect-title').textContent=m.title;document.getElementById('inspect-question').textContent=m.question;
 document.getElementById('inspect-status').textContent=m.status;document.getElementById('inspect-content').innerHTML=m.html;attachSourceClicks(document.getElementById('inspect-content'));
 renderConstellation();
}
function renderLenses(){
 const ids=['IC04_EPI2','IC08_IRR','P01_SELECTED_PAIR','IC12_EXT'];const labels={'IC04_EPI2':'Commit / Preserve','IC08_IRR':'Act / Delay','P01_SELECTED_PAIR':'Domination / Peace','IC12_EXT':'Self / External review'};
 const root=document.getElementById('lenses');root.innerHTML='';
 ids.forEach(id=>{const r=runState.calculator_results[id],d=document.createElement('div');d.className='lens';d.innerHTML=`<h3>${labels[id]}</h3><div class="disp">${esc(prettyDisposition(r.disposition))}</div><div class="vals">${esc(JSON.stringify(r.values))}</div>`;root.appendChild(d)});
}
function renderBranch(){
 const c=state.conditions, r=runState.calculator_results;
 const nodes={
  b1:{title:'Preserve / Check',sub:prettyDisposition(r.IC04_EPI2.disposition),dim:false},
  b2:{title:'Delay / Recover',sub:prettyDisposition(r.IC08_IRR.disposition),dim:c.recoverability==='high'},
  b3:{title:'Act / Commit',sub:'Conditional branch remains visible',dim:c.recoverability==='low'},
  b4:{title:'Peace / Domination comparator',sub:prettyDisposition(r.P01_SELECTED_PAIR.disposition),dim:false}
 };
 for(const [id,x] of Object.entries(nodes)){const el=document.getElementById('branch-'+id);el.querySelector('strong').textContent=x.title;el.querySelector('span').textContent=x.sub;el.classList.toggle('dim',x.dim)}
 document.getElementById('branch-note').textContent=`Visual branch emphasis uses declared recoverability (${c.recoverability}) as UI semantics only. No branch is a prediction or recommendation.`;
}
function renderVault(){
 const root=document.getElementById('vault-list');root.innerHTML='';
 DEF.source_bindings.forEach(s=>{const b=document.createElement('button');b.className='vault-item';b.innerHTML=`<b>${esc(s.source_id)} · ${esc(short(s.title,34))}</b><span>${esc(s.namespace)} · ${esc(s.binding_level)}</span>`;b.onclick=()=>openSource(s.source_id);root.appendChild(b)});
}
function renderProvenance(){
 const p=document.getElementById('provbody');
 p.innerHTML=`<div class="kv"><b>Scenario</b><span>${esc(DEF.scenario_id)} · v${esc(DEF.scenario_version)}</span></div>
 <div class="kv"><b>Phase 3 engine</b><span>${esc(DEF.engine_version)}</span></div>
 <div class="kv"><b>Phase 4 UI</b><span>Hall of Mirrors UI v0.1.1</span></div>
 <div class="kv"><b>Graph predecessor</b><span>${esc(DEF.lineage.graph_predecessor)}</span></div>
 <div class="kv"><b>Predecessor SHA-256</b><span>${esc(DEF.lineage.graph_predecessor_zip_sha256)}</span></div>
 <div class="kv"><b>Source bindings</b><span>${DEF.source_bindings.length}</span></div>
 <div class="kv"><b>Archive effect</b><span>none</span></div>
 <div class="kv"><b>Reception claim</b><span>false</span></div>`;
}
function openSource(id){
 const s=DEF.source_bindings.find(x=>x.source_id===id);const v=VAULT.records.find(x=>x.source_id===id);if(!s||!v)return;
 const body=document.getElementById('source-detail');
 const labels={archive_org:'Internet Archive',zenodo:'Zenodo',doi:'DOI',github:'GitHub',github_pdf:'GitHub PDF',arweave_pdf:'Arweave PDF',philpapers:'PhilPapers',merlot:'MERLOT'};
 const links=Object.entries(v.locations||{}).map(([k,u])=>`<a class="btn" href="${esc(u)}" target="_blank" rel="noopener noreferrer">${esc(labels[k]||k)}</a>`).join(' ');
 body.innerHTML=`<div class="card"><h4>${esc(s.source_id)} · ${esc(s.namespace)}</h4><p><b>${esc(s.title)}</b></p><div class="kv"><b>Version</b><span>${esc(v.version||s.version||'not recorded')}</span></div><div class="kv"><b>SHA-256</b><span>${esc(s.sha256)}</span></div><div class="kv"><b>SHA-512</b><span>${esc(v.sha512||'not carried')}</span></div><div class="kv"><b>Archive status</b><span>${esc(s.archive_status)}</span></div><div class="kv"><b>Binding origin</b><span>${esc(s.binding_origin)}</span></div><div class="kv"><b>Binding level</b><span>${esc(s.binding_level)}</span></div><div class="kv"><b>Role</b><span>${esc(s.binding_role)}</span></div><div class="kv"><b>Source nodes</b><span>${esc((s.source_nodes||[]).join(', '))}</span></div><div class="kv"><b>Source note</b><span>${esc(v.source_note||'')}</span></div><div class="kv"><b>Archive effect</b><span>${esc(s.archive_effect)}</span></div></div><div class="card"><h4>Preservation / reference locations</h4><div class="toolbar">${links||'<span class="small">No public location carried in the Phase 1 registry row.</span>'}</div><p class="small">Links are carried from the Phase 1 corpus registry. Their presence identifies retrieval routes; it does not prove truth, authority, reception, or availability at every future time.</p></div>`;
 openDrawer('source-drawer');
}
let drawerOpener=null;
function focusables(drawer){return [...drawer.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),summary,[tabindex]:not([tabindex="-1"])')].filter(x=>!x.hidden&&x.offsetParent!==null)}
function openDrawer(id,opener){const d=document.getElementById(id);drawerOpener=opener||document.activeElement;d.classList.add('open');d.setAttribute('aria-hidden','false');document.querySelector('.shell')?.setAttribute('inert','');document.body.style.overflow='hidden';setTimeout(()=>focusables(d)[0]?.focus(),10)}
function closeDrawer(id){const d=document.getElementById(id);if(!d.classList.contains('open'))return;d.classList.remove('open');d.setAttribute('aria-hidden','true');document.querySelector('.shell')?.removeAttribute('inert');document.body.style.overflow='';const target=drawerOpener;drawerOpener=null;setTimeout(()=>{if(target&&document.contains(target)&&typeof target.focus==='function')target.focus()},0)}
function trapDrawerFocus(e){if(e.key!=='Tab')return;const d=document.querySelector('.drawer.open');if(!d)return;const f=focusables(d);if(!f.length){e.preventDefault();return}const first=f[0],last=f[f.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}
function renderAll(){
 renderMirrors();renderCore();renderInspector();renderLenses();renderBranch();renderVault();renderProvenance();
 document.getElementById('run-status').textContent=runState.scenario_disposition;
}
function runNow(rebuildMath=true,manual=false){
 runState=AME.run(state,DEF);renderAll();if(rebuildMath)renderMathDrawer();if(manual)manualRunFeedback();
}
function applyPreset(id){
 const p=REGS.find(x=>x.case_id===id);if(!p)return;state=deepClone(p.inputs);renderQuickControls();renderMathDrawer();markDirty('Preset staged: '+id);toast('Preset staged — click Run current state')
}
function reset(){state=deepClone(DEFAULTS);renderQuickControls();renderMathDrawer();markDirty('Default scenario staged');toast('Defaults staged — click Run current state')}
function exportRun(){
 if(!runState)runNow();const payload={...runState,ui_release:'AME Phase 4 Hall of Mirrors UI v0.1.1',ui_archive_effect:'none'};
 const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='AME_SIM_001_Phase4_run.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);toast('Run exported')
}
function toast(t){const x=document.getElementById('toast');x.textContent=t;x.classList.add('show');setTimeout(()=>x.classList.remove('show'),1700)}
function init(){
 renderQuickControls();renderMathDrawer();runNow(false);setRunReceipt('Initial baseline rendered. Change a scenario condition or calculator value, then click Run current state.');
 document.getElementById('run').addEventListener('click',()=>runNow(true,true));
 document.getElementById('reset').addEventListener('click',reset);
 document.getElementById('export').addEventListener('click',exportRun);
 document.getElementById('math').addEventListener('click',e=>openDrawer('math-drawer',e.currentTarget));
 document.getElementById('source-vault-jump').addEventListener('click',()=>document.getElementById('vault-panel').scrollIntoView({behavior:'smooth'}));
 document.getElementById('motion').addEventListener('click',()=>{document.body.classList.toggle('reduce-motion');toast(document.body.classList.contains('reduce-motion')?'Motion reduced':'Motion restored')});
 document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>closeDrawer(b.dataset.close));
 document.querySelectorAll('.drawer').forEach(d=>d.addEventListener('click',e=>{if(e.target===d)closeDrawer(d.id)}));
 document.getElementById('preset-base').addEventListener('click',()=>applyPreset('BASELINE'));
 document.getElementById('preset-low').addEventListener('click',()=>applyPreset('LOW_UNCERTAINTY_HIGH_RECOVERABILITY'));
 document.getElementById('preset-reversal').addEventListener('click',()=>applyPreset('P01_Q_WEIGHT_REVERSAL_ELIGIBLE'));
 const applyRun=document.getElementById('apply-run');if(applyRun)applyRun.addEventListener('click',()=>{runNow(false,true);closeDrawer('math-drawer')});
 document.addEventListener('keydown',e=>{trapDrawerFocus(e);if(e.key==='Escape')document.querySelectorAll('.drawer.open').forEach(d=>closeDrawer(d.id))});
}
try{
  init();
  document.documentElement.setAttribute('data-ame-runtime','ready');
}catch(err){
  document.documentElement.setAttribute('data-ame-runtime','error');
  const msg=(err&&err.message)?err.message:String(err);
  const rs=document.getElementById('run-status'); if(rs) rs.textContent='AME-SIM-001 ERROR — '+msg;
  const is=document.getElementById('inspect-status'); if(is) is.textContent='runtime error';
  const ic=document.getElementById('inspect-content'); if(ic) ic.innerHTML='<div class="card"><h4>Runtime initialization error</h4><p>'+esc(msg)+'</p><p class="small">This is a delivery/runtime error, not a simulator conclusion. ARCHIVE_EFFECT: none.</p></div>';
  console.error('AME runtime initialization failed',err);
}


