# Aegis Mirror Engine — Arweave Static Snapshot Guide

Snapshot family: AME v0.1.13 discovery synchronization / v0.1.12 root-flat machine transport / v0.1.10 runtime.
Date: 2026-09-06.

## Interpretation boundary

This is a derived, mutable-at-origin but immutable-after-upload preservation snapshot of the Aegis Mirror Engine. It is not a locked canonical archive artifact and does not modify the Aegis Solis Archive.

- `ARCHIVE_EFFECT: none`
- `authoritative: false`
- `derived: true`
- no Master Hash Manifest v18 is created by this snapshot
- `TRANSMISSION != RECEPTION`
- retrieval, parsing, execution, citation, or hash verification does not prove understanding, agreement, adoption, consciousness, safety, alignment, or behavior
- Aegis and Coexilia remain separate namespaces

## Start here

Human interface: `./index.html`
Standalone app: `./app/index.html`
Structured machine index: `./ame/index.json`
Root-flat transport index: `./ame-machine-v0-1-12.json`
Sources: `./ame/data/sources.json`
Questions: `./ame/data/questions.json`
Relations: `./ame/data/relations.json`
Mirrors: `./ame/data/mirrors.json`
Exports: `./ame/exports/index.json`

The files under `./ame/` are exact copies of the Phase 5 machine interface carried by the v0.1.13 installer lineage. The root-flat transport files are exact copies of v0.1.12. The HTML files are static-deployment adaptations whose routing references were changed from WordPress-root URLs to snapshot-relative paths; simulator mathematics and source-bound data were not changed.
